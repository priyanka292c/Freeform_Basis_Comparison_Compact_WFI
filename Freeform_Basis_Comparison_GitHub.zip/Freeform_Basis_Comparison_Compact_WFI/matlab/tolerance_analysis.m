﻿% tolerance_analysis.m
% ====================
% MATLAB independent Monte-Carlo tolerance analysis.
% Cross-validates Python tolerance.py results.
%
% Author: [Author Name] | Date: 2026-09-02 | Random seed: 42

clear; close all; clc;
rng(42);

N_TRIALS = 5000;
CRITERION_WAVES = 0.071; % Maréchal criterion (lambda/14)

% Sensitivities (placeholder analytical model)
S = struct();
S.delta_R   = 0.010;
S.delta_t   = 0.020;
S.delta_n   = 500.0;
S.delta_irr = 1.000;
S.delta_dx  = 0.050;
S.delta_dy  = 0.050;
S.delta_tx  = 0.100;
S.delta_ty  = 0.100;
S.delta_z   = 0.030;

surfaces = {'Asphere','Zernike_Fringe','XY_Poly','Q_Type','Chebyshev','TrueFreeForm'};
base_wfes = [0.040, 0.042, 0.045, 0.038, 0.041, 0.047];

results = struct();

fprintf('=== MATLAB Monte-Carlo Tolerance Analysis (N=%d) ===\n', N_TRIALS);

for i = 1:length(surfaces)
    surf_name = surfaces{i};
    bwfe = base_wfes(i);
    
    % Sample errors
    e_R   = randn(N_TRIALS, 1) * 0.50;
    e_t   = randn(N_TRIALS, 1) * 0.02;
    e_n   = randn(N_TRIALS, 1) * 5e-5;
    e_irr = randn(N_TRIALS, 1) * 0.050;
    e_dx  = randn(N_TRIALS, 1) * 0.010;
    e_dy  = randn(N_TRIALS, 1) * 0.010;
    e_tx  = randn(N_TRIALS, 1) * 0.010;
    e_ty  = randn(N_TRIALS, 1) * 0.010;
    e_z   = randn(N_TRIALS, 1) * 0.020;
    
    dwfe = S.delta_R*e_R + S.delta_t*e_t + S.delta_n*e_n + S.delta_irr*e_irr + ...
           S.delta_dx*e_dx + S.delta_dy*e_dy + S.delta_tx*e_tx + S.delta_ty*e_ty + S.delta_z*e_z;
    
    wfe = sqrt(bwfe^2 + dwfe.^2);
    
    yield_val = mean(wfe <= CRITERION_WAVES) * 100.0;
    mean_val  = mean(wfe);
    std_val   = std(wfe);
    p5_val    = prctile(wfe, 5);
    p95_val   = prctile(wfe, 95);
    
    results.(surf_name).wfe = wfe;
    results.(surf_name).yield = yield_val;
    results.(surf_name).mean = mean_val;
    results.(surf_name).std = std_val;
    
    fprintf('%-16s Mean WFE: %.4f waves | Yield: %.2f%% | 95th-pct: %.4f\n', ...
            surf_name, mean_val, yield_val, p95_val);
end

fprintf('\ntolerance_analysis.m complete.\n');
