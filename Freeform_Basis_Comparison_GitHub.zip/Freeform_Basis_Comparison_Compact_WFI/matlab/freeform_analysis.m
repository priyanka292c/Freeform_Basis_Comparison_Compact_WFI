﻿% freeform_analysis.m
% ===================
% MATLAB independent reproduction of freeform surface analysis.
% Cross-validates Python results from freeform_surfaces.py and fci_calculator.py.
%
% System: Compact off-axis reflective imaging system
%   Half-aperture : 10.0 mm
%   R_base        : 80.0 mm
%   Conic k       : -0.50
%   Grid size     : 256 x 256
%
% Author: [Author Name] | Date: 2026-09-02 | Random seed: 42

clear; close all; clc;
rng(42);  % Set random seed for reproducibility

%% System constants
HALF_AP = 10.0;   % mm
R_BASE  = 80.0;   % mm
K_BASE  = -0.50;
N_PTS   = 256;
DX      = 2*HALF_AP / (N_PTS - 1);  % mm/pixel

%% Grid
x1 = linspace(-HALF_AP, HALF_AP, N_PTS);
[x, y] = meshgrid(x1, x1);

%% ─── FUNCTION: Even Asphere Sag ────────────────────────────────────────────
% z = c*r^2 / (1 + sqrt(1 - (1+k)*c^2*r^2))
c = 1/R_BASE;
r2 = x.^2 + y.^2;
denom = 1 + sqrt(max(1 - (1+K_BASE)*c^2*r2, 0));
z_base = c*r2 ./ denom;

%% ─── FUNCTION: Zernike Radial Polynomial ───────────────────────────────────
function R = zernike_radial(n, m, rho)
    m_abs = abs(m);
    if mod(n - m_abs, 2) ~= 0
        R = zeros(size(rho));
        return;
    end
    R = zeros(size(rho));
    for s = 0 : (n - m_abs)/2
        num = (-1)^s * factorial(n-s);
        den = factorial(s) * factorial((n+m_abs)/2-s) * factorial((n-m_abs)/2-s);
        R = R + (num/den) * rho.^(n-2*s);
    end
end

%% ─── Zernike Fringe Surface ─────────────────────────────────────────────────
rho   = sqrt(x.^2 + y.^2) / HALF_AP;
theta = atan2(y, x);

% Fringe coefficients (matching Python):
% j=5 (n=2,m=2,cos): a=0.050; j=9 (n=4,m=0): a=0.030;
% j=12(n=4,m=2,cos): a=0.020; j=16(n=6,m=0): a=0.012
zern_coeffs = [5, 0.050; 9, 0.030; 12, 0.020; 16, 0.012; 17, 0.008; 25, 0.005];

FRINGE_NM = [0,0; 1,1; 1,-1; 2,0; 2,2; 2,-2; 3,1; 3,-1; 4,0; 3,3; ...
             3,-3; 4,2; 4,-2; 5,1; 5,-1; 6,0; 4,4; 4,-4; 5,3; 5,-3; ...
             6,2; 6,-2; 7,1; 7,-1; 8,0; 5,5; 5,-5];

z_zernike = z_base;
for row = 1:size(zern_coeffs,1)
    j = zern_coeffs(row,1);
    a = zern_coeffs(row,2);
    n = FRINGE_NM(j,1);
    m = FRINGE_NM(j,2);
    m_abs = abs(m);
    Rnm = zernike_radial(n, m_abs, rho);
    if m == 0
        N_norm = sqrt(n+1);
        Z = N_norm * Rnm;
    elseif m > 0
        N_norm = sqrt(2*(n+1));
        Z = N_norm * Rnm .* cos(m*theta);
    else
        N_norm = sqrt(2*(n+1));
        Z = N_norm * Rnm .* sin(m_abs*theta);
    end
    z_zernike = z_zernike + a * Z;
end

%% ─── Chebyshev Polynomial ───────────────────────────────────────────────────
function T = cheby_T(n, t)
    if n == 0; T = ones(size(t)); return; end
    if n == 1; T = t; return; end
    T0 = ones(size(t)); T1 = t;
    for k = 2:n
        T2 = 2*t.*T1 - T0; T0 = T1; T1 = T2;
    end
    T = T1;
end

tx = x / HALF_AP; ty = y / HALF_AP;
cheby_coeffs = {[0,2], 0.0011; [0,4], 0.0005; [2,0], 0.0009; ...
                [2,2], 0.0004; [4,0], 0.0003; [0,6], 0.0002; [6,0], 0.0002};

z_chebyshev = z_base;
for k = 1:size(cheby_coeffs,1)
    ij  = cheby_coeffs{k,1};
    aij = cheby_coeffs{k,2};
    z_chebyshev = z_chebyshev + aij * cheby_T(ij(1), tx) .* cheby_T(ij(2), ty);
end

%% ─── XY Polynomial ──────────────────────────────────────────────────────────
xy_coeffs = {[0,2], 0.0012; [0,4], 0.0006; [2,0], 0.0010; ...
             [2,2], 0.0005; [4,0], 0.0004; [0,6], 0.0002; [6,0], 0.0002};
z_xy = z_base;
for k = 1:size(xy_coeffs,1)
    ij  = xy_coeffs{k,1};
    aij = xy_coeffs{k,2};
    z_xy = z_xy + aij * x.^ij(1) .* y.^ij(2);
end

%% ─── Surface Metrics ────────────────────────────────────────────────────────
function metrics = compute_metrics(z, z_base, dx, label)
    dep = z - z_base;
    pv_sag  = max(dep(:)) - min(dep(:));
    rms_sag = sqrt(mean(dep(:).^2));
    [dzdx, dzdy] = gradient(dep, dx);
    slope_mag = sqrt(dzdx.^2 + dzdy.^2);
    max_slope = max(slope_mag(:));
    rms_slope = sqrt(mean(slope_mag(:).^2));
    [d2zdx2, ~] = gradient(dzdx, dx);
    [~, d2zdy2] = gradient(dzdy, dx);
    H = 0.5*(d2zdx2 + d2zdy2);
    rms_curv = sqrt(mean(H(:).^2));
    metrics = struct('label', label, 'pv_sag_mm', pv_sag, ...
        'rms_sag_mm', rms_sag, 'max_slope', max_slope, ...
        'rms_slope', rms_slope, 'rms_curv_mm1', rms_curv);
    fprintf('%-20s PV_sag=%.4f mm  RMS_sag=%.4f mm  Max_slope=%.4f  RMS_slope=%.4f\n', ...
        label, pv_sag, rms_sag, max_slope, rms_slope);
end

fprintf('\n=== MATLAB Surface Metrics (cross-validation) ===\n');
m_base  = compute_metrics(z_base,      z_base, DX, 'Asphere');
m_zern  = compute_metrics(z_zernike,   z_base, DX, 'Zernike_Fringe');
m_cheby = compute_metrics(z_chebyshev, z_base, DX, 'Chebyshev');
m_xy    = compute_metrics(z_xy,        z_base, DX, 'XY_Poly');

%% ─── Save validation CSV ────────────────────────────────────────────────────
metrics_all = {m_base, m_zern, m_cheby, m_xy};
out_table = table();
for k = 1:length(metrics_all)
    m = metrics_all{k};
    out_table = [out_table; {m.label, m.pv_sag_mm, m.rms_sag_mm, ...
                              m.max_slope, m.rms_slope, m.rms_curv_mm1}];
end
out_table.Properties.VariableNames = {'surface','pv_sag_mm','rms_sag_mm',...
    'max_slope','rms_slope','rms_curv_mm1'};
out_table.source = repmat({'MATLAB_2026-09-02'}, height(out_table), 1);

writetable(out_table, fullfile('..','data','csv','python_matlab_validation.csv'));
fprintf('\nValidation table saved to data/csv/python_matlab_validation.csv\n');

%% ─── Figures ────────────────────────────────────────────────────────────────
figure('Name','Zernike Departure','Position',[100 100 900 300]);
subplot(1,3,1); imagesc(x1, x1, z_zernike - z_base); colorbar; axis square;
title('Zernike Departure [mm]'); xlabel('x [mm]'); ylabel('y [mm]');
colormap('RdBu'); set(gca,'YDir','normal');

subplot(1,3,2); imagesc(x1, x1, z_chebyshev - z_base); colorbar; axis square;
title('Chebyshev Departure [mm]'); xlabel('x [mm]');
colormap('RdBu'); set(gca,'YDir','normal');

subplot(1,3,3); imagesc(x1, x1, z_xy - z_base); colorbar; axis square;
title('XY Departure [mm]'); xlabel('x [mm]');
colormap('RdBu'); set(gca,'YDir','normal');

sgtitle('MATLAB: Freeform Sag Departure Comparison');
saveas(gcf, fullfile('..','figures','source','matlab_surface_comparison.png'));

fprintf('\nfreeform_analysis.m complete.\n');
