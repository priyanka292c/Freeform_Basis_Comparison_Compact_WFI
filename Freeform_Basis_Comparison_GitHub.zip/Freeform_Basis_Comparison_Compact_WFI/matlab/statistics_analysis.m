﻿% statistics_analysis.m
% =====================
% MATLAB statistical significance testing and ANOVA for freeform benchmarks.
% Cross-validates Python statistics.py.
%
% Author: [Author Name] | Date: 2026-09-02 | Random seed: 42

clear; close all; clc;
rng(42);

% Load tolerance distributions or simulate matching sets
surfaces = {'Asphere','Zernike_Fringe','XY_Poly','Q_Type','Chebyshev','TrueFreeForm'};
base_wfes = [0.040, 0.042, 0.045, 0.038, 0.041, 0.047];
N = 1000;

data_matrix = zeros(N, length(surfaces));
for j = 1:length(surfaces)
    data_matrix(:, j) = base_wfes(j) + 0.015 * randn(N, 1);
end

% One-way ANOVA
[p_anova, tbl, stats_res] = anova1(data_matrix, surfaces, 'off');
fprintf('=== ANOVA Analysis across Freeform Representations ===\n');
fprintf('F-statistic: %.4f | p-value: %e\n', tbl{2,5}, p_anova);

% Kruskal-Wallis non-parametric test
[p_kw, tbl_kw] = kruskalwallis(data_matrix, surfaces, 'off');
fprintf('Kruskal-Wallis H-statistic: %.4f | p-value: %e\n', tbl_kw{2,5}, p_kw);

% Effect size eta^2
SS_between = tbl{2,4};
SS_total = tbl{4,4};
eta_squared = SS_between / SS_total;
fprintf('Eta-squared (effect size): %.4f\n', eta_squared);

fprintf('\nstatistics_analysis.m complete.\n');
