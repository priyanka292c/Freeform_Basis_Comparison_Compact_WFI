﻿% master_analysis.m
% =================
% Master MATLAB analysis orchestrator.
% Runs all MATLAB modules in sequence.
%
% Author: [Author Name] | Date: 2026-09-02

clear; close all; clc;

fprintf('====================================================\n');
fprintf('FREEFORM BASIS COMPARISON — MATLAB MASTER ANALYSIS\n');
fprintf('====================================================\n\n');

fprintf('Step 1: Running freeform surface analysis...\n');
freeform_analysis;

fprintf('\nStep 2: Running tolerance analysis...\n');
tolerance_analysis;

fprintf('\nStep 3: Running statistical analysis...\n');
statistics_analysis;

fprintf('\n====================================================\n');
fprintf('ALL MATLAB ANALYSES COMPLETED SUCCESSFULLY\n');
fprintf('====================================================\n');
