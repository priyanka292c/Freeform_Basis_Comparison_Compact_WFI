ELSEVIER SUBMISSION PACKAGE
===========================
Article Title: Benchmarking Mathematical Freeform Surface Representations for Robust Compact Wide-Field Imaging
Target Journal: Optics & Laser Technology (Elsevier)
Authors: Priyanka, Abhijit Das, Ram Soorat (Corresponding: rsoorat@gmail.com)

File Inventory:
1. 01_Main_Manuscript.pdf            - Full 13-page double-column research article
2. 02_Supplementary_Information.pdf - 10-page complete supplementary data & prescriptions
3. 03_Research_Highlights.pdf       - Formatted 1-page Research Highlights (5 bullets <= 85 chars)
   03_Research_Highlights.txt       - Plain-text highlights for direct portal copy-pasting
4. 04_Cover_Letter.pdf              - Formal 2-page editorial cover letter
   04_Cover_Letter.txt              - Plain-text cover letter for direct portal copy-pasting
5. 05_Graphical_Abstract.png        - 300 DPI high-resolution graphical abstract (PNG)
   05_Graphical_Abstract.pdf        - Vector PDF graphical abstract (Elsevier recommended)
6. 06_Declaration_of_Generative_AI.txt - Formatted Elsevier AI disclosure declaration
7. LaTeX_Source_Files/              - Full LaTeX source tree (main.tex, supplementary.tex, bib, and figures)
