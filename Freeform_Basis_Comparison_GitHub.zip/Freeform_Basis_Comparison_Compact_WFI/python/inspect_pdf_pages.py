import pypdf

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Total pages: {len(reader.pages)}")

for i, page in enumerate(reader.pages, 1):
    text = page.extract_text()
    first_line = text.split('\n')[0] if text else ''
    last_line = text.split('\n')[-2] if text and len(text.split('\n')) > 1 else ''
    print(f"Page {i:02d}: {len(text)} chars | First: {first_line[:40]}... | Last: ...{last_line[-40:]}")
