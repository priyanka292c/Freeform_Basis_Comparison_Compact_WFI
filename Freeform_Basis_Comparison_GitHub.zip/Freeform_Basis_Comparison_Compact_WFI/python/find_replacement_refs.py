"""
find_replacement_refs.py
Uses CrossRef to find real, topically appropriate papers to replace the 19
off-topic references in the freeform optics manuscript.
Each replacement targets the same citation context/number in the paper.
"""
import urllib.request, urllib.parse, json, time, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

HEADERS = {"User-Agent": "RefFinder/1.0 (mailto:priyanka292c@gmail.com)"}

def crossref_search(query, rows=3, from_year=2015):
    """Search CrossRef for papers matching a query."""
    params = urllib.parse.urlencode({
        "query": query,
        "rows": rows,
        "filter": f"from-pub-date:{from_year}",
        "select": "DOI,title,author,published-print,published-online,container-title,volume,page,issue",
        "sort": "relevance",
    })
    url = f"https://api.crossref.org/works?{params}"
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode())
    return data.get("message", {}).get("items", [])

def format_ref(item):
    """Format a CrossRef item as a LaTeX \bibitem entry."""
    title = item.get("title", [""])[0]
    authors = item.get("author", [])
    doi = item.get("DOI", "")
    journal_list = item.get("container-title", [])
    journal = journal_list[0] if journal_list else ""
    
    # Year
    year = None
    for df in ["published-print", "published-online", "issued"]:
        dp = item.get(df, {}).get("date-parts", [[]])
        if dp and dp[0]:
            year = dp[0][0]
            break
    
    # Volume / pages
    vol = item.get("volume", "")
    page = item.get("page", "")
    
    # Format authors
    if len(authors) == 0:
        author_str = "—"
    elif len(authors) == 1:
        a = authors[0]
        author_str = f"{a.get('given','')[:1]}. {a.get('family','')}"
    elif len(authors) == 2:
        a, b = authors[0], authors[1]
        author_str = f"{a.get('given','')[:1]}. {a.get('family','')} and {b.get('given','')[:1]}. {b.get('family','')}"
    else:
        a = authors[0]
        author_str = f"{a.get('given','')[:1]}. {a.get('family','')} et al."
    
    vol_str = f"\\textbf{{{vol}}}" if vol else ""
    page_str = f", {page}" if page else ""
    year_str = f" ({year})" if year else ""
    
    oq = "``"
    cq = "''"
    entry = f"{author_str}, {oq}{title},{cq}  \\textit{{{journal}}} {vol_str}{page_str}{year_str}. \\doi{{{doi}}}"
    return {
        "doi": doi,
        "title": title,
        "journal": journal,
        "year": year,
        "authors": [f"{a.get('given','')[:1]}. {a.get('family','')}" for a in authors[:3]],
        "latex": entry,
    }

# ── Replacement queries for each off-topic reference ─────────────────────────
# Each entry: (bibitem_key, citation_number, description_of_needed_ref, search_query)
NEEDED = [
    ("Qin2022OLT",    26, "Freeform optics for remote sensing / compact imaging system",
     "freeform mirror compact wide-field imaging telescope design"),
    
    ("Li2023OLT",     27, "Chebyshev polynomial fitting / rectangular aperture surface description",
     "Chebyshev polynomial optical surface fitting rectangular aperture freeform"),
    
    ("Cheng2023OLT",  29, "Zernike or phi-polynomial freeform surface for imaging",
     "phi-polynomial Zernike freeform optical design off-axis imaging"),
    
    ("Zhang2019CIRP", 51, "Single-point diamond turning freeform optics manufacturing CIRP",
     "single-point diamond turning freeform optical surface CIRP manufacturing"),
    
    ("Brinksmeier2012", 52, "Ultra-precision machining freeform surfaces manufacturing CIRP",
     "ultra-precision machining freeform optics surface finishing CIRP 2012"),
    
    ("Gao2019PE",     53, "Precision engineering fast tool servo freeform machining",
     "fast tool servo freeform optical surface precision engineering machining"),
    
    ("Shore2011",     54, "Diamond turning / slow slide servo freeform manufacturing precision engineering",
     "slow slide servo diamond turning freeform optical surface precision engineering"),
    
    ("Beaucamp2017",  55, "Bonnet polishing / MRF mid-spatial frequency freeform optics",
     "magneto-rheological finishing MRF freeform optical surface mid-spatial frequency"),
    
    ("Gong2021OLT",   56, "Freeform optical surface manufacturing OLT 2021",
     "freeform surface optical manufacturing tolerancing Optics Laser Technology 2021"),
    
    ("Liu2022OLT",    57, "Surface measurement interferometry freeform optics OLT 2022",
     "freeform optical surface interferometry measurement Optics Laser Technology 2022"),
    
    ("Zhao2020OLT",   60, "Optical system freeform design OLT 2020",
     "freeform optical imaging system compact design Optics Laser Technology 2020"),
    
    ("Wang2024OLT",   61, "Freeform optical design or metrology OLT 2024",
     "freeform optical system design or metrology Optics Laser Technology 2024"),
    
    ("Xu2023OLT",     62, "PSD or wavefront error analysis freeform optics OLT 2023",
     "wavefront error power spectral density freeform optical surface 2023"),
    
    ("Shi2021OLT",    64, "Freeform tolerancing or manufacturing OLT 2021",
     "freeform surface manufacturing tolerance optical system 2021"),
    
    ("Howard2013",    67, "Tolerancing freeform optical surfaces SPIE",
     "tolerancing freeform optical surfaces SPIE Proceedings"),
    
    ("Song2022OLT",   70, "Freeform optics surface characterization or metrology OLT 2022",
     "freeform optical surface characterization polynomial basis OLT 2022"),
    
    ("Duparre2002",   72, "Scatter optical surfaces roughness measurement freeform",
     "surface scatter roughness mid-spatial frequency optical imaging quality"),
    
    ("DeGroote2012",  73, "Magnetorheological finishing freeform optics 2012",
     "magnetorheological finishing freeform optical surface SPIE 2012"),
    
    ("Wu2023OLT",     78, "OLT freeform optics or optical system design 2023-2024",
     "freeform optical surface design compact imaging system Optics Laser Technology 2024"),
]

print(f"Finding {len(NEEDED)} replacement references via CrossRef...\n")
print("=" * 70)

replacements = {}

for key, num, description, query in NEEDED:
    print(f"[{num:02d}] {key}")
    print(f"     Need: {description}")
    try:
        items = crossref_search(query, rows=3, from_year=2010)
        candidates = []
        for item in items:
            formatted = format_ref(item)
            candidates.append(formatted)
            print(f"     CANDIDATE: {formatted['title'][:70]}")
            print(f"                {formatted['journal']} ({formatted['year']}) DOI:{formatted['doi']}")
        
        replacements[key] = {
            "num": num,
            "description": description,
            "candidates": candidates,
            "selected": candidates[0] if candidates else None,
        }
    except Exception as e:
        print(f"     ERROR: {e}")
        replacements[key] = {"num": num, "description": description, "candidates": [], "selected": None}
    
    print()
    time.sleep(0.4)

# Save
with open("python/replacement_refs.json", "w", encoding="utf-8") as f:
    json.dump(replacements, f, indent=2, ensure_ascii=False)
print(f"\nSaved: python/replacement_refs.json")
print(f"Found replacements for {sum(1 for v in replacements.values() if v.get('selected'))} of {len(NEEDED)} refs")
