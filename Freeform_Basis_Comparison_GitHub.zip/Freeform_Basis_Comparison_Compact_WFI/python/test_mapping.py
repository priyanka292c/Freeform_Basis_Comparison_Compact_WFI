import re
import json

# Load verified 80 references
with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    bib_data = json.load(f)

expected_keys = [it['key'] for it in bib_data]
key_to_order = {it['key']: it['order'] for it in bib_data}

print(f"Loaded {len(expected_keys)} keys.")
assert len(expected_keys) == 80
