import urllib.request
import urllib.parse
import json
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

from curated_80_targets import curated_targets

HEADERS = {'User-Agent': 'OpticsResearchBibValidator/2.0 (mailto:optics.research@edu.org)'}

def fetch_doi_metadata(doi):
    url = f"https://api.crossref.org/works/{urllib.parse.quote(doi)}"
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return parse_crossref_item(data.get('message', {}))
    except Exception as e:
        return None

def search_crossref_article(query):
    params = urllib.parse.urlencode({
        'query': query,
        'rows': 3,
        'filter': 'type:journal-article'
    })
    url = f"https://api.crossref.org/works?{params}"
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            items = data.get('message', {}).get('items', [])
            for item in items:
                parsed = parse_crossref_item(item)
                if parsed and parsed.get('doi') and parsed.get('title'):
                    return parsed
            return None
    except Exception as e:
        return None

def parse_crossref_item(item):
    doi = item.get('DOI', '').strip()
    titles = item.get('title', [])
    title = titles[0].strip() if titles and titles[0] else ''
    
    container = item.get('container-title', [])
    journal = container[0].strip() if container and container[0] else ''
    if not journal:
        # Check event or publisher
        event = item.get('event', {})
        journal = event.get('name', '') or item.get('publisher', '')
        
    pub = item.get('published-print') or item.get('published-online') or item.get('created')
    year = pub['date-parts'][0][0] if pub and 'date-parts' in pub else ''
    
    volume = item.get('volume', '')
    issue = item.get('issue', '')
    page = item.get('page', '')
    
    authors_list = item.get('author', [])
    author_names = []
    for a in authors_list:
        given = a.get('given', '').strip()
        family = a.get('family', '').strip()
        if given and family:
            initials = " ".join([f"{n[0]}." for n in given.split() if n])
            author_names.append(f"{initials} {family}")
        elif family:
            author_names.append(family)
            
    return {
        'doi': doi,
        'title': title,
        'journal': journal,
        'year': year,
        'volume': volume,
        'issue': issue,
        'page': page,
        'authors': author_names
    }

verified_entries = []
seen_dois = set()

print(f"Starting verification of {len(curated_targets)} entries against CrossRef...")

for i, target in enumerate(curated_targets, 1):
    key = target['key']
    doi_hint = target.get('doi_hint')
    query = target['query']
    
    item = None
    if doi_hint:
        item = fetch_doi_metadata(doi_hint)
        if item:
            item['source'] = 'doi_direct'
    
    if not item or not item.get('title'):
        item = search_crossref_article(query)
        if item:
            item['source'] = 'search'
            
    if not item or not item.get('doi'):
        print(f"[{i:02d}/80] FAILED: {key} (query: {query})")
        continue
        
    # Check duplicate DOI
    doi = item['doi'].lower()
    if doi in seen_dois:
        print(f"[{i:02d}/80] DUPLICATE DOI {doi} for {key}, attempting alternative search...")
        # Search with key and different terms
        alt_item = search_crossref_article(f"{query} optical engineering")
        if alt_item and alt_item['doi'].lower() not in seen_dois:
            item = alt_item
            doi = item['doi'].lower()
        else:
            print(f"[{i:02d}/80] CRITICAL: Could not find unique DOI for {key}")
            
    seen_dois.add(doi)
    item['key'] = key
    item['order'] = i
    verified_entries.append(item)
    
    print(f"[{i:02d}/80] OK: {key:16s} | {item['year']} | {item['journal'][:25]:25s} | DOI: {item['doi']}")
    time.sleep(0.12)

print(f"\nCompleted: {len(verified_entries)} / {len(curated_targets)} entries verified.")
print(f"Unique DOIs: {len(seen_dois)}")

with open('python/verified_80_final.json', 'w', encoding='utf-8') as f:
    json.dump(verified_entries, f, indent=2, ensure_ascii=False)

print("Saved metadata to python/verified_80_final.json")
