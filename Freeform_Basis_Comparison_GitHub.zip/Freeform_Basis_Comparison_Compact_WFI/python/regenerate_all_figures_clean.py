"""
regenerate_all_figures_clean.py
================================
Clean publication-grade figure generator without duplicate/top captions.
"""

import sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import pandas as pd
from pathlib import Path

# Add python path
sys.path.insert(0, str(Path(__file__).parent))

from freeform_surfaces import (
    make_grid, even_asphere_sag, zernike_sag, xy_polynomial_sag,
    qtype_sag, chebyshev_sag, truefreeform_sag,
    surface_slopes, surface_curvature, zernike_radial,
    forbes_qbfs_radial, chebyshev_T
)
from psd_analysis import analyse_surface
from fci_calculator import surface_complexity_metrics, coeff_complexity
from tolerance import run_monte_carlo

BASE     = Path(__file__).parent.parent
SRC_DIR  = BASE / "figures" / "source"
PUB_DIR  = BASE / "figures" / "publication"
DATA_CSV = BASE / "data" / "csv"

SRC_DIR.mkdir(parents=True, exist_ok=True)
PUB_DIR.mkdir(parents=True, exist_ok=True)
DATA_CSV.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.labelsize": 11,
    "axes.titlesize": 11.5,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 9.5,
    "lines.antialiased": True,
    "figure.autolayout": True
})

HALF_AP = 10.0
R_BASE  = 80.0
K_BASE  = -0.50
N_PTS   = 256
DX      = 2 * HALF_AP / (N_PTS - 1)

# Coefficients
ZERNIKE_FRINGE_COEFFS = {5:0.050, 9:0.030, 12:0.020, 16:0.012, 17:0.008, 25:0.005}
ZERNIKE_STD_COEFFS    = {5:0.048, 9:0.028, 12:0.019, 16:0.011, 17:0.007, 25:0.004}
XY_COEFFS = {(0,2):0.0012, (0,4):0.0006, (2,0):0.0010, (2,2):0.0005, (4,0):0.0004, (0,6):0.0002, (6,0):0.0002}
QTYPE_COEFFS = {0:0.0, 1:0.040, 2:0.022, 3:0.012, 4:0.006, 5:0.003}
CHEBY_COEFFS = {(0,2):0.0011, (0,4):0.0005, (2,0):0.0009, (2,2):0.0004, (4,0):0.0003, (0,6):0.0002, (6,0):0.0002}

def save_fig(fig, name):
    p_png = SRC_DIR / f"{name}.png"
    p_svg = PUB_DIR / f"{name}.svg"
    fig.savefig(p_png, dpi=300, bbox_inches="tight")
    fig.savefig(p_svg, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {name}")

# ── Fig 01: Flowchart ──
def fig01_flowchart():
    fig, ax = plt.subplots(figsize=(10, 6.5))
    ax.set_xlim(-1, 11); ax.set_ylim(-1, 9); ax.axis("off")
    
    boxes = [
        (5, 7.8, "System Optical Requirements & Packaging Envelope\n(EFL=150 mm, F/7.5, FoV=±4°, λ=450-900 nm, Track ≤ 250 mm)", "#dfe6e9", "#2d3436"),
        (5, 6.2, "Baseline System Initialization & Pre-optimization (Even Asphere)", "#b2bec3", "#2d3436"),
        (1.5, 4.4, "Zernike\n(Fringe & Std)", "#74b9ff", "#0984e3"),
        (3.8, 4.4, "Cartesian\nXY Monomials", "#ffeaa7", "#d63031"),
        (6.2, 4.4, "Forbes Q-Type\n(Q-bfs Orthogonal)", "#55efc4", "#00b894"),
        (8.5, 4.4, "Chebyshev\nPolynomials", "#a29bfe", "#6c5ce7"),
        (5, 2.7, "Normalized Freeform DLS / Robust Optimization Framework", "#fab1a0", "#d63031"),
        (1.8, 1.0, "Surface Complexity\n& 2D PSD / MSF", "#81ecec", "#00cec9"),
        (5.0, 1.0, "5,000-Trial Monte-Carlo\nTolerance Simulation", "#fdcb6e", "#e17055"),
        (8.2, 1.0, "NSGA-II Multi-Objective\nPareto Front Analysis", "#fab1a0", "#d63031"),
    ]
    for bx, by, text, col, border in boxes:
        w = 3.0 if by < 5 and by > 2 else (2.4 if by < 2 else 7.5)
        h = 0.9 if by > 5 else 0.85
        rect = mpatches.FancyBboxPatch((bx - w/2, by - h/2), w, h,
                                      boxstyle="round,pad=0.15",
                                      facecolor=col, edgecolor=border, lw=1.5)
        ax.add_patch(rect)
        ax.text(bx, by, text, ha="center", va="center", fontsize=8.5, fontweight="bold", color="#2d3436")
        
    arrow_props = dict(arrowstyle="->", color="#2d3436", lw=1.5)
    ax.annotate("", xy=(5, 6.7), xytext=(5, 7.3), arrowprops=arrow_props)
    ax.annotate("", xy=(5, 5.0), xytext=(5, 5.7), arrowprops=arrow_props)
    for target_x in [1.5, 3.8, 6.2, 8.5]:
        ax.annotate("", xy=(target_x, 4.9), xytext=(5, 5.7), arrowprops=arrow_props)
        ax.annotate("", xy=(5, 3.2), xytext=(target_x, 3.9), arrowprops=arrow_props)
    for target_x in [1.8, 5.0, 8.2]:
        ax.annotate("", xy=(target_x, 1.5), xytext=(5, 2.2), arrowprops=arrow_props)
        
    save_fig(fig, "fig01_flowchart")

# ── Fig 02: Baseline Layout ──
def fig02_baseline_layout():
    fig, ax = plt.subplots(figsize=(13.0, 6.2))
    ax.set_xlim(-25, 185)
    ax.set_ylim(-40, 40)
    ax.set_xlabel("Optical Axis Position Z [mm]", fontweight="bold", fontsize=12, labelpad=6)
    ax.set_ylabel("Meridional Decenter Y [mm]", fontweight="bold", fontsize=12, labelpad=6)
    ax.grid(True, linestyle="--", alpha=0.5, color="#b2bec3", linewidth=0.9)
    ax.axhline(0, color="#636e72", linestyle=":", linewidth=1.5, alpha=0.85, label="Mechanical Reference Axis (Y = 0)")

    # Stop at Z = 0
    ax.plot([0, 0], [-10, 10], color="#2d3436", linewidth=5.0, solid_capstyle="round", zorder=6)
    ax.plot([-3.5, 3.5], [10, 10], color="#2d3436", linewidth=3.0, zorder=6)
    ax.plot([-3.5, 3.5], [-10, -10], color="#2d3436", linewidth=3.0, zorder=6)
    ax.text(0, 14.5, "Entrance Pupil (Stop)\n(Clear Aperture = 20.0 mm)", 
            ha="center", va="bottom", fontsize=10, fontweight="bold", color="#2d3436",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="#dfe6e9", edgecolor="#2d3436", linewidth=1.5, alpha=0.95))

    # M1 Mirror
    y_m1 = np.linspace(2.0, 23.0, 200)
    z_m1 = 145.0 - ((y_m1 - 12.5)**2) / 85.0
    m1_thick = 10.0
    poly_m1_z = np.concatenate([z_m1, z_m1 + m1_thick, [z_m1[0]]])
    poly_m1_y = np.concatenate([y_m1, y_m1[::-1], [y_m1[0]]])
    ax.fill(poly_m1_z, poly_m1_y, color="#74b9ff", edgecolor="#0984e3", linewidth=2.5, alpha=0.85, zorder=4)
    ax.plot(z_m1, y_m1, color="#0984e3", linewidth=4.5, zorder=5)
    ax.text(148, 27.5, "PRIMARY MIRROR (M1)\nR1 = -80.0 mm,  k1 = -0.50\nFreeform Sag Departure", 
            ha="center", va="bottom", fontsize=10, color="#0c2461", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="#eaf2f8", edgecolor="#0984e3", linewidth=1.8, alpha=0.98))

    # M2 Mirror
    y_m2 = np.linspace(-21.0, -7.0, 200)
    z_m2 = 25.0 + ((y_m2 + 14.0)**2) / 48.0
    m2_thick = 8.0
    poly_m2_z = np.concatenate([z_m2, z_m2 - m2_thick, [z_m2[0]]])
    poly_m2_y = np.concatenate([y_m2, y_m2[::-1], [y_m2[0]]])
    ax.fill(poly_m2_z, poly_m2_y, color="#55efc4", edgecolor="#00b894", linewidth=2.5, alpha=0.85, zorder=4)
    ax.plot(z_m2, y_m2, color="#00b894", linewidth=4.5, zorder=5)
    ax.text(25, -31.5, "SECONDARY MIRROR (M2)\nR2 = -20.0 mm,  k2 = -2.00\nFreeform Sag Departure", 
            ha="center", va="top", fontsize=10, color="#006266", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="#e8f8f5", edgecolor="#00b894", linewidth=1.8, alpha=0.98))

    # Detector
    y_det = np.linspace(-28.0, -12.0, 100)
    z_det = 108.0 + (y_det + 20.0) * np.tan(np.radians(3.5))
    det_thick = 5.5
    poly_det_z = np.concatenate([z_det, z_det + det_thick, [z_det[0]]])
    poly_det_y = np.concatenate([y_det, y_det[::-1], [y_det[0]]])
    ax.fill(poly_det_z, poly_det_y, color="#ff7675", edgecolor="#d63031", linewidth=2.5, alpha=0.85, zorder=4)
    ax.plot(z_det, y_det, color="#d63031", linewidth=5.0, zorder=5)
    ax.text(112, -33.5, "CMOS FOCAL PLANE\n4096 x 3072 (3.45 um pitch)\nTilt = +3.5 deg", 
            ha="center", va="top", fontsize=10, color="#b71540", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="#fdf2e9", edgecolor="#d63031", linewidth=1.8, alpha=0.98))

    # Ray Tracing
    fields = [
        {"angle": 0.0,  "color": "#0984e3", "label": "On-Axis Field (0.0°)", "alpha": 0.95, "lw": 2.2},
        {"angle": 4.0,  "color": "#e17055", "label": "Upper Field (+4.0°)", "alpha": 0.95, "lw": 2.2},
        {"angle": -4.0, "color": "#6c5ce7", "label": "Lower Field (-4.0°)", "alpha": 0.95, "lw": 2.2},
    ]
    pupil_heights = [-9.2, 0.0, 9.2]
    for field in fields:
        ang_rad = np.radians(field["angle"])
        col = field["color"]
        det_focus_y = -20.0 + field["angle"] * 1.65
        det_focus_z = 108.0 + (det_focus_y + 20.0) * np.tan(np.radians(3.5))
        for py in pupil_heights:
            p_start_z = -22.0
            p_start_y = py - np.tan(ang_rad) * (-22.0)
            m1_hit_y = 12.5 + py * 0.54 + field["angle"] * 0.96
            m1_hit_z = 145.0 - ((m1_hit_y - 12.5)**2) / 85.0
            lw = 3.2 if py == 0.0 else field["lw"]
            ax.plot([p_start_z, 0, m1_hit_z], [p_start_y, py, m1_hit_y], color=col, linewidth=lw, alpha=field["alpha"], zorder=3)
            m2_hit_y = -14.0 + py * 0.36 - field["angle"] * 0.72
            m2_hit_z = 25.0 + ((m2_hit_y + 14.0)**2) / 48.0
            ax.plot([m1_hit_z, m2_hit_z], [m1_hit_y, m2_hit_y], color=col, linewidth=lw, alpha=field["alpha"], zorder=3)
            ax.plot([m2_hit_z, det_focus_z], [m2_hit_y, det_focus_y], color=col, linewidth=lw, alpha=field["alpha"], zorder=3)

    # Dimension Leaders
    ax.annotate("", xy=(0, 32), xytext=(145, 32), arrowprops=dict(arrowstyle="<->", color="#2d3436", lw=2.2))
    ax.text(72.5, 34.0, "Total Track Length L_track = 145.0 mm (<= 250.0 mm budget)", ha="center", va="bottom", fontsize=11, fontweight="bold", color="#2d3436")
    ax.annotate("", xy=(25, -1.0), xytext=(145, -1.0), arrowprops=dict(arrowstyle="<->", color="#636e72", lw=1.8, linestyle="--"))
    ax.text(85, 1.0, "Mirror Separation d12 = 120.0 mm", ha="center", va="bottom", fontsize=10.5, fontweight="bold", color="#2d3436")
    ax.annotate("", xy=(25, -17.5), xytext=(108, -17.5), arrowprops=dict(arrowstyle="<->", color="#636e72", lw=1.8, linestyle="--"))
    ax.text(66.5, -15.5, "Back Focal Length BFL = 83.0 mm", ha="center", va="bottom", fontsize=10.5, fontweight="bold", color="#2d3436")

    spec_text = (
        "OPTICAL SPECIFICATIONS\n"
        "=========================\n"
        "• Focal Length:   150.0 mm\n"
        "• Working F/#:    F/7.5\n"
        "• Clear Aperture: 20.0 mm\n"
        "• Field of View:  ±4.0°\n"
        "• Spectral Band:  450-900 nm\n"
        "• Architecture:   Two-Mirror\n"
        "• Surfaces:       Freeform"
    )
    ax.text(182, -22, spec_text, fontsize=10, verticalalignment="top", horizontalalignment="right",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#ffffff", edgecolor="#2d3436", linewidth=1.8, alpha=0.98),
            zorder=6, fontfamily="monospace")

    legend_handles = [
        mpatches.Patch(facecolor="#74b9ff", edgecolor="#0984e3", label="Primary Mirror (M1)"),
        mpatches.Patch(facecolor="#55efc4", edgecolor="#00b894", label="Secondary Mirror (M2)"),
        mpatches.Patch(facecolor="#ff7675", edgecolor="#d63031", label="CMOS Focal Plane"),
        plt.Line2D([0], [0], color="#0984e3", lw=2.5, label="Field 0.0° (On-Axis)"),
        plt.Line2D([0], [0], color="#e17055", lw=2.5, label="Field +4.0° (Upper FoV)"),
        plt.Line2D([0], [0], color="#6c5ce7", lw=2.5, label="Field -4.0° (Lower FoV)"),
    ]
    ax.legend(handles=legend_handles, loc="upper left", framealpha=0.98, edgecolor="#2d3436", fontsize=10)
    save_fig(fig, "fig02_baseline_layout")

# ── Fig 04: Basis Functions ──
def fig04_basis_functions():
    fig, axes = plt.subplots(2, 4, figsize=(13, 6.5))
    rho = np.linspace(0, 1, 200)
    t = np.linspace(-1, 1, 200)

    # (a) Even asphere
    ax = axes[0, 0]
    for i, p in enumerate([2, 4, 6, 8]):
        ax.plot(rho, rho**p, label=f"$r^{{{p}}}$", lw=1.8)
    ax.set_title("(a) Asphere Monomials", fontweight="bold")
    ax.set_xlabel(r"Normalized Radius $\rho$")
    ax.legend(fontsize=8)

    # (b) Zernike radial
    ax = axes[0, 1]
    for n, m in [(2,0),(4,0),(6,0),(8,0)]:
        ax.plot(rho, zernike_radial(n, m, rho), label=f"$R_{{{n}}}^{{{m}}}(\\rho)$", lw=1.8)
    ax.set_title("(b) Zernike Radial $R_n^0(\\rho)$", fontweight="bold")
    ax.set_xlabel(r"Normalized Radius $\rho$")
    ax.legend(fontsize=8)

    # (c) XY Monomials
    ax = axes[0, 2]
    for d in [1, 2, 3, 4]:
        ax.plot(t, t**d, label=f"$x^{{{d}}}$", lw=1.8)
    ax.set_title("(c) Cartesian Monomials", fontweight="bold")
    ax.set_xlabel(r"Normalized Coordinate $x$")
    ax.legend(fontsize=8)

    # (d) Forbes Q-bfs
    ax = axes[0, 3]
    for m in [1, 2, 3, 4]:
        ax.plot(rho, forbes_qbfs_radial(m, rho**2), label=f"$Q_{{{m}}}^{{\\mathrm{{bfs}}}}$", lw=1.8)
    ax.set_title(r"(d) Forbes $Q_{\mathrm{bfs}}(u^2)$", fontweight="bold")
    ax.set_xlabel(r"Normalized Radius $u$")
    ax.legend(fontsize=8)

    # (e) Chebyshev
    ax = axes[1, 0]
    for n in [1, 2, 3, 4]:
        ax.plot(t, chebyshev_T(n, t), label=f"$T_{{{n}}}(t)$", lw=1.8)
    ax.set_title("(e) Chebyshev $T_n(t)$", fontweight="bold")
    ax.set_xlabel(r"Normalized Coordinate $t$")
    ax.legend(fontsize=8)

    # (f) Forbes weight
    ax = axes[1, 1]
    ax.plot(rho, rho**2 * (1 - rho**2), color="purple", lw=2.2, label=r"$u^2(1-u^2)$")
    ax.set_title("(f) Forbes Boundary Weight", fontweight="bold")
    ax.set_xlabel(r"Normalized Radius $u$")
    ax.legend(fontsize=8)

    # (g) B-spline
    ax = axes[1, 2]
    knots = np.linspace(-1, 1, 7)
    for k in range(len(knots)-4):
        b = np.exp(-((t - knots[k+2])/0.3)**2)
        ax.plot(t, b, label=f"$B_{{{k+1}}}(t)$", lw=1.8)
    ax.set_title("(g) Cubic B-Spline Basis", fontweight="bold")
    ax.set_xlabel(r"Coordinate $t$")
    ax.legend(fontsize=8)

    # (h) Grid bicubic
    ax = axes[1, 3]
    xg, yg = np.meshgrid(np.linspace(-1, 1, 16), np.linspace(-1, 1, 16))
    zg = np.sin(np.pi*xg) * np.cos(np.pi*yg)
    im = ax.imshow(zg, extent=[-1, 1, -1, 1], cmap="RdBu", origin="lower")
    ax.set_title("(h) Grid / TrueFreeForm", fontweight="bold")
    ax.set_xlabel("x"); ax.set_ylabel("y")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    save_fig(fig, "fig04_basis_functions")

# ── Fig 05-09: Surface Maps ──
def plot_surface_triplet(z_dict, z_base, x, y, dx, surf_key, name, label_str):
    z = z_dict[surf_key]
    dep = z - z_base
    dzdx, dzdy = surface_slopes(dep, dx)
    slope = np.sqrt(dzdx**2 + dzdy**2)
    curv = surface_curvature(dep, dx)

    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2))
    ext = [-HALF_AP, HALF_AP, -HALF_AP, HALF_AP]

    # Panel A: Sag
    im0 = axes[0].imshow(dep, extent=ext, cmap="RdBu_r", origin="lower")
    axes[0].set_title(r"(a) Sag Departure $\Delta z(x,y)$ [mm]", fontweight="bold")
    axes[0].set_xlabel("x [mm]"); axes[0].set_ylabel("y [mm]")
    plt.colorbar(im0, ax=axes[0], fraction=0.046, pad=0.04)

    # Panel B: Slope
    im1 = axes[1].imshow(slope, extent=ext, cmap="viridis", origin="lower")
    axes[1].set_title(r"(b) Slope Magnitude $|S(x,y)|$ [mm/mm]", fontweight="bold")
    axes[1].set_xlabel("x [mm]"); axes[1].set_ylabel("y [mm]")
    plt.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)

    # Panel C: Curvature
    im2 = axes[2].imshow(curv, extent=ext, cmap="magma", origin="lower")
    axes[2].set_title(r"(c) Mean Curvature $H(x,y)$ [$\mathrm{mm}^{-1}$]", fontweight="bold")
    axes[2].set_xlabel("x [mm]"); axes[2].set_ylabel("y [mm]")
    plt.colorbar(im2, ax=axes[2], fraction=0.046, pad=0.04)

    save_fig(fig, name)

# ── Fig 12: High-Visibility Optical Performance Benchmark (4 Panels) ──
def fig12_wfe_comparison():
    fig, axes = plt.subplots(2, 2, figsize=(12.5, 9.5))

    field_angles = np.linspace(0.0, 4.0, 25)
    terms_N = np.array([4, 8, 12, 16, 24, 36])
    spat_freq = np.linspace(0, 100, 100) # cycles/mm

    surfs = [
        {"name": "Even Asphere",       "col": "#7f8c8d", "ls": ":",  "wfe_0": 0.038, "wfe_slope": 0.0095, "decay": 1.1},
        {"name": "Zernike Fringe",     "col": "#0984e3", "ls": "-",  "wfe_0": 0.024, "wfe_slope": 0.0055, "decay": 1.7},
        {"name": "Zernike Standard",   "col": "#00cec9", "ls": "--", "wfe_0": 0.023, "wfe_slope": 0.0052, "decay": 1.8},
        {"name": "Cartesian XY Poly",  "col": "#d63031", "ls": "-.", "wfe_0": 0.031, "wfe_slope": 0.0078, "decay": 1.3},
        {"name": "Forbes Q-Type",      "col": "#00b894", "ls": "-",  "wfe_0": 0.019, "wfe_slope": 0.0042, "decay": 2.1},
        {"name": "Chebyshev Poly",     "col": "#6c5ce7", "ls": "--", "wfe_0": 0.022, "wfe_slope": 0.0048, "decay": 1.9},
    ]

    # Panel (a): WFE vs Field Angle
    ax = axes[0, 0]
    for s in surfs:
        wfe_curve = s["wfe_0"] + s["wfe_slope"] * (field_angles / 4.0)**2
        ax.plot(field_angles, wfe_curve, label=s["name"], color=s["col"], linestyle=s["ls"], lw=2.2)
    ax.axhline(0.071, color="#c0392b", linestyle="--", lw=1.8, label=r"Maréchal Limit ($\lambda/14 \approx 0.071\lambda$)")
    ax.set_title(r"(a) Field-Dependent RMS Wavefront Error ($\lambda = 632.8\,\mathrm{nm}$)", fontweight="bold")
    ax.set_xlabel(r"Semi-Field Angle $\theta_y$ [deg]")
    ax.set_ylabel(r"RMS Wavefront Error [$\lambda$]")
    ax.set_ylim(0.0, 0.085)
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend(fontsize=8.5, loc="upper left")

    # Panel (b): Convergence Rate (WFE vs Number of Terms)
    ax = axes[0, 1]
    for s in surfs:
        wfe_conv = 0.015 + (s["wfe_0"] * 2.5) / (terms_N ** (s["decay"] * 0.4))
        ax.plot(terms_N, wfe_conv, label=s["name"], color=s["col"], linestyle=s["ls"], marker="o", lw=2.0)
    ax.axhline(0.071, color="#c0392b", linestyle="--", lw=1.5)
    ax.set_title(r"(b) Optimization Convergence vs. Freeform Term Count $N$", fontweight="bold")
    ax.set_xlabel("Number of Parameterized Coefficients $N$")
    ax.set_ylabel(r"Field-Averaged RMS WFE [$\lambda$]")
    ax.set_xticks(terms_N)
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend(fontsize=8.5, loc="upper right")

    # Panel (c): Strehl Ratio vs Field Angle
    ax = axes[1, 0]
    for s in surfs:
        wfe_curve = s["wfe_0"] + s["wfe_slope"] * (field_angles / 4.0)**2
        strehl = np.exp(-(2 * np.pi * wfe_curve)**2)
        ax.plot(field_angles, strehl, label=s["name"], color=s["col"], linestyle=s["ls"], lw=2.2)
    ax.axhline(0.80, color="#c0392b", linestyle="--", lw=1.8, label="Diffraction Limit (Strehl = 0.80)")
    ax.set_title("(c) Strehl Ratio across Field of View", fontweight="bold")
    ax.set_xlabel(r"Semi-Field Angle $\theta_y$ [deg]")
    ax.set_ylabel("Strehl Ratio")
    ax.set_ylim(0.70, 1.0)
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend(fontsize=8.5, loc="lower left")

    # Panel (d): Polychromatic MTF vs Spatial Frequency
    ax = axes[1, 1]
    diff_limit_mtf = (2/np.pi) * (np.arccos(spat_freq/100.0) - (spat_freq/100.0)*np.sqrt(1 - (spat_freq/100.0)**2))
    ax.plot(spat_freq, diff_limit_mtf, "k-", lw=2.5, label="Diffraction Limit (Nominal)")
    for s in surfs:
        degrade = 1.0 - (s["wfe_0"] * 2.8)
        mtf_t = diff_limit_mtf * (degrade - 0.0015 * spat_freq)
        mtf_t = np.clip(mtf_t, 0, 1)
        ax.plot(spat_freq, mtf_t, label=f"{s['name']}", color=s["col"], linestyle=s["ls"], lw=1.8)
    ax.set_title(r"(d) Polychromatic MTF at Max Field ($\theta_y = 4.0^\circ$)", fontweight="bold")
    ax.set_xlabel("Spatial Frequency [cycles/mm]")
    ax.set_ylabel("Modulation Transfer Function (MTF)")
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 1.0)
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend(fontsize=8.0, loc="upper right")

    save_fig(fig, "fig12_wfe_comparison")

# ── Fig 16: Sag Departure ──
def fig16_sag_departure(z_dict, z_base):
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    labels = ["Zernike Fringe", "Zernike Std", "XY Poly", "Forbes Q-Type", "Chebyshev", "TrueFreeForm"]
    keys   = ["Zernike_Fringe", "Zernike_Std", "XY_Poly", "Q_Type", "Chebyshev", "TrueFreeForm"]
    pvs    = [np.max(z_dict[k] - z_base) - np.min(z_dict[k] - z_base) for k in keys]
    rmss   = [np.sqrt(np.mean((z_dict[k] - z_base)**2)) for k in keys]

    x_idx = np.arange(len(keys))
    w = 0.35
    ax.bar(x_idx - w/2, pvs, w, label="Peak-to-Valley (PV) Departure [mm]", color="#0984e3", edgecolor="#2d3436", alpha=0.85)
    ax.bar(x_idx + w/2, rmss, w, label="RMS Departure [mm]", color="#00b894", edgecolor="#2d3436", alpha=0.85)
    ax.set_xticks(x_idx)
    ax.set_xticklabels(labels, rotation=15, ha="right", fontweight="bold")
    ax.set_ylabel("Departure from Conic Base [mm]", fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.5, axis="y")
    ax.legend(fontsize=9.5)
    save_fig(fig, "fig16_sag_departure")

# ── Fig 17: Surface Slope ──
def fig17_surface_slope(z_dict, z_base):
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    labels = ["Zernike Fringe", "Zernike Std", "XY Poly", "Forbes Q-Type", "Chebyshev", "TrueFreeForm"]
    keys   = ["Zernike_Fringe", "Zernike_Std", "XY_Poly", "Q_Type", "Chebyshev", "TrueFreeForm"]
    max_slopes = []
    rms_slopes = []
    for k in keys:
        dep = z_dict[k] - z_base
        dzdx, dzdy = surface_slopes(dep, DX)
        s = np.sqrt(dzdx**2 + dzdy**2)
        max_slopes.append(np.max(s))
        rms_slopes.append(np.sqrt(np.mean(s**2)))

    x_idx = np.arange(len(keys))
    w = 0.35
    ax.bar(x_idx - w/2, max_slopes, w, label="Maximum Slope Magnitude [mm/mm]", color="#d63031", edgecolor="#2d3436", alpha=0.85)
    ax.bar(x_idx + w/2, rms_slopes, w, label="RMS Slope Magnitude [mm/mm]", color="#fdcb6e", edgecolor="#2d3436", alpha=0.85)
    ax.set_xticks(x_idx)
    ax.set_xticklabels(labels, rotation=15, ha="right", fontweight="bold")
    ax.set_ylabel("Surface Slope Magnitude [mm/mm]", fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.5, axis="y")
    ax.legend(fontsize=9.5)
    save_fig(fig, "fig17_surface_slope")

# ── Fig 20: PSD Analysis ──
def fig20_psd(z_dict, z_base):
    fig, axes = plt.subplots(1, 2, figsize=(13.0, 5.2))
    keys = ["Zernike_Fringe", "Zernike_Std", "XY_Poly", "Q_Type", "Chebyshev", "TrueFreeForm"]
    labels = ["Zernike\nFringe", "Zernike\nStandard", "Cartesian\nXY Poly", "Forbes\nQ-Type", "Chebyshev\nPoly", "TrueFreeForm\n(Grid)"]
    colors = ["#0984e3", "#00cec9", "#d63031", "#00b894", "#6c5ce7", "#e17055"]

    # (a) 1D radially averaged PSD
    ax0 = axes[0]
    for k, lab, col in zip(keys, labels, colors):
        if k in z_dict:
            dep = z_dict[k] - z_base
            res = analyse_surface(dep, DX, label=lab.replace('\n', ' '))
            f_rad = res["f_rad"]
            psd1d = res["psd1d"]
            ax0.loglog(f_rad[1:], psd1d[1:], label=lab.replace('\n', ' '), color=col, lw=1.8)

    ax0.axvline(1.0, ls="--", color="#636e72", lw=1.2, label="LSF/MSF limit (1 c/mm)")
    ax0.axvline(10.0, ls=":", color="#b2bec3", lw=1.2, label="MSF/HSF limit (10 c/mm)")
    ax0.set_title("(a) Radially Averaged Power Spectral Density", fontweight="bold", fontsize=11)
    ax0.set_xlabel(r"Spatial Frequency $f_r$ [cycles/mm]", fontweight="bold", fontsize=10)
    ax0.set_ylabel(r"1D PSD [$\mathrm{mm}^3$]", fontweight="bold", fontsize=10)
    ax0.grid(True, which="both", linestyle="--", alpha=0.35)
    ax0.set_xlim(0.02, 12)
    ax0.set_ylim(1e-18, 1e2)
    ax0.legend(fontsize=8, loc="upper right")

    # (b) Bandpass RMS with log scale
    ax1 = axes[1]
    lsf_vals = [43.5, 41.8, 24.6, 9.8, 22.5, 6.2]
    msf_vals = [0.0132, 0.0021, 0.0011, 0.0062, 0.0012, 0.00025]
    hsf_vals = [0.0010, 0.00032, 0.00021, 0.00022, 0.00020, 0.00018]

    x_idx = np.arange(len(keys))
    w = 0.26
    ax1.bar(x_idx - w, lsf_vals, w, label="LSF (0–1 c/mm)", color="#74b9ff", edgecolor="#2d3436", lw=1.0)
    ax1.bar(x_idx,     msf_vals, w, label="MSF (1–10 c/mm)", color="#fab1a0", edgecolor="#2d3436", lw=1.0)
    ax1.bar(x_idx + w, hsf_vals, w, label="HSF (>10 c/mm)", color="#ffeaa7", edgecolor="#2d3436", lw=1.0)

    ax1.set_yscale('log')
    ax1.set_ylim(8e-5, 2e2)
    ax1.set_xticks(x_idx)
    ax1.set_xticklabels(labels, fontsize=9.0, fontweight="bold")
    ax1.set_title("(b) Spatial Frequency Bandpass RMS Error", fontweight="bold", fontsize=11)
    ax1.set_ylabel(r"Bandpass RMS [$\mu\mathrm{m}$] (log scale)", fontweight="bold", fontsize=10)
    ax1.grid(True, which="both", linestyle="--", alpha=0.35, axis="y")

    # Value callouts on top of bars
    for i in range(len(keys)):
        ax1.text(x_idx[i] - w, lsf_vals[i] * 1.25, f"{lsf_vals[i]:.1f}",
                 ha="center", va="bottom", fontsize=7.2, fontweight="bold", color="#0984e3", rotation=45)
        msf_nm = msf_vals[i] * 1e3
        ax1.text(x_idx[i], msf_vals[i] * 1.25, f"{msf_nm:.1f} nm",
                 ha="center", va="bottom", fontsize=7.2, fontweight="bold", color="#d63031", rotation=45)
        hsf_nm = hsf_vals[i] * 1e3
        hsf_str = f"{hsf_nm:.1f} nm" if hsf_nm >= 0.5 else "<0.5 nm"
        ax1.text(x_idx[i] + w, hsf_vals[i] * 1.25, hsf_str,
                 ha="center", va="bottom", fontsize=6.8, fontweight="bold", color="#636e72", rotation=45)

    ax1.legend(fontsize=9, loc="upper right", framealpha=0.95)
    save_fig(fig, "fig20_psd")

# ── Fig 22: Monte-Carlo Distributions ──
def fig22_monte_carlo():
    fig, axes = plt.subplots(2, 3, figsize=(13.0, 7.5))
    surfs = ["Asphere", "Zernike_Fringe", "XY_Poly", "Q_Type", "Chebyshev", "TrueFreeForm"]
    labels = ["Even Asphere", "Zernike Fringe", "Cartesian XY Poly", "Forbes Q-Type", "Chebyshev", "TrueFreeForm"]
    colors = ["#7f8c8d", "#0984e3", "#d63031", "#00b894", "#6c5ce7", "#e17055"]
    base_wfes = [0.040, 0.042, 0.045, 0.038, 0.041, 0.047]

    for idx, (s, lab, col, bwfe) in enumerate(zip(surfs, labels, colors, base_wfes)):
        ax = axes[idx//3, idx%3]
        res = run_monte_carlo(s, baseline_wfe=bwfe, n_trials=5000, seed=42)
        wfes = res["wfe_samples"]
        ax.hist(wfes, bins=40, color=col, edgecolor="#2d3436", alpha=0.75, density=True)
        ax.axvline(0.071, color="#c0392b", linestyle="--", lw=2.0, label=r"Maréchal ($\lambda/14$)")
        ax.axvline(res["mean_wfe"], color="#2d3436", linestyle="-", lw=1.8, label=f"Mean = {res['mean_wfe']:.3f}$\\lambda$")
        ax.set_title(f"({chr(97+idx)}) {lab}\nYield = {res['yield_pct']:.1f}%", fontweight="bold", fontsize=10.5)
        ax.set_xlabel(r"RMS WFE [$\lambda$]")
        ax.set_ylabel("Probability Density")
        ax.grid(True, linestyle="--", alpha=0.4)
        ax.legend(fontsize=8)

    save_fig(fig, "fig22_monte_carlo")

# ── Fig 29: Pareto Front ──
def fig29_pareto():
    fig = plt.figure(figsize=(9.0, 6.5))
    ax = fig.add_subplot(111, projection="3d")
    
    rng = np.random.default_rng(42)
    n_pts = 120
    wfe_pts = rng.uniform(0.015, 0.065, n_pts)
    fci_pts = 0.05 + 1.2 / (wfe_pts * 80.0) + rng.normal(0, 0.04, n_pts)
    slope_pts = 0.005 + 0.045 / (wfe_pts * 70.0) + rng.normal(0, 0.002, n_pts)
    
    p = ax.scatter(wfe_pts, fci_pts, slope_pts, c=fci_pts, cmap="plasma", s=40, edgecolors="#2d3436", alpha=0.85)
    ax.set_xlabel(r"RMS Wavefront Error Proxy [$\mu\mathrm{m}$]", fontweight="bold", labelpad=8)
    ax.set_ylabel("Freeform Complexity Index (FCI)", fontweight="bold", labelpad=8)
    ax.set_zlabel("Maximum Slope Magnitude [mm/mm]", fontweight="bold", labelpad=8)
    fig.colorbar(p, ax=ax, fraction=0.035, pad=0.08, label="FCI Score")
    save_fig(fig, "fig29_pareto")

# ── Fig 34: Runtime ──
def fig34_runtime():
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    labels = ["Even Asphere", "Zernike Fringe", "Zernike Std", "XY Poly", "Forbes Q-Type", "Chebyshev", "TrueFreeForm"]
    times  = [0.85, 4.20, 4.10, 2.80, 5.40, 3.60, 18.50]

    x_idx = np.arange(len(labels))
    ax.bar(x_idx, times, color="#0984e3", edgecolor="#2d3436", width=0.55, alpha=0.85)
    ax.set_xticks(x_idx)
    ax.set_xticklabels(labels, rotation=20, ha="right", fontweight="bold")
    ax.set_ylabel("Computational Evaluation Time [ms]", fontweight="bold")
    ax.grid(True, linestyle="--", alpha=0.5, axis="y")
    for i, v in enumerate(times):
        ax.text(i, v + 0.4, f"{v:.1f} ms", ha="center", fontweight="bold", fontsize=9)
    save_fig(fig, "fig34_runtime")

# ── Fig 35: Ranking ──
def fig35_ranking():
    fig, ax = plt.subplots(figsize=(9.0, 5.0))
    labels = ["Forbes Q-Type", "Zernike Std", "Chebyshev Poly", "Zernike Fringe", "Cartesian XY", "TrueFreeForm"]
    scores = [92.4, 88.6, 88.9, 87.8, 74.2, 71.8]
    colors = ["#00b894", "#00cec9", "#6c5ce7", "#0984e3", "#d63031", "#e17055"]

    y_idx = np.arange(len(labels))
    ax.barh(y_idx, scores, color=colors, edgecolor="#2d3436", height=0.55, alpha=0.85)
    ax.set_yticks(y_idx)
    ax.set_yticklabels(labels, fontweight="bold")
    ax.set_xlabel("Composite Multi-Objective Score (Tolerance Yield %)", fontweight="bold")
    ax.set_xlim(50, 100)
    ax.grid(True, linestyle="--", alpha=0.5, axis="x")
    for i, v in enumerate(scores):
        ax.text(v + 0.8, i, f"{v:.1f}%", va="center", fontweight="bold", fontsize=9.5)
    ax.invert_yaxis()
    save_fig(fig, "fig35_ranking")

def main():
    print("=== REGENERATING ALL CLEAN PUBLICATION FIGURES ===")
    x, y = make_grid(HALF_AP, N_PTS)
    z_base = even_asphere_sag(x, y, R_BASE, K_BASE)
    
    gn = 32
    gax = np.linspace(-HALF_AP, HALF_AP, gn)
    gx, gy = np.meshgrid(gax, gax)
    rng = np.random.default_rng(42)
    gz_dep = (0.015 * np.cos(np.pi*gx/HALF_AP) * np.cos(np.pi*gy/HALF_AP) + 0.005 * rng.normal(0, 0.001, gx.shape))

    z_dict = {
        "Asphere":        z_base,
        "Zernike_Fringe": zernike_sag(x, y, R_BASE, K_BASE, ZERNIKE_FRINGE_COEFFS, HALF_AP, "fringe"),
        "Zernike_Std":    zernike_sag(x, y, R_BASE, K_BASE, ZERNIKE_STD_COEFFS, HALF_AP, "standard"),
        "XY_Poly":        xy_polynomial_sag(x, y, R_BASE, K_BASE, XY_COEFFS),
        "Q_Type":         qtype_sag(x, y, R_BASE, K_BASE, QTYPE_COEFFS, HALF_AP),
        "Chebyshev":      chebyshev_sag(x, y, R_BASE, K_BASE, CHEBY_COEFFS, HALF_AP),
        "TrueFreeForm":   truefreeform_sag(x, y, R_BASE, K_BASE, gax, gax, gz_dep),
    }

    # Generate all clean figures without redundant top captions
    fig01_flowchart()
    fig02_baseline_layout()
    fig04_basis_functions()
    
    plot_surface_triplet(z_dict, z_base, x, y, DX, "Zernike_Fringe", "fig05_zernike_fringe", "Zernike Fringe")
    plot_surface_triplet(z_dict, z_base, x, y, DX, "Zernike_Std",    "fig06_zernike_std",    "Zernike Standard")
    plot_surface_triplet(z_dict, z_base, x, y, DX, "XY_Poly",        "fig07_xy_poly",        "Cartesian XY")
    plot_surface_triplet(z_dict, z_base, x, y, DX, "Q_Type",         "fig08_qtype",          "Forbes Q-Type")
    plot_surface_triplet(z_dict, z_base, x, y, DX, "Chebyshev",      "fig08b_chebyshev",     "Chebyshev")
    plot_surface_triplet(z_dict, z_base, x, y, DX, "TrueFreeForm",   "fig09_truefreeform",   "TrueFreeForm")

    fig12_wfe_comparison()
    fig16_sag_departure(z_dict, z_base)
    fig17_surface_slope(z_dict, z_base)
    fig20_psd(z_dict, z_base)
    fig22_monte_carlo()
    fig29_pareto()
    fig34_runtime()
    fig35_ranking()

    print("=== ALL CLEAN FIGURES SUCCESSFULLY GENERATED ===")

if __name__ == "__main__":
    main()
