﻿"""
freeform_surfaces.py
====================
Mathematically rigorous analytical representations for 7 optical surfaces:
1. Even Asphere (Baseline)
2. Zernike Fringe Sag (Circular orthogonal)
3. Zernike Standard / Noll Sag (Circular orthogonal)
4. Normalized Cartesian XY Polynomials
5. Forbes Q-Type (Q-bfs orthogonal with Jacobi P_m^(0,4) basis)
6. 2D Chebyshev Polynomials (Rectangular orthogonal)
7. TrueFreeForm (Grid Sag with bicubic B-spline interpolation)

All representations are evaluated on normalized pupil coordinates (r_norm = 10.0 mm).
"""

from __future__ import annotations
import numpy as np
from math import factorial
from scipy.interpolate import RectBivariateSpline
from scipy.special import eval_jacobi

def make_grid(half_ap: float = 10.0, n_pts: int = 256):
    axis = np.linspace(-half_ap, half_ap, n_pts)
    return np.meshgrid(axis, axis)

def even_asphere_sag(x: np.ndarray, y: np.ndarray, R: float, k: float = 0.0,
                      asph_coeffs: list[float] | None = None) -> np.ndarray:
    c = 1.0 / R
    r2 = x**2 + y**2
    denom = 1.0 + np.sqrt(np.clip(1.0 - (1.0 + k) * (c**2) * r2, 0.0, None))
    z = (c * r2) / denom
    if asph_coeffs is not None:
        for order, a in enumerate(asph_coeffs):
            p = 2 * (order + 2)
            z = z + a * (r2**(p / 2))
    return z

def zernike_radial(n: int, m: int, rho: np.ndarray) -> np.ndarray:
    m = abs(m)
    if (n - m) % 2 != 0 or n < m:
        return np.zeros_like(rho)
    R = np.zeros_like(rho)
    for s in range((n - m) // 2 + 1):
        num = ((-1)**s) * factorial(n - s)
        den = factorial(s) * factorial((n + m) // 2 - s) * factorial((n - m) // 2 - s)
        R += (num / den) * (rho**(n - 2 * s))
    return R

def zernike_poly(n: int, m: int, rho: np.ndarray, phi: np.ndarray) -> np.ndarray:
    R = zernike_radial(n, abs(m), rho)
    if m >= 0:
        return R * np.cos(m * phi)
    else:
        return R * np.sin(abs(m) * phi)

FRINGE_NM = {
    1:(0,0), 2:(1,1), 3:(1,-1), 4:(2,0), 5:(2,2), 6:(2,-2),
    7:(3,1), 8:(3,-1), 9:(4,0), 10:(3,3), 11:(3,-3), 12:(4,2),
    13:(4,-2), 14:(5,1), 15:(5,-1), 16:(6,0), 17:(4,4), 18:(4,-4),
    19:(5,3), 20:(5,-3), 21:(6,2), 22:(6,-2), 23:(7,1), 24:(7,-1),
    25:(8,0), 26:(5,5), 27:(5,-5), 28:(6,4), 29:(6,-4), 30:(7,3),
    31:(7,-3), 32:(8,2), 33:(8,-2), 34:(9,1), 35:(9,-1), 36:(10,0)
}

def zernike_sag(x: np.ndarray, y: np.ndarray, R: float, k: float,
                coeffs: dict[int, float], norm_radius: float,
                ordering: str = "fringe") -> np.ndarray:
    z_base = even_asphere_sag(x, y, R, k)
    rho = np.clip(np.sqrt(x**2 + y**2) / norm_radius, 0.0, 1.0)
    phi = np.arctan2(y, x)
    z_ff = np.zeros_like(rho)
    for j, a in coeffs.items():
        if ordering == "fringe":
            if j in FRINGE_NM:
                n, m = FRINGE_NM[j]
                z_ff += a * zernike_poly(n, m, rho, phi)
        else: # Standard / Noll
            n = int(np.ceil((-1 + np.sqrt(1 + 8*j))/2) - 1)
            m = 2*j - n*(n+1) - 1
            z_ff += a * zernike_poly(n, m, rho, phi)
    return z_base + z_ff

def xy_polynomial_sag(x: np.ndarray, y: np.ndarray, R: float, k: float,
                      coeffs: dict[tuple[int, int], float],
                      norm_radius: float = 10.0) -> np.ndarray:
    z_base = even_asphere_sag(x, y, R, k)
    # Normalized dimensionless coordinates
    u = np.clip(x / norm_radius, -1.0, 1.0)
    v = np.clip(y / norm_radius, -1.0, 1.0)
    z_ff = sum(a * (u**i) * (v**j) for (i, j), a in coeffs.items())
    return z_base + z_ff

def forbes_qbfs_radial(m: int, u2: np.ndarray) -> np.ndarray:
    """
    Exact Forbes Q-bfs radial basis using Jacobi polynomials P_m^(0,4)(2u^2 - 1).
    Normalized according to Forbes (Opt. Express 2007, 2010).
    """
    if m == 0:
        return np.ones_like(u2)
    # Transform u^2 in [0, 1] to x in [-1, 1]
    x_val = 2.0 * u2 - 1.0
    # Jacobi P_m^(alpha=0, beta=4)(x)
    P_m = eval_jacobi(m, 0, 4, x_val)
    # Orthonormalization factor: sqrt((2m + 5) / 2)
    norm = np.sqrt((2.0 * m + 5.0) / 2.0)
    return P_m * norm

def qtype_sag(x: np.ndarray, y: np.ndarray, R: float, k: float,
              coeffs: dict[int, float], norm_radius: float) -> np.ndarray:
    z_base = even_asphere_sag(x, y, R, k)
    u = np.clip(np.sqrt(x**2 + y**2) / norm_radius, 0.0, 1.0)
    u2 = u**2
    # Boundary prefactor enforcing slope vanishing at vertex and rim
    weight = u2 * (1.0 - u2)
    z_ff = sum(a * weight * forbes_qbfs_radial(int(m), u2) for m, a in coeffs.items() if m > 0)
    return z_base + z_ff

def chebyshev_T(n: int, t: np.ndarray) -> np.ndarray:
    if n == 0: return np.ones_like(t)
    if n == 1: return t.copy()
    T0 = np.ones_like(t)
    T1 = t.copy()
    for _ in range(2, n + 1):
        T2 = 2.0 * t * T1 - T0
        T0, T1 = T1, T2
    return T1

def chebyshev_sag(x: np.ndarray, y: np.ndarray, R: float, k: float,
                  coeffs: dict[tuple[int, int], float], norm_radius: float = 10.0) -> np.ndarray:
    z_base = even_asphere_sag(x, y, R, k)
    tx = np.clip(x / norm_radius, -1.0, 1.0)
    ty = np.clip(y / norm_radius, -1.0, 1.0)
    z_ff = sum(a * chebyshev_T(i, tx) * chebyshev_T(j, ty) for (i, j), a in coeffs.items())
    return z_base + z_ff

def truefreeform_sag(x: np.ndarray, y: np.ndarray, R: float, k: float,
                     grid_x: np.ndarray, grid_y: np.ndarray,
                     grid_z_departure: np.ndarray) -> np.ndarray:
    z_base = even_asphere_sag(x, y, R, k)
    interp = RectBivariateSpline(grid_y, grid_x, grid_z_departure, kx=3, ky=3)
    z_dep = interp.ev(y.ravel(), x.ravel()).reshape(x.shape)
    return z_base + z_dep

def surface_slopes(z: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray]:
    dzdy, dzdx = np.gradient(z, dx, dx)
    return dzdx, dzdy

def surface_curvature(z: np.ndarray, dx: float) -> np.ndarray:
    dzdy, dzdx = np.gradient(z, dx, dx)
    d2zdy2, d2zdxdy = np.gradient(dzdy, dx, dx)
    d2zdydx, d2zdx2 = np.gradient(dzdx, dx, dx)
    num = (1.0 + dzdx**2) * d2zdy2 - 2.0 * dzdx * dzdy * d2zdxdy + (1.0 + dzdy**2) * d2zdx2
    den = 2.0 * (1.0 + dzdx**2 + dzdy**2)**1.5
    return num / np.clip(den, 1e-12, None)
