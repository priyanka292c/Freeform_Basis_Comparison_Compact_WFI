import re

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    content = f.read()

with open('manuscript/bib_80_clean.tex', 'r', encoding='utf-8') as f:
    new_bib = f.read()

bib_pattern = re.compile(r'\\begin\{thebibliography\}.*?\\end\{thebibliography\}', re.DOTALL)
assert bib_pattern.search(content), "Bibliography block not found!"
content = bib_pattern.sub(lambda m: new_bib, content)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated bibliography in manuscript/main.tex successfully!")
