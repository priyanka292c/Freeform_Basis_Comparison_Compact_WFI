import json
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('python/verified_80_clean.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Total entries: {len(data)}")
for i, item in enumerate(data, 1):
    print(f"{i:02d}: {item['key']:20s} | {item['year']} | {item.get('journal', 'N/A')[:25]:25s} | {item['title'][:45]}")
