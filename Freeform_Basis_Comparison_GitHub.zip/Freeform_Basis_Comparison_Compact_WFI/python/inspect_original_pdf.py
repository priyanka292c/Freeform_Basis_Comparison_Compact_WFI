import pypdf
import sys
sys.stdout.reconfigure(encoding='utf-8')

reader = pypdf.PdfReader('supplementary/main_manuscript.pdf')
for p in [8, 9, 10]:
    print(f"=== PAGE {p} ===")
    text = reader.pages[p-1].extract_text()
    for line in text.split('\n')[:10]:
        print("  ", line)
    print("   ...")
    for line in text.split('\n')[-6:]:
        print("  ", line)
