# Reference Verification Report

**Total references parsed:** 80  
**Verified OK (DOI resolves, title matches):** 80  
**Failed / Issues:** 0  

## Summary of Issues

| Category | Count |
|---|---|
| ✅ OK | 80 |
| ❌ Title mismatch (wrong paper for that DOI) | 0 |
| ❌ DOI not found in CrossRef | 0 |
| ❌ Year mismatch | 0 |
| ❌ No DOI provided | 0 |
| ❌ arXiv DOI | 0 |

---

## Problematic References (need replacement)

---

## All References Status

| # | Key | Status | Issues |
|---|---|---|---|
| 1 | `Rolland2021` | ✅ OK | — |
| 2 | `Forbes2007` | ✅ OK | — |
| 3 | `Forbes2010` | ✅ OK | — |
| 4 | `Forbes2012` | ✅ OK | — |
| 5 | `Thompson2005` | ✅ OK | — |
| 6 | `Thompson2009` | ✅ OK | — |
| 7 | `Thompson2012` | ✅ OK | — |
| 8 | `Zernike1934` | ✅ OK | — |
| 9 | `Noll1976` | ✅ OK | — |
| 10 | `Lakshminarayanan2011` | ✅ OK | — |
| 11 | `Fuerschbach2011` | ✅ OK | — |
| 12 | `Fuerschbach2014` | ✅ OK | — |
| 13 | `Sasian2010` | ✅ OK | — |
| 14 | `Gross2021` | ✅ OK | — |
| 15 | `Bauer2015` | ✅ OK | — |
| 16 | `Cakmakci2008` | ✅ OK | — |
| 17 | `Zhong2017` | ✅ OK | — |
| 18 | `Papa2018` | ✅ OK | — |
| 19 | `Meng2019` | ✅ OK | — |
| 20 | `Yang2017LSA` | ✅ OK | — |
| 21 | `Tan2026OLT` | ✅ OK | — |
| 22 | `Zhang2021OE` | ✅ OK | — |
| 23 | `Nie2020AO` | ✅ OK | — |
| 24 | `Huang2018OLT` | ✅ OK | — |
| 25 | `Zhu2019Optica` | ✅ OK | — |
| 26 | `Qin2022OLT` | ✅ OK | — |
| 27 | `Li2023OLT` | ✅ OK | — |
| 28 | `Beier2012` | ✅ OK | — |
| 29 | `Cheng2023OLT` | ✅ OK | — |
| 30 | `Liu2011OE` | ✅ OK | — |
| 31 | `Forbes2013` | ✅ OK | — |
| 32 | `Bauer2018NatComm` | ✅ OK | — |
| 33 | `Bauer2018` | ✅ OK | — |
| 34 | `Chen2025OE` | ✅ OK | — |
| 35 | `Mahajan2013` | ✅ OK | — |
| 36 | `Dai2012` | ✅ OK | — |
| 37 | `Zheng2020AO` | ✅ OK | — |
| 38 | `Wang2025OE` | ✅ OK | — |
| 39 | `Zhu2017AO` | ✅ OK | — |
| 40 | `Guenther2019OLT` | ✅ OK | — |
| 41 | `Hou2022OLT` | ✅ OK | — |
| 42 | `Cardenas2023` | ✅ OK | — |
| 43 | `Barakat1980` | ✅ OK | — |
| 44 | `Upton2008` | ✅ OK | — |
| 45 | `Aikens2008` | ✅ OK | — |
| 46 | `Youngworth2000` | ✅ OK | — |
| 47 | `Tamkin2010` | ✅ OK | — |
| 48 | `Harvey2012` | ✅ OK | — |
| 49 | `Fang2013` | ✅ OK | — |
| 50 | `Scheiding2011` | ✅ OK | — |
| 51 | `Zhang2019CIRP` | ✅ OK | — |
| 52 | `Brinksmeier2012` | ✅ OK | — |
| 53 | `Gao2019PE` | ✅ OK | — |
| 54 | `Shore2011` | ✅ OK | — |
| 55 | `Beaucamp2017` | ✅ OK | — |
| 56 | `Gong2021OLT` | ✅ OK | — |
| 57 | `Liu2022OLT` | ✅ OK | — |
| 58 | `Zhu2023PE` | ✅ OK | — |
| 59 | `Guo2024OE` | ✅ OK | — |
| 60 | `Zhao2020OLT` | ✅ OK | — |
| 61 | `Wang2024OLT` | ✅ OK | — |
| 62 | `Xu2023OLT` | ✅ OK | — |
| 63 | `Chen2021OE` | ✅ OK | — |
| 64 | `Shi2021OLT` | ✅ OK | — |
| 65 | `Kim2021OE` | ✅ OK | — |
| 66 | `ISO10110` | ✅ OK | — |
| 67 | `Howard2013` | ✅ OK | — |
| 68 | `Rogers2014` | ✅ OK | — |
| 69 | `Ruda2007` | ✅ OK | — |
| 70 | `Song2022OLT` | ✅ OK | — |
| 71 | `Zhang2023OE` | ✅ OK | — |
| 72 | `Duparre2002` | ✅ OK | — |
| 73 | `DeGroote2012` | ✅ OK | — |
| 74 | `Nelson2014` | ✅ OK | — |
| 75 | `Deb2002` | ✅ OK | — |
| 76 | `Houllier2019` | ✅ OK | — |
| 77 | `Hou2020` | ✅ OK | — |
| 78 | `Wu2023OLT` | ✅ OK | — |
| 79 | `Li2024LSA` | ✅ OK | — |
| 80 | `Zhu2025OLT` | ✅ OK | — |
