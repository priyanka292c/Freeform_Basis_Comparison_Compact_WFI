import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Spacing tweaks in preamble and abstract
tex = tex.replace(r'\vspace{0.4em}' + '\n' + r'\noindent\textbf{Keywords:}',
                  r'\vspace{0.1em}' + '\n' + r'\noindent\textbf{Keywords:}')
tex = tex.replace(r'\vspace{0.5em}' + '\n' + r'\noindent\textbf{Highlights}',
                  r'\vspace{0.2em}' + '\n' + r'\noindent\textbf{Highlights}')

# 2. Table row stretch
if r'\renewcommand{\arraystretch}' not in tex:
    tex = tex.replace(r'\begin{document}', r'\renewcommand{\arraystretch}{0.90}' + '\n' + r'\begin{document}')

# 3. Figure widths
fig_scales = [
    (r'\includegraphics[width=0.78\textwidth]{../figures/source/fig01_flowchart.png}',
     r'\includegraphics[width=0.70\textwidth]{../figures/source/fig01_flowchart.png}'),
    (r'\includegraphics[width=0.78\textwidth]{../figures/source/fig02_baseline_layout.png}',
     r'\includegraphics[width=0.70\textwidth]{../figures/source/fig02_baseline_layout.png}'),
    (r'\includegraphics[width=0.80\textwidth]{../figures/source/fig12_wfe_comparison.png}',
     r'\includegraphics[width=0.72\textwidth]{../figures/source/fig12_wfe_comparison.png}'),
    (r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig16_sag_departure.png}',
     r'\includegraphics[width=0.64\columnwidth]{../figures/source/fig16_sag_departure.png}'),
    (r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig17_surface_slope.png}',
     r'\includegraphics[width=0.64\columnwidth]{../figures/source/fig17_surface_slope.png}'),
    (r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig20_psd.png}',
     r'\includegraphics[width=0.64\columnwidth]{../figures/source/fig20_psd.png}'),
    (r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig22_monte_carlo.png}',
     r'\includegraphics[width=0.64\columnwidth]{../figures/source/fig22_monte_carlo.png}'),
    (r'\includegraphics[width=0.68\columnwidth]{../figures/source/fig29_pareto.png}',
     r'\includegraphics[width=0.62\columnwidth]{../figures/source/fig29_pareto.png}'),
    (r'\includegraphics[width=0.66\columnwidth]{../figures/source/fig34_runtime.png}',
     r'\includegraphics[width=0.62\columnwidth]{../figures/source/fig34_runtime.png}'),
    (r'\includegraphics[width=0.66\columnwidth]{../figures/source/fig35_ranking.png}',
     r'\includegraphics[width=0.62\columnwidth]{../figures/source/fig35_ranking.png}'),
]

for o, n in fig_scales:
    if o in tex:
        tex = tex.replace(o, n)

# 4. Bibliography font
old_bib = re.search(r'\\begin\{thebibliography\}\{80\}.*?(?=\\bibitem)', tex, re.DOTALL)
if old_bib:
    new_bib = r"""\begin{thebibliography}{80}
\fontsize{4.3pt}{4.9pt}\selectfont
\setlength{\itemsep}{-1.5pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}
"""
    tex = tex[:old_bib.start()] + new_bib + tex[old_bib.end():]

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex. Compiling two passes...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
