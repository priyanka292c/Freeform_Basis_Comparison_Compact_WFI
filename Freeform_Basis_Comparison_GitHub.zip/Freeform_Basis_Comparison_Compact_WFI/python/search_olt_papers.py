import urllib.request
import urllib.parse
import json
import time

def search_papers():
    queries = [
        "Optics and Laser Technology freeform optical design",
        "Optics and Laser Technology freeform mirror",
        "Optics and Laser Technology freeform surface measurement",
        "Optics and Lasers in Engineering freeform surface metrology deflectometry",
        "Precision Engineering freeform diamond turning tool path",
        "Optics Express freeform tolerance analysis Monte Carlo",
        "Applied Optics freeform three mirror anastigmat",
        "Light Science and Applications freeform optics review",
        "Journal of Astronomical Telescopes Instruments Systems freeform off-axis",
        "Optics Express Forbes Q-type orthogonal polynomials freeform",
        "Optics Express Chebyshev polynomials freeform optical design",
        "Applied Optics Zernike polynomials freeform surface representation",
        "Optics Express mid spatial frequency power spectral density freeform",
        "Optics Express NSGA-II multiobjective optical design Pareto"
    ]
    
    candidates = {}
    
    for q in queries:
        url = "https://api.crossref.org/works?query=" + urllib.parse.quote(q) + "&rows=8"
        req = urllib.request.Request(url, headers={'User-Agent': 'OpticsBenchmark/1.0 (mailto:priyanka.s@research.org)'})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                for it in data['message']['items']:
                    doi = it.get('DOI', '').strip()
                    if not doi or 'arxiv' in doi.lower():
                        continue
                    title = it.get('title', [''])[0].strip()
                    container = it.get('container-title', [''])[0].strip()
                    year = it.get('issued', {}).get('date-parts', [[None]])[0][0]
                    authors = [a.get('family', '') for a in it.get('author', []) if a.get('family')]
                    vol = it.get('volume', '')
                    page = it.get('page', it.get('article-number', ''))
                    
                    # Filter out books or non-relevant items
                    if not title or not authors or not year:
                        continue
                    
                    if doi not in candidates:
                        candidates[doi] = {
                            'doi': doi,
                            'title': title,
                            'journal': container,
                            'year': year,
                            'authors': authors,
                            'vol': vol,
                            'page': page
                        }
            print(f"Query '{q[:35]}...' completed. Total unique: {len(candidates)}", flush=True)
            time.sleep(0.4)
        except Exception as e:
            print(f"Error for '{q[:30]}': {e}", flush=True)
            
    with open('python/candidates_retrieved.json', 'w', encoding='utf-8') as f:
        json.dump(candidates, f, indent=2)
    print(f"Saved {len(candidates)} verified candidate papers to python/candidates_retrieved.json", flush=True)

if __name__ == '__main__':
    search_papers()
