"""
semantic_ref_check.py
Checks whether each reference is actually relevant to freeform optics/optical design.
Uses CrossRef to get the real title and compares with what the bibitem key claims.
Flags references where the actual paper topic doesn't match freeform/optics context.
"""
import re, json, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Load the JSON verification report (already has CrossRef titles)
with open("python/reference_verification_report.json", "r", encoding="utf-8") as f:
    results = json.load(f)

# Keywords that indicate freeform/optical-design relevance
OPTICS_KEYWORDS = {
    "freeform", "optical", "optics", "lens", "mirror", "aberration", "wavefront",
    "surface", "imaging", "asphere", "polynomial", "zernike", "chebyshev", "forbes",
    "pupil", "aperture", "telescope", "spectrometer", "reflective", "refractive",
    "ray", "trace", "mid-spatial", "roughness", "scatter", "toleranc", "manufacturing",
    "precision", "diamond", "polishing", "interferometry", "metrology", "deflectometry",
    "measurement", "phase", "pareto", "nsga", "optimization", "genetic", "design",
    "depth", "curvature", "slope", "sag", "basis", "orthogonal", "expansion",
    "coordinate", "mapping", "node", "noll", "fringe", "cartesian", "monomial",
    "spatial frequency", "psd", "power spectral", "iso 10110", "drawing", "standard",
    "coating", "scatter", "field", "focal", "pupil", "conic", "aspheric",
    "wfe", "rms", "strehl", "mtf", "psf", "spectral", "band", "diffraction"
}

# Keywords that strongly indicate NON-optics content
NONOPTICS_KEYWORDS = {
    "fiber laser", "fiber bragg", "liquid crystal", "hydrophobic", "titanium alloy",
    "additive manufacturing", "terahertz", "bessel beam", "salinity", "seawater",
    "soliton", "amplifier", "cladding", "coherent combin", "polymer degradation",
    "air bearing", "vibration cutting", "function recommender", "dental crown",
    "product life cycle", "elastic modulus", "cladding coating", "glass drilling",
    "anisotropic axicon", "optoelectronic tweez", "silica hybrid film"
}

print("=" * 70)
print("SEMANTIC RELEVANCE CHECK FOR FREEFORM OPTICS PAPER")
print("=" * 70)

suspicious = []
ok_count = 0

for r in results:
    # Combine tex title + crossref title for analysis
    combined = (r.get("title_tex", "") + " " + r.get("cr_title", "") + " " + r.get("cr_journal", "")).lower()
    
    has_optics = any(kw in combined for kw in OPTICS_KEYWORDS)
    has_nonoptics = any(kw in combined for kw in NONOPTICS_KEYWORDS)
    
    if has_nonoptics or not has_optics:
        flag = "NONOPTICS" if has_nonoptics else "POSSIBLY_OFF_TOPIC"
        suspicious.append({
            "num": r["num"],
            "key": r["key"],
            "flag": flag,
            "tex_title": r.get("title_tex", "")[:100],
            "cr_title": r.get("cr_title", "")[:100],
            "cr_journal": r.get("cr_journal", "")[:60],
            "cr_year": r.get("cr_year"),
            "doi": r.get("doi", ""),
        })
        print(f"[{r['num']:02d}] *** {flag} ***")
        print(f"     Key: {r['key']}")
        print(f"     TEX: {r.get('title_tex','')[:90]}")
        print(f"     CR : {r.get('cr_title','')[:90]}")
        print(f"     DOI: {r.get('doi','')}")
        print()
    else:
        ok_count += 1

print("=" * 70)
print(f"TOPICALLY RELEVANT: {ok_count}")
print(f"SUSPICIOUS / OFF-TOPIC: {len(suspicious)}")
print("=" * 70)

# Save suspicious list
with open("python/semantic_check_report.json", "w", encoding="utf-8") as f:
    json.dump(suspicious, f, indent=2, ensure_ascii=False)
print(f"\nSaved: python/semantic_check_report.json")
