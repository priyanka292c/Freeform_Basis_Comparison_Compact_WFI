import json

with open(r'C:\Users\I7\.gemini\antigravity-ide\brain\c164dfa0-3104-4e46-874d-3ced51071590\.system_generated\logs\transcript.jsonl', 'r', encoding='utf-8') as f:
    for i, line in enumerate(f):
        data = json.loads(line)
        if data.get('type') == 'USER_INPUT':
            content = data.get('content', '')
            for term in ['generative ai', 'declaration', 'ai contents', 'artificial intelligence', 'use of ai', 'ai statement']:
                if term in content.lower():
                    print(f'Match on "{term}" at step {i}:')
                    safe_c = content.encode('ascii', errors='replace').decode('ascii')
                    for line_c in safe_c.split('\n')[:15]:
                        print('  ', line_c)
                    print('='*50)
