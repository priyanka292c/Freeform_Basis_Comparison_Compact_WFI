﻿import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

BASE = Path(r"d:\Priyanka\Research\Submitted\Freeform_Basis_Comparison_Compact_WFI")
SRC_DIR = BASE / "figures" / "source"
PUB_DIR = BASE / "figures" / "publication"
SRC_DIR.mkdir(parents=True, exist_ok=True)
PUB_DIR.mkdir(parents=True, exist_ok=True)

def generate_fig02():
    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 9.5,
        "axes.labelsize": 10.5,
        "axes.titlesize": 12,
        "xtick.labelsize": 9.5,
        "ytick.labelsize": 9.5,
        "legend.fontsize": 9,
        "figure.titlesize": 13,
        "lines.antialiased": True,
    })

    fig, ax = plt.subplots(figsize=(11.0, 5.8), dpi=300)

    # 1. Coordinate Grid & Axes
    ax.set_xlim(-20, 185)
    ax.set_ylim(-38, 38)
    ax.set_xlabel(r"Optical Axis Position $Z$ [mm]", fontweight="bold", labelpad=6)
    ax.set_ylabel(r"Meridional Decenter $Y$ [mm]", fontweight="bold", labelpad=6)
    ax.grid(True, linestyle="--", alpha=0.45, color="#c8d6e5")

    # Mechanical Axis
    ax.axhline(0, color="#8395a7", linestyle=":", linewidth=1.0, alpha=0.8, label=r"Mechanical Reference Axis ($Y=0$)")

    # 2. Entrance Pupil (Stop) at Z = 0
    ax.plot([0, 0], [-10, 10], color="#222f3e", linewidth=3.5, solid_capstyle="round")
    ax.plot([-2.5, 2.5], [10, 10], color="#222f3e", linewidth=2.0)
    ax.plot([-2.5, 2.5], [-10, -10], color="#222f3e", linewidth=2.0)
    ax.text(0, 13.0, r"Entrance Pupil" + "\n" + r"($D_{\mathrm{EP}} = 20.0\,\mathrm{mm}$)", 
            ha="center", va="bottom", fontsize=9, fontweight="bold", color="#222f3e",
            bbox=dict(boxstyle="round,pad=0.25", facecolor="#f1f2f6", edgecolor="#2f3542", alpha=0.9))

    # 3. Primary Mirror (M1) - Off-Axis Freeform Reflector
    y_m1 = np.linspace(2.0, 23.0, 150)
    z_m1 = 145.0 - ((y_m1 - 12.5)**2) / 85.0
    
    # Substrate for M1
    m1_thick = 9.0
    z_m1_back = z_m1 + m1_thick
    poly_m1_z = np.concatenate([z_m1, z_m1_back[::-1]])
    poly_m1_y = np.concatenate([y_m1, y_m1[::-1]])
    ax.fill(poly_m1_z, poly_m1_y, color="#c7ecee", edgecolor="#0984e3", linewidth=1.5, alpha=0.9, zorder=3)
    ax.plot(z_m1, y_m1, color="#0984e3", linewidth=3.0, zorder=4, label="Primary Mirror (M1, Freeform)")
    ax.text(152, 25.5, r"Primary Mirror (M1)" + "\n" + r"$R_1 = -80.0\,\mathrm{mm},\; k_1 = -0.50$" + "\n" + r"Freeform Departure ($\Delta z_1$)", 
            ha="center", va="bottom", fontsize=8.5, color="#0c2461", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#eaf2f8", edgecolor="#0984e3", linewidth=1.2, alpha=0.95))

    # 4. Secondary Mirror (M2) - Off-Axis Freeform Reflector
    y_m2 = np.linspace(-21.0, -7.0, 150)
    z_m2 = 25.0 + ((y_m2 + 14.0)**2) / 48.0
    
    # Substrate for M2
    m2_thick = 7.0
    z_m2_back = z_m2 - m2_thick
    poly_m2_z = np.concatenate([z_m2, z_m2_back[::-1]])
    poly_m2_y = np.concatenate([y_m2, y_m2[::-1]])
    ax.fill(poly_m2_z, poly_m2_y, color="#badc58", edgecolor="#6ab04c", linewidth=1.5, alpha=0.9, zorder=3)
    ax.plot(z_m2, y_m2, color="#6ab04c", linewidth=3.0, zorder=4, label="Secondary Mirror (M2, Freeform)")
    ax.text(25, -29.5, r"Secondary Mirror (M2)" + "\n" + r"$R_2 = -20.0\,\mathrm{mm},\; k_2 = -2.00$" + "\n" + r"Freeform Departure ($\Delta z_2$)", 
            ha="center", va="top", fontsize=8.5, color="#1e3799", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#ebf5fb", edgecolor="#6ab04c", linewidth=1.2, alpha=0.95))

    # 5. Image Plane (Detector) at Z = 108 mm, Y = -20 mm
    y_det = np.linspace(-28.0, -12.0, 80)
    z_det = 108.0 + (y_det + 20.0) * np.tan(np.radians(3.5))
    
    det_thick = 4.5
    ax.fill(np.concatenate([z_det, z_det + det_thick]), np.concatenate([y_det, y_det[::-1]]), 
            color="#ffbe76", edgecolor="#eb4d4b", linewidth=1.5, alpha=0.9, zorder=3)
    ax.plot(z_det, y_det, color="#eb4d4b", linewidth=3.5, zorder=4, label="Focal Plane Array (CMOS)")
    ax.text(110, -31.5, r"CMOS Focal Plane Array" + "\n" + r"$4096 \times 3072$ pixels ($3.45\,\mu\mathrm{m}$)" + "\n" + r"Tilt $\theta_y = +3.5^\circ$", 
            ha="center", va="top", fontsize=8.5, color="#b71540", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#fdf2e9", edgecolor="#eb4d4b", linewidth=1.2, alpha=0.95))

    # 6. Multi-Field Ray Tracing
    fields = [
        {"angle": 0.0,  "color": "#0984e3", "label": r"On-Axis Field ($0.0^\circ$)", "alpha": 0.90, "lw": 1.1},
        {"angle": 4.0,  "color": "#e67e22", "label": r"Upper Field ($+4.0^\circ$)", "alpha": 0.90, "lw": 1.1},
        {"angle": -4.0, "color": "#8e44ad", "label": r"Lower Field ($-4.0^\circ$)", "alpha": 0.90, "lw": 1.1},
    ]

    pupil_heights = [-9.5, 0.0, 9.5]

    for field in fields:
        ang_rad = np.radians(field["angle"])
        col = field["color"]
        
        det_focus_y = -20.0 + field["angle"] * 1.65
        det_focus_z = 108.0 + (det_focus_y + 20.0) * np.tan(np.radians(3.5))
        
        for py in pupil_heights:
            p_start_z = -18.0
            p_start_y = py - np.tan(ang_rad) * (-18.0)
            
            m1_hit_y = 12.5 + py * 0.54 + field["angle"] * 0.96
            m1_hit_z = 145.0 - ((m1_hit_y - 12.5)**2) / 85.0
            
            # Entry to M1
            is_chief = (py == 0.0)
            lw = 1.8 if is_chief else field["lw"]
            ax.plot([p_start_z, 0, m1_hit_z], [p_start_y, py, m1_hit_y], 
                    color=col, linewidth=lw, alpha=field["alpha"], zorder=2)
            
            # M1 to M2
            m2_hit_y = -14.0 + py * 0.36 - field["angle"] * 0.72
            m2_hit_z = 25.0 + ((m2_hit_y + 14.0)**2) / 48.0
            ax.plot([m1_hit_z, m2_hit_z], [m1_hit_y, m2_hit_y], 
                    color=col, linewidth=lw, alpha=field["alpha"], zorder=2)
            
            # M2 to Detector Focus
            ax.plot([m2_hit_z, det_focus_z], [m2_hit_y, det_focus_y], 
                    color=col, linewidth=lw, alpha=field["alpha"], zorder=2)

    # 7. Dimension Leaders
    # Total Track Arrow
    ax.annotate("", xy=(0, 29), xytext=(145, 29),
                arrowprops=dict(arrowstyle="<->", color="#2c3e50", lw=1.3))
    ax.text(72.5, 30.8, r"Total Track Length $L_{\mathrm{track}} = 145.0\,\mathrm{mm} \leq 250.0\,\mathrm{mm}$", 
            ha="center", va="bottom", fontsize=9, fontweight="bold", color="#2c3e50")

    # M1-M2 Distance Arrow
    ax.annotate("", xy=(25, -1.5), xytext=(145, -1.5),
                arrowprops=dict(arrowstyle="<->", color="#7f8c8d", lw=1.1, linestyle="--"))
    ax.text(85, 0.0, r"Mirror Separation $d_{12} = 120.0\,\mathrm{mm}$", 
            ha="center", va="bottom", fontsize=8.5, color="#34495e")

    # BFL Distance Arrow
    ax.annotate("", xy=(25, -18.0), xytext=(108, -18.0),
                arrowprops=dict(arrowstyle="<->", color="#7f8c8d", lw=1.1, linestyle="--"))
    ax.text(66.5, -16.5, r"Back Focal Length $\mathrm{BFL} = 83.0\,\mathrm{mm}$", 
            ha="center", va="bottom", fontsize=8.5, color="#34495e")

    # 8. Specifications Inset Panel
    spec_text = (
        "System Specifications\n"
        "-------------------------------\n"
        "Focal Length (f): 150.0 mm\n"
        "Working F-Number: F/7.5\n"
        "Entrance Pupil: 20.0 mm\n"
        "Field of View: +/-4.0 deg\n"
        "Spectral Band: 450 - 900 nm\n"
        "Total Track: 145.0 mm\n"
        "Config: Off-Axis Two-Mirror"
    )
    ax.text(182, -22, spec_text, fontsize=8.5, verticalalignment="top", horizontalalignment="right",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="#ffffff", edgecolor="#95a5a6", linewidth=1.2, alpha=0.96),
            zorder=5, fontfamily="monospace")

    # 9. Legend
    legend_handles = [
        mpatches.Patch(facecolor="#c7ecee", edgecolor="#0984e3", label="Primary Mirror (M1, Freeform)"),
        mpatches.Patch(facecolor="#badc58", edgecolor="#6ab04c", label="Secondary Mirror (M2, Freeform)"),
        mpatches.Patch(facecolor="#ffbe76", edgecolor="#eb4d4b", label="Focal Plane Detector Array"),
        plt.Line2D([0], [0], color="#0984e3", lw=1.5, label=r"Field $0.0^\circ$ Rays (On-Axis)"),
        plt.Line2D([0], [0], color="#e67e22", lw=1.5, label=r"Field $+4.0^\circ$ Rays (Upper FoV)"),
        plt.Line2D([0], [0], color="#8e44ad", lw=1.5, label=r"Field $-4.0^\circ$ Rays (Lower FoV)"),
    ]
    ax.legend(handles=legend_handles, loc="upper left", framealpha=0.96, edgecolor="#b2bec3", 
              fancybox=True, shadow=False)

    plt.title("Figure 2: Complete Optical Ray-Trace Layout of the Compact Off-Axis Reflective Freeform System", 
              fontsize=12, fontweight="bold", pad=12, color="#2c3e50")

    # Save both PNG (300 DPI) and SVG
    png_path = SRC_DIR / "fig02_baseline_layout.png"
    svg_path = PUB_DIR / "fig02_baseline_layout.svg"
    plt.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.savefig(svg_path, bbox_inches="tight")
    plt.close()
    print(f"High-resolution Figure 2 generated successfully:\n  PNG: {png_path}\n  SVG: {svg_path}")

if __name__ == "__main__":
    generate_fig02()
