﻿from pathlib import Path

# Let's inspect plotting.py to see all figure generators
plot_py = Path(r"d:\Priyanka\Research\Submitted\Freeform_Basis_Comparison_Compact_WFI\python\plotting.py")
print("plotting.py exists:", plot_py.exists())
