import json
import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

journal_abbrevs = {
    "Optics & Laser Technology": "Opt. Laser Technol.",
    "Optics Express": "Opt. Express",
    "Applied Optics": "Appl. Opt.",
    "Precision Engineering": "Precis. Eng.",
    "CIRP Annals": "CIRP Ann.",
    "Light: Science & Applications": "Light Sci. Appl.",
    "Light: Advanced Manufacturing": "Light Adv. Manuf.",
    "Journal of the Optical Society of America A": "J. Opt. Soc. Am. A",
    "Journal of the Optical Society of America": "J. Opt. Soc. Am.",
    "Optics Letters": "Opt. Lett.",
    "Optics Communications": "Opt. Commun.",
    "Optical Engineering": "Opt. Eng.",
    "Optics and Photonics News": "Opt. Photonics News",
    "Nature Communications": "Nat. Commun.",
    "IEEE Transactions on Evolutionary Computation": "IEEE Trans. Evol. Comput.",
    "Journal of Modern Optics": "J. Mod. Opt.",
    "Journal of Advanced Mechanical Design, Systems, and Manufacturing": "J. Adv. Mech. Des. Syst. Manuf.",
    "Physica": "Physica",
    "Frontiers in Optics 2008/Laser Science XXIV/Plasmonics and Metamaterials/Optical Fabrication and Testing": "Proc. FiO/OFT",
    "Optical Design and Fabrication 2019 (Freeform, OFT)": "Proc. OFT",
    "SPIE Proceedings": "Proc. SPIE",
    "SPIE Newsroom": "SPIE Newsroom"
}

def format_compact_authors(author_str):
    # Split authors
    # If "et al." already in it
    if "et al." in author_str:
        return author_str
    # Split by comma or " and "
    parts = re.split(r',\s*and\s*|,\s*|\s+and\s+', author_str)
    parts = [p.strip() for p in parts if p.strip()]
    if len(parts) > 2:
        return f"{parts[0]} et al."
    elif len(parts) == 2:
        return f"{parts[0]} and {parts[1]}"
    elif len(parts) == 1:
        return parts[0]
    return author_str

bib_lines = []
bib_lines.append(r"\begin{thebibliography}{80}")
bib_lines.append(r"\fontsize{4.8pt}{5.6pt}\selectfont")
bib_lines.append(r"\setlength{\itemsep}{-0.8pt}")
bib_lines.append(r"\setlength{\parskip}{0pt}")
bib_lines.append(r"\setlength{\parsep}{0pt}")
bib_lines.append("")

for it in data:
    authors = format_compact_authors(it['authors'])
    title = it['title']
    
    # Abbreviate journal
    raw_j = it['journal'].replace(r'\&', '&')
    j_abbr = journal_abbrevs.get(raw_j, raw_j)
    j_abbr = j_abbr.replace('&', r'\&')
    
    vol = it['volume']
    page = it['page']
    year = it['year']
    doi = it['doi']
    
    # Format: A. Author et al., ``Title,'' \textit{J. Abbr.} \textbf{V}, P (Y). \doi{DOI}
    vol_part = f"\\textbf{{{vol}}}, " if vol else ""
    page_part = f"{page} " if page else ""
    year_part = f"({year})" if year else ""
    
    entry = (
        f"\\bibitem{{{it['key']}}}\n"
        f"{authors}, ``{title},'' \\textit{{{j_abbr}}} {vol_part}{page_part}{year_part}. \\doi{{{doi}}}\n"
    )
    bib_lines.append(entry)

bib_lines.append(r"\end{thebibliography}")

compact_bib_text = "\n".join(bib_lines)

with open('manuscript/bib_80_clean.tex', 'w', encoding='utf-8') as f:
    f.write(compact_bib_text)

# Update in main.tex
with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

bib_pattern = re.compile(r'\\begin\{thebibliography\}.*?\\end\{thebibliography\}', re.DOTALL)
tex = bib_pattern.sub(lambda m: compact_bib_text, tex)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Updated main.tex with compact standard bibliography! Compiling...")

for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
