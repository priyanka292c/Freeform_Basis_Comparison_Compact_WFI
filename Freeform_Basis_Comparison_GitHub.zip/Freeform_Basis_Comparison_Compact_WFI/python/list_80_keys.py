import json

with open('python/verified_80_clean.json', 'r', encoding='utf-8') as f:
    clean_refs = json.load(f)

for i, item in enumerate(clean_refs):
    k = item['key']
    y = item.get('year', '')
    j = item.get('journal', '')[:25]
    t = item.get('title', '')[:35]
    print(f"[{i+1:2d}] {k:18s} | {y} | {j:25s} | {t}")
