import json

with open('python/candidates_retrieved.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Total candidates: {len(data)}")
olt_count = sum(1 for v in data.values() if 'laser' in v['journal'].lower())
print(f"Optics & Laser Technology papers: {olt_count}")
recent_count = sum(1 for v in data.values() if v.get('year') and v['year'] >= 2018)
print(f"Recent papers (>= 2018): {recent_count}")

for i, (k, v) in enumerate(list(data.items())[:12]):
    print(f"[{i+1}] {v.get('year')} | {v.get('journal')[:30]} | {v.get('title')[:45]} | {v.get('doi')}")
