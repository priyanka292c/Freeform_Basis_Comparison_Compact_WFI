import json
import re

# Load verified 80 clean references
with open('python/verified_80_clean.json', 'r', encoding='utf-8') as f:
    clean_refs = json.load(f)

print(f"Loaded {len(clean_refs)} verified references.")

def format_clean_bib(items):
    lines = []
    lines.append("\\begin{thebibliography}{80}")
    lines.append("\\setlength{\\itemsep}{0pt plus 0.1pt}")
    lines.append("\\setlength{\\parskip}{0pt}")
    lines.append("\\scriptsize")
    
    for item in items:
        key = item['key']
        title = item.get('title', '').strip()
        # Clean title
        title = title.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
        title = title.replace('%', '\\%').replace('#', '\\#')
        # Format journal
        journal = item.get('journal', '').strip()
        journal = journal.replace('&amp;', '\\&').replace('&', '\\&')
        year = item.get('year', '')
        vol = item.get('vol', '')
        page = item.get('page', '')
        doi = item.get('doi', '').strip()
        
        authors = item.get('authors', [])
        if not authors:
            author_str = "Author"
        elif len(authors) == 1:
            author_str = authors[0]
        elif len(authors) == 2:
            author_str = f"{authors[0]} and {authors[1]}"
        elif len(authors) == 3:
            author_str = f"{authors[0]}, {authors[1]}, and {authors[2]}"
        else:
            author_str = f"{authors[0]} et al."
            
        vol_page = ""
        if vol and page:
            vol_page = f", vol.~{vol}, pp.~{page}"
        elif vol:
            vol_page = f", vol.~{vol}"
        elif page:
            vol_page = f", pp.~{page}"
            
        doi_str = f" \\doi{{{doi}}}" if doi else ""
        lines.append(f"\\bibitem{{{key}}} {author_str}, ``{title},'' \\emph{{{journal}}}{vol_page}, {year}.{doi_str}")
        
    lines.append("\\end{thebibliography}")
    return "\n".join(lines)

bib_tex = format_clean_bib(clean_refs)

with open('manuscript/bib_80_clean.tex', 'w', encoding='utf-8') as f:
    f.write(bib_tex)

print("Saved manuscript/bib_80_clean.tex")
