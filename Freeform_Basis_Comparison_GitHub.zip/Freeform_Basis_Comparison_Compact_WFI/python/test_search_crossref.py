import urllib.request
import urllib.parse
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

def search_crossref_article(query):
    params = urllib.parse.urlencode({
        'query': query,
        'rows': 2,
        'filter': 'type:journal-article'
    })
    url = f"https://api.crossref.org/works?{params}"
    req = urllib.request.Request(url, headers={'User-Agent': 'OpticsResearchBibValidator/1.0 (mailto:researcher@opticslab.edu)'})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            items = data.get('message', {}).get('items', [])
            results = []
            for item in items:
                doi = item.get('DOI', '')
                title = (item.get('title') or [''])[0]
                container = item.get('container-title', [''])
                journal = container[0] if container else ''
                pub = item.get('published-print') or item.get('published-online') or item.get('created')
                year = pub['date-parts'][0][0] if pub and 'date-parts' in pub else ''
                volume = item.get('volume', '')
                page = item.get('page', '')
                
                authors_list = item.get('author', [])
                author_names = []
                for a in authors_list:
                    given = a.get('given', '')
                    family = a.get('family', '')
                    if given and family:
                        initials = " ".join([f"{n[0]}." for n in given.split() if n])
                        author_names.append(f"{initials} {family}")
                    elif family:
                        author_names.append(family)
                        
                results.append({
                    'doi': doi,
                    'title': title,
                    'journal': journal,
                    'year': year,
                    'volume': volume,
                    'page': page,
                    'authors': author_names
                })
            return results
    except Exception as e:
        print(f"Error querying {query}: {e}")
        return []

# Test queries
queries = [
    "Fuerschbach Davis Thompson A new family of optical systems employing phi-polynomial",
    "Optics Laser Technology freeform surface design",
    "Optics Laser Technology mid-spatial frequency error",
    "Optics Express Zernike polynomial freeform surface",
    "Deb Kalyanmoy NSGA-II fast and elitist multiobjective"
]

for q in queries:
    res = search_crossref_article(q)
    print(f"\nQUERY: {q[:50]}")
    for r in res:
        print(f"  -> {r['doi']} | {r['year']} | {r['journal'][:30]} | {r['title'][:60]}")
