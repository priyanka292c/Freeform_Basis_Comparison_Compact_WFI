import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Compact figure widths
figs = [
    (r'\includegraphics[width=0.78\columnwidth]{../figures/source/fig16_sag_departure.png}',
     r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig16_sag_departure.png}'),
    (r'\includegraphics[width=0.78\columnwidth]{../figures/source/fig17_surface_slope.png}',
     r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig17_surface_slope.png}'),
    (r'\includegraphics[width=0.78\columnwidth]{../figures/source/fig20_psd.png}',
     r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig20_psd.png}'),
    (r'\includegraphics[width=0.78\columnwidth]{../figures/source/fig22_monte_carlo.png}',
     r'\includegraphics[width=0.70\columnwidth]{../figures/source/fig22_monte_carlo.png}'),
    (r'\includegraphics[width=0.76\columnwidth]{../figures/source/fig29_pareto.png}',
     r'\includegraphics[width=0.68\columnwidth]{../figures/source/fig29_pareto.png}'),
    (r'\includegraphics[width=0.76\columnwidth]{../figures/source/fig34_runtime.png}',
     r'\includegraphics[width=0.66\columnwidth]{../figures/source/fig34_runtime.png}'),
    (r'\includegraphics[width=0.76\columnwidth]{../figures/source/fig35_ranking.png}',
     r'\includegraphics[width=0.66\columnwidth]{../figures/source/fig35_ranking.png}'),
]

for o, n in figs:
    if o in tex:
        tex = tex.replace(o, n)
    else:
        print(f"Warning: could not find {o[:30]}")

# 2. Bibliography font and spacing
old_bib = re.search(r'\\begin\{thebibliography\}\{80\}.*?(?=\\bibitem)', tex, re.DOTALL)
if old_bib:
    new_bib = r"""\begin{thebibliography}{80}
\fontsize{4.8pt}{5.6pt}\selectfont
\setlength{\itemsep}{-1.0pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}
"""
    tex = tex[:old_bib.start()] + new_bib + tex[old_bib.end():]

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Compiling main.tex...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
