import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Remove \vfill\null\pagebreak or \pagebreak
tex = tex.replace(r'\vfill\null\pagebreak', '')
tex = tex.replace(r'\pagebreak', '')

# 2. Set gentle \enlargethispage{1\baselineskip} on Conclusions
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Conclusions\}',
             r'\\enlargethispage{1\\baselineskip}\n\\section{Conclusions}',
             tex)

# 3. Ensure clean bib header
bib_header = r"""\begin{thebibliography}{80}
\fontsize{4.3pt}{4.8pt}\selectfont
\setlength{\itemsep}{-0.6pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}"""

tex = re.sub(
    r'\\begin\{thebibliography\}\{80\}.*?(?=\\bibitem)',
    lambda m: bib_header + '\n',
    tex,
    flags=re.DOTALL
)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Compiling main.tex for clean 10-page verification...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
