﻿"""
optimization.py
===============
Multi-objective optimization of freeform surface representations.

Uses NSGA-II algorithm (pymoo) to construct Pareto fronts for:
  - Minimize: WFE, distortion, FCI, max_slope
  - Maximize: tolerance yield, MTF at Nyquist

The system model is analytical (polynomial surface evaluation).
For Zemax-based optimization, use zemax_api.py.

Author: [Author Name] | Date: 2026-09-02 | RANDOM SEED: 42
"""

import numpy as np
import pandas as pd
from pathlib import Path

try:
    from pymoo.algorithms.moo.nsga2 import NSGA2
    from pymoo.core.problem import Problem
    from pymoo.optimize import minimize as pymoo_minimize
    from pymoo.operators.crossover.sbx import SBX
    from pymoo.operators.mutation.pm import PM
    from pymoo.operators.sampling.rnd import FloatRandomSampling
    PYMOO_AVAILABLE = True
except ImportError:
    PYMOO_AVAILABLE = False
    print("WARNING: pymoo not installed. Install with: pip install pymoo")


SURFACES = ["Asphere", "Zernike_Fringe", "XY_Poly", "Q_Type",
            "Chebyshev", "TrueFreeForm"]
RANDOM_SEED = 42


class FreeformOptProblem(Problem):
    """
    Multi-objective problem for freeform coefficient optimization.

    Decision variables: N freeform coefficients in [-0.5, +0.5] mm
    Objectives:
      f1 = RMS WFE proxy (L2 norm of coefficients — analytical surrogate)
      f2 = FCI (coefficient complexity proxy)
      f3 = Max slope (computed analytically)
    Constraints:
      g1 = max_slope <= 0.10 (10% slope limit)

    NOTE: This is an ANALYTICAL SURROGATE MODEL.
    Real optical performance requires OpticStudio.
    """

    def __init__(self, n_coeffs: int = 12):
        super().__init__(
            n_var=n_coeffs,
            n_obj=3,
            n_constr=1,
            xl=-0.5 * np.ones(n_coeffs),
            xu=+0.5 * np.ones(n_coeffs),
        )
        self.n_coeffs = n_coeffs

    def _evaluate(self, X, out, *args, **kwargs):
        import sys; sys.path.insert(0, str(Path(__file__).parent))
        from freeform_surfaces import make_grid, chebyshev_sag, sag_departure, surface_slopes

        HALF_AP = 10.0
        R, K = 80.0, -0.5
        x, y = make_grid(HALF_AP, 64)
        dx = 2 * HALF_AP / 63.0

        f1 = np.zeros(len(X))  # WFE proxy
        f2 = np.zeros(len(X))  # FCI proxy
        f3 = np.zeros(len(X))  # max slope proxy
        g1 = np.zeros(len(X))  # slope constraint

        orders = [(0,2),(0,4),(0,6),(2,0),(2,2),(2,4),(4,0),(4,2),(4,4),
                  (6,0),(6,2),(8,0)][:self.n_coeffs]

        from freeform_surfaces import even_asphere_sag
        z_base = even_asphere_sag(x, y, R, K)

        for idx, coeffs_vec in enumerate(X):
            coeffs = {orders[i]: coeffs_vec[i] for i in range(len(orders))}
            z_ff = chebyshev_sag(x, y, R, K, coeffs, HALF_AP)
            dep = z_ff - z_base
            dzdx, dzdy = surface_slopes(dep, dx)
            slope_mag = np.sqrt(dzdx**2 + dzdy**2)

            wfe_proxy   = float(np.sqrt(np.mean(dep**2)))
            fci_proxy   = float(np.sqrt(np.sum(coeffs_vec**2)))
            max_slope   = float(slope_mag.max())

            f1[idx] = wfe_proxy
            f2[idx] = fci_proxy
            f3[idx] = max_slope
            g1[idx] = max_slope - 0.10  # <= 0 is feasible

        out["F"] = np.column_stack([f1, f2, f3])
        out["G"] = g1.reshape(-1, 1)


def run_nsga2(n_coeffs: int = 12,
              pop_size: int = 100,
              n_gen: int = 200,
              seed: int = RANDOM_SEED) -> dict:
    """
    Run NSGA-II multi-objective optimization.

    Parameters
    ----------
    n_coeffs : number of freeform coefficients (decision variables)
    pop_size : NSGA-II population size
    n_gen    : number of generations
    seed     : random seed

    Returns
    -------
    dict with Pareto-optimal solutions or NOT_EXECUTED status
    """
    if not PYMOO_AVAILABLE:
        return {"status": "NOT_EXECUTED — pymoo not installed",
                "n_coeffs": n_coeffs}

    problem = FreeformOptProblem(n_coeffs=n_coeffs)
    algorithm = NSGA2(
        pop_size=pop_size,
        sampling=FloatRandomSampling(),
        crossover=SBX(prob=0.9, eta=15),
        mutation=PM(eta=20),
        eliminate_duplicates=True,
    )

    res = pymoo_minimize(
        problem, algorithm,
        ("n_gen", n_gen),
        seed=seed,
        verbose=False
    )

    return {
        "status":        "COMPLETED",
        "n_coeffs":      n_coeffs,
        "pop_size":      pop_size,
        "n_gen":         n_gen,
        "seed":          seed,
        "n_pareto":      len(res.X),
        "pareto_X":      res.X,
        "pareto_F":      res.F,
    }


def save_pareto_csv(result: dict, out_path: Path) -> None:
    """Save Pareto front to CSV."""
    if result.get("status") != "COMPLETED":
        pd.DataFrame([result]).to_csv(out_path, index=False)
        return
    X, F = result["pareto_X"], result["pareto_F"]
    df_X = pd.DataFrame(X, columns=[f"c{i}" for i in range(X.shape[1])])
    df_F = pd.DataFrame(F, columns=["f1_wfe", "f2_fci", "f3_slope"])
    df = pd.concat([df_F, df_X], axis=1)
    df["n_coeffs"] = result["n_coeffs"]
    df.to_csv(out_path, index=False)
    print(f"Pareto front saved: {out_path} ({len(df)} solutions)")


if __name__ == "__main__":
    print("Running NSGA-II (analytical surrogate model)...")
    result = run_nsga2(n_coeffs=12, pop_size=80, n_gen=100, seed=42)
    if result.get("status") == "COMPLETED":
        print(f"Pareto front: {result['n_pareto']} solutions found.")
        save_pareto_csv(result, Path("../data/csv/pareto_front.csv"))
    else:
        print(result["status"])
