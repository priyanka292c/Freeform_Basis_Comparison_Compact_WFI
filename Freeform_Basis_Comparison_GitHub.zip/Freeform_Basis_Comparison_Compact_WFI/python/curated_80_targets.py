import urllib.request
import urllib.parse
import json
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

# 80 specific target queries or known exact DOIs covering the full manuscript scope
# Categorized by section to match the sequential narrative flow:
# 1-18: Section 1 (Introduction: Freeform optics, off-axis imaging, aberration theory)
# 19-28: Section 2 (Research Gap: Multi-basis comparison, TMA architectures, compact systems)
# 29-36: Section 3 (Benchmark System: Compact WFI, geometry, sampling, normalization)
# 37-48: Section 4 (Surface Formulations: Zernike, XY, Forbes Q, Chebyshev, local grids, bicubic, PSD)
# 49-66: Section 5 (Results: WFE/MTF, toolpath/MSF, slope/Hessian, ISO tolerancing, ANOVA, Monte Carlo)
# 67-74: Section 6 (Discussion: Orthogonality mechanisms, Noll vs Fringe, grid gradients)
# 75-80: Section 7 & 8 (Limitations, NSGA-II optimization, AI/global search, future outlook)

curated_targets = [
    # --- SECTION 1: Introduction (1-18) ---
    {"key": "Rolland2021", "query": "Rolland Freeform optics: tutorial", "doi_hint": "10.1364/AOP.416262"},
    {"key": "Forbes2007", "query": "Forbes Shape specification for axially symmetric optical surfaces", "doi_hint": "10.1364/oe.15.005218"},
    {"key": "Forbes2010", "query": "Forbes Robust, efficient computational methods for axially symmetric", "doi_hint": "10.1364/oe.18.019700"},
    {"key": "Forbes2012", "query": "Forbes Characterizing the shape of freeform optics", "doi_hint": "10.1364/oe.20.002483"},
    {"key": "Thompson2005", "query": "Thompson Description of the third-order optical aberrations of unsymmetric systems", "doi_hint": "10.1364/josaa.22.001389"},
    {"key": "Thompson2009", "query": "Thompson Multinodal fifth-order optical aberrations of optical systems without rotational symmetry", "doi_hint": "10.1364/josaa.26.001090"},
    {"key": "Thompson2012", "query": "Thompson Rolland Freeform Optical Surfaces: A Revolution in Imaging Optical Design", "doi_hint": "10.1364/OPN.23.6.000030"},
    {"key": "Zernike1934", "query": "Zernike Beugungstheorie des schneidenver-fahrens und seiner verbesserten form", "doi_hint": "10.1016/S0031-8914(34)80259-5"},
    {"key": "Noll1976", "query": "Noll Zernike polynomials and atmospheric turbulence", "doi_hint": "10.1364/JOSA.66.000207"},
    {"key": "Lakshminarayanan2011", "query": "Lakshminarayanan Zernike polynomials: a guide", "doi_hint": "10.1080/09500340.2011.554896"},
    {"key": "Fuerschbach2011", "query": "Fuerschbach Davis Thompson Rolland A new family of optical systems employing phi-polynomial surfaces", "doi_hint": "10.1364/oe.19.021919"},
    {"key": "Fuerschbach2014", "query": "Fuerschbach Assembly of a freeform off-axis optical system employing three mirrors", "doi_hint": "10.1364/ol.39.002896"},
    {"key": "Sasian2010", "query": "Sasian Aberrations of anamorphic optical systems", "doi_hint": "10.1364/ao.49.006802"},
    {"key": "Gross2021", "query": "Gross Extended aberration analysis in symmetry-free optical systems", "doi_hint": "10.1364/oe.439873"},
    {"key": "Bauer2015", "query": "Bauer Rolland Design of a freeform electronic viewfinder", "doi_hint": "10.1364/oe.23.028141"},
    {"key": "Cakmakci2008", "query": "Cakmakci Application of radial basis functions to shape description in a freeform optical system", "doi_hint": "10.1364/ol.33.001237"},
    {"key": "Zhong2017", "query": "Zhong Gross Initial system design method for non-rotationally symmetric systems", "doi_hint": "10.1364/oe.25.010016"},
    {"key": "Papa2018", "query": "Papa Bauer Rolland Freeform spectrometer design", "doi_hint": "10.1364/OE.26.022996"},

    # --- SECTION 2: Research Gap & Scope (19-28) ---
    {"key": "Meng2019", "query": "Meng Design of off-axis three-mirror systems with freeform surfaces", "doi_hint": "10.1364/ao.58.000609"},
    {"key": "Yang2017LSA", "query": "Yang Jin Zhu Automated design of freeform imaging systems", "doi_hint": "10.1038/lsa.2017.81"},
    {"key": "Tan2026OLT", "query": "Tan Cheng Conic-Surface-Enabling design of multi-mirror freeform imaging systems", "doi_hint": "10.1016/j.optlastec.2025.114482"},
    {"key": "Zhang2021OE", "query": "Zhang Men Zhu Design of a freeform imaging spectrometer based on off-axis three-mirror", "doi_hint": "10.1364/oe.441398"},
    {"key": "Nie2020AO", "query": "Nie Design of compact off-axis freeform two-mirror system", "doi_hint": "10.1364/AO.59.004112"},
    {"key": "Huang2018OLT", "query": "Huang Meng Residual aberration correction method of the off-axis three-mirror system", "doi_hint": "10.1016/j.optlastec.2018.03.035"},
    {"key": "Zhu2019Optica", "query": "Zhu Constructing starting points for freeform imaging optical system design", "doi_hint": "10.1364/OPTICA.6.000840"},
    {"key": "Qin2022OLT", "query": "Optics Laser Technology off-axis reflective optical system freeform", "doi_hint": "10.1016/j.optlastec.2021.107775"},
    {"key": "Li2023OLT", "query": "Optics Laser Technology freeform imaging spectrometer", "doi_hint": "10.1016/j.optlastec.2022.108998"},
    {"key": "Beier2012", "query": "Kaya Thompson Rolland Comparative assessment of freeform polynomials", "doi_hint": "10.1364/oe.20.022683"},

    # --- SECTION 3: Optical System & Benchmark Protocol (29-36) ---
    {"key": "Cheng2023OLT", "query": "Optics Laser Technology off-axis freeform surface reflective optical design", "doi_hint": "10.1016/j.optlastec.2023.109555"},
    {"key": "Liu2011OE", "query": "Liu Analyzing optics test data on rectangular apertures with Chebyshev polynomials", "doi_hint": "10.1117/1.3569692"},
    {"key": "Forbes2013", "query": "Forbes Fitting freeform shapes with orthogonal bases", "doi_hint": "10.1364/oe.21.019061"},
    {"key": "Davis2018", "query": "Davis Off-axis reflective optical system design freeform mirror", "doi_hint": "10.1364/AO.57.002302"},
    {"key": "Bauer2018", "query": "Yao Anderson Rolland Point-cloud noncontact metrology of freeform optical surfaces", "doi_hint": "10.1364/oe.26.010242"},
    {"key": "Chen2025OE", "query": "Chen Xu Wang Topological homeomorphism extends orthogonal polynomials to arbitrary domains", "doi_hint": "10.1364/oe.568940"},
    {"key": "Mahajan2013", "query": "Mahajan Diaz Imaging characteristics of Zernike and annular polynomials", "doi_hint": "10.1364/ao.52.002062"},
    {"key": "Dai2012", "query": "Dai Tang Wang Modal wavefront reconstruction based on Zernike polynomials", "doi_hint": "10.1364/ao.51.005028"},

    # --- SECTION 4: Mathematical Surface Formulations (37-48) ---
    {"key": "Zheng2020AO", "query": "Zheng Orthogonal polynomial representation for freeform optical surfaces", "doi_hint": "10.1364/AO.59.006528"},
    {"key": "Wang2025OE", "query": "Analytical design of freeform surface parameters of optical system", "doi_hint": "10.1364/oe.557283"},
    {"key": "Zhu2017AO", "query": "Zhu Design of freeform optical systems using coordinate transformation", "doi_hint": "10.1364/AO.56.002543"},
    {"key": "Guenther2019OLT", "query": "Optics Laser Technology freeform surface measurement deflectometry", "doi_hint": "10.1016/j.optlastec.2019.04.015"},
    {"key": "Hou2022OLT", "query": "Optics Laser Technology freeform mirror fabrication ultra precision", "doi_hint": "10.1016/j.optlastec.2022.108226"},
    {"key": "Cardenas2023", "query": "Cardenas Forbes Designing freeform surfaces using orthogonal polynomials", "doi_hint": "10.1364/JOSAA.40.000B22"},
    {"key": "Barakat1980", "query": "Barakat Optimum balanced wave-front aberrations for arbitrary apertures", "doi_hint": "10.1364/JOSA.70.000739"},
    {"key": "Upton2008", "query": "Upton Fitting freeform optical surfaces with orthogonal basis functions", "doi_hint": "10.1364/OFT.2008.OWB2"},
    {"key": "Aikens2008", "query": "Aikens DeGroote Youngworth Specification and Control of Mid-Spatial Frequency", "doi_hint": "10.1364/oft.2008.otua1"},
    {"key": "Youngworth2000", "query": "Youngworth Stone Simple estimates for the effects of mid-spatial-frequency surface errors", "doi_hint": "10.1364/ao.39.002198"},
    {"key": "Tamkin2010", "query": "Tamkin Milster Analysis and tolerancing of structured mid-spatial frequency errors", "doi_hint": "10.1117/12.871013"},
    {"key": "Harvey2012", "query": "Harvey Total integrated scatter from surfaces with arbitrary roughness", "doi_hint": "10.1117/1.oe.51.1.013402"},

    # --- SECTION 5: Results & Comparative Analysis (49-66) ---
    {"key": "Fang2013", "query": "Fang Zhang Manufacturing and measurement of freeform optics", "doi_hint": "10.1016/j.cirp.2013.05.003"},
    {"key": "Scheiding2011", "query": "Scheiding Ultra-precision machining of freeform optical surfaces", "doi_hint": "10.1117/12.894291"},
    {"key": "Zhang2019CIRP", "query": "Zhang CIRP ultra-precision machining of freeform surfaces", "doi_hint": "10.1016/j.cirp.2019.04.015"},
    {"key": "Brinksmeier2012", "query": "Brinksmeier Diamond machining of freeform surfaces", "doi_hint": "10.1016/j.cirp.2012.05.004"},
    {"key": "Gao2019PE", "query": "Gao Precision Engineering diamond turning freeform", "doi_hint": "10.1016/j.precisioneng.2018.11.005"},
    {"key": "Shore2011", "query": "Shore Precision Engineering ultra precision diamond machining", "doi_hint": "10.1016/j.precisioneng.2010.09.006"},
    {"key": "Beaucamp2017", "query": "Beaucamp CIRP Annals finishing freeform surfaces", "doi_hint": "10.1016/j.cirp.2017.04.041"},
    {"key": "Gong2021OLT", "query": "Optics Laser Technology diamond turning tool wear freeform", "doi_hint": "10.1016/j.optlastec.2020.106512"},
    {"key": "Liu2022OLT", "query": "Optics Laser Technology laser surface polishing freeform", "doi_hint": "10.1016/j.optlastec.2021.107567"},
    {"key": "Zhu2023PE", "query": "Precision Engineering fast tool servo freeform surface fabrication", "doi_hint": "10.1016/j.precisioneng.2023.01.008"},
    {"key": "Guo2024OE", "query": "Zhang Wang Virtual reference surface phase measuring deflectometry", "doi_hint": "10.1364/oe.545763"},
    {"key": "Zhao2020OLT", "query": "Optics Laser Technology ultra precision optical machining", "doi_hint": "10.1016/j.optlastec.2020.106312"},
    {"key": "Wang2024OLT", "query": "Optics Laser Technology optical surface form error compensation", "doi_hint": "10.1016/j.optlastec.2023.110255"},
    {"key": "Xu2023OLT", "query": "Optics Laser Technology high precision optical measurement sensor", "doi_hint": "10.1016/j.optlastec.2023.109315"},
    {"key": "Chen2021OE", "query": "Beaucamp Takizawa Reduction of mid-spatial frequency errors on freeform surfaces", "doi_hint": "10.1364/oe.435945"},
    {"key": "Shi2021OLT", "query": "Optics Laser Technology optical surface measurement and characterization", "doi_hint": "10.1016/j.optlastec.2021.107228"},
    {"key": "Kim2021OE", "query": "Kim Cassarly Rolland Connecting tolerancing of freeform surface departures", "doi_hint": "10.1364/oe.442853"},
    {"key": "ISO10110", "query": "Herman Aikens Youngworth Modern optics drawings: Understanding the nuances of ISO 10110", "doi_hint": "10.1364/oft.2019.om2a.5"},

    # --- SECTION 6: Discussion (67-74) ---
    {"key": "Howard2013", "query": "Howard Tolerancing optical systems using Monte Carlo techniques", "doi_hint": "10.1117/12.2024560"},
    {"key": "Rogers2014", "query": "Kiontke Aikens Youngworth Description and tolerancing of freeform surfaces", "doi_hint": "10.1117/12.2075925"},
    {"key": "Ruda2007", "query": "Perrin Ruda Comparison of methods for tolerancing optical systems", "doi_hint": "10.1117/12.734563"},
    {"key": "Song2022OLT", "query": "Optics Laser Technology optical system tolerance and thermal analysis", "doi_hint": "10.1016/j.optlastec.2022.108412"},
    {"key": "Zhang2023OE", "query": "Shi Yoshimoto Zhang Design of freeform optical surfaces with controlled slope error", "doi_hint": "10.1364/oe.501898"},
    {"key": "Duparre2002", "query": "Duparre Surface roughness and light scattering of optical components", "doi_hint": "10.1364/ao.41.003294"},
    {"key": "DeGroote2012", "query": "DeGroote Aikens Specification and measurement of optical surface shape and roughness", "doi_hint": "10.1117/12.929828"},
    {"key": "Nelson2014", "query": "Lin Shen Wang Optical wavefront reconstruction and tolerance", "doi_hint": "10.1364/ao.53.003920"},

    # --- SECTION 7 & 8: Limitations, NSGA-II, Conclusions (75-80) ---
    {"key": "Deb2002", "query": "Deb A fast and elitist multiobjective genetic algorithm: NSGA-II", "doi_hint": "10.1109/4235.996017"},
    {"key": "Houllier2019", "query": "Houllier Lepine Comparing optimization algorithms for optical design", "doi_hint": "10.1364/oe.27.028383"},
    {"key": "Hou2020", "query": "Bacca Galvis Arguello Deep learning coded aperture design freeform", "doi_hint": "10.1364/oe.381479"},
    {"key": "Wu2023OLT", "query": "Optics Laser Technology multiobjective optimization optical design algorithm", "doi_hint": "10.1016/j.optlastec.2023.109885"},
    {"key": "Li2024LSA", "query": "Light Science Applications freeform optics manufacturing and testing", "doi_hint": "10.1038/s41377-024-01450-x"},
    {"key": "Zhu2025OLT", "query": "Optics Laser Technology coherent mode freeform optical systems", "doi_hint": "10.1016/j.optlastec.2024.111950"}
]

print(f"Total curated targets: {len(curated_targets)}")
