﻿"""
master_pipeline.py
==================
Master research pipeline orchestrator.

Runs in sequence:
  1. Generate all CSV data files (analytical)
  2. Generate all figures
  3. Run bibliography verification
  4. Report status

Author: [Author Name] | Date: 2026-09-02 | RANDOM SEED: 42
"""

import sys
import time
import numpy as np
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

BASE     = Path(__file__).parent.parent
DATA_CSV = BASE / "data" / "csv"
DATA_CSV.mkdir(parents=True, exist_ok=True)

HALF_AP = 10.0
R_BASE  = 80.0
K_BASE  = -0.50
N_PTS   = 256
DX      = 2 * HALF_AP / (N_PTS - 1)

SURFACES_FF = ["Zernike_Fringe","Zernike_Std","XY_Poly","Q_Type","Chebyshev","TrueFreeForm"]


def generate_csv_data():
    """Generate all analytical CSV data files."""
    print("=== GENERATING CSV DATA ===")

    from freeform_surfaces import (
        make_grid, even_asphere_sag, zernike_sag, xy_polynomial_sag,
        qtype_sag, chebyshev_sag, truefreeform_sag,
        surface_slopes, surface_curvature
    )
    from fci_calculator import batch_fci, surface_complexity_metrics, coeff_complexity
    from tolerance import run_monte_carlo, TOLERANCE_TABLE
    from psd_analysis import analyse_surface

    x, y = make_grid(HALF_AP, N_PTS)

    # Build surfaces
    gn  = 32
    gax = np.linspace(-HALF_AP, HALF_AP, gn)
    gx, gy = np.meshgrid(gax, gax)
    rng = np.random.default_rng(42)
    gz_dep = (0.015 * np.cos(np.pi*gx/HALF_AP) * np.cos(np.pi*gy/HALF_AP)
              + 0.005 * rng.normal(0, 0.001, gx.shape))

    ZERNIKE_FRINGE_COEFFS = {5:0.050, 9:0.030, 12:0.020, 16:0.012, 17:0.008, 25:0.005}
    ZERNIKE_STD_COEFFS    = {5:0.048, 9:0.028, 12:0.019, 16:0.011, 17:0.007, 25:0.004}
    XY_COEFFS = {(0,2):0.0012,(0,4):0.0006,(2,0):0.0010,(2,2):0.0005,
                 (4,0):0.0004,(0,6):0.0002,(6,0):0.0002}
    QTYPE_COEFFS = {0:0.0, 1:0.040, 2:0.022, 3:0.012, 4:0.006, 5:0.003}
    CHEBY_COEFFS = {(0,2):0.0011,(0,4):0.0005,(2,0):0.0009,(2,2):0.0004,
                    (4,0):0.0003,(0,6):0.0002,(6,0):0.0002}

    z_base = even_asphere_sag(x, y, R_BASE, K_BASE)
    z_dict = {
        "Asphere":        z_base,
        "Zernike_Fringe": zernike_sag(x, y, R_BASE, K_BASE, ZERNIKE_FRINGE_COEFFS, HALF_AP),
        "Zernike_Std":    zernike_sag(x, y, R_BASE, K_BASE, ZERNIKE_STD_COEFFS, HALF_AP, "standard"),
        "XY_Poly":        xy_polynomial_sag(x, y, R_BASE, K_BASE, XY_COEFFS),
        "Q_Type":         qtype_sag(x, y, R_BASE, K_BASE, QTYPE_COEFFS, HALF_AP),
        "Chebyshev":      chebyshev_sag(x, y, R_BASE, K_BASE, CHEBY_COEFFS, HALF_AP),
        "TrueFreeForm":   truefreeform_sag(x, y, R_BASE, K_BASE, gax, gax, gz_dep),
    }

    # ── Baseline system specification CSV ──
    baseline_spec = {
        "Parameter":     ["EFL","F_number","Half_FOV_deg","Aperture_diam_mm",
                          "Wavelength_band_nm","Detector_pixels","Pixel_size_um",
                          "Total_track_mm","Obscuration_ratio","System_type"],
        "Value":         [150, 7.5, 4.0, 20, "450-900", "4096x3072", 3.45, 250,
                          0.25, "Off-axis_reflective_two_mirror"],
        "Unit":          ["mm","","deg","mm","nm","pixels","um","mm","",""],
        "Justification": ["Compact imaging requirement","Standard for compact systems",
                          "Wide-field benchmark","Clear aperture budget",
                          "Vis-NIR coverage","Consumer imaging grade","Mobile sensor grade",
                          "System packaging constraint","Secondary mirror central",
                          "Enables freeform comparison on non-rotational surface"],
    }
    pd.DataFrame(baseline_spec).to_csv(DATA_CSV / "baseline_system.csv", index=False)
    print("  baseline_system.csv saved")

    # ── Surface sag maps (central cross-section for CSV) ──
    N_cs = 512
    ax_cs = np.linspace(-HALF_AP, HALF_AP, N_cs)
    x_cs = ax_cs
    y_cs = np.zeros(N_cs)

    sag_rows = []
    for key, z in z_dict.items():
        centre_row = z[N_PTS//2, :]
        for xi, zi in zip(np.linspace(-HALF_AP, HALF_AP, N_PTS), centre_row):
            sag_rows.append({"surface": key, "x_mm": xi, "y_mm": 0.0, "z_sag_mm": zi})
    pd.DataFrame(sag_rows).to_csv(DATA_CSV / "surface_sag.csv", index=False)
    print("  surface_sag.csv saved")

    # ── Surface slope / FCI table ──
    coeff_sets = {
        "Asphere":        {},
        "Zernike_Fringe": ZERNIKE_FRINGE_COEFFS,
        "Zernike_Std":    ZERNIKE_STD_COEFFS,
        "XY_Poly":        {f"({k[0]},{k[1]})": v for k,v in XY_COEFFS.items()},
        "Q_Type":         QTYPE_COEFFS,
        "Chebyshev":      {f"({k[0]},{k[1]})": v for k,v in CHEBY_COEFFS.items()},
        "TrueFreeForm":   {},
    }

    surf_list = []
    for key, z in z_dict.items():
        dep = z - z_base
        from fci_calculator import surface_complexity_metrics, coeff_complexity
        gm  = surface_complexity_metrics(dep, DX)
        cm  = coeff_complexity(coeff_sets.get(key, {}))
        row = {"surface": key}
        row.update(gm)
        row.update(cm)
        surf_list.append(row)
    pd.DataFrame(surf_list).to_csv(DATA_CSV / "surface_slope.csv", index=False)
    print("  surface_slope.csv (slope + FCI components) saved")

    # ── Monte-Carlo summary ──
    base_wfes = {"Asphere":0.040,"Zernike_Fringe":0.042,"XY_Poly":0.045,
                 "Q_Type":0.038,"Chebyshev":0.041,"TrueFreeForm":0.047}
    mc_rows = []
    for surf, bwfe in base_wfes.items():
        r = run_monte_carlo(surf, baseline_wfe=bwfe, n_trials=5000, seed=42)
        mc_rows.append({k: v for k, v in r.items()
                        if k not in ("wfe_samples","errors_df")})
    pd.DataFrame(mc_rows).to_csv(DATA_CSV / "monte_carlo_results.csv", index=False)
    print("  monte_carlo_results.csv saved (analytical model)")

    # ── Coefficient table CSV ──
    coeff_rows = []
    named_coeffs = {
        "Zernike_Fringe": ZERNIKE_FRINGE_COEFFS,
        "Zernike_Std":    ZERNIKE_STD_COEFFS,
    }
    for surf, coeffs in named_coeffs.items():
        for idx, val in coeffs.items():
            coeff_rows.append({"surface": surf, "index": idx,
                               "coefficient_mm": val})
    # XY
    for (i,j), v in XY_COEFFS.items():
        coeff_rows.append({"surface":"XY_Poly","index":f"x{i}y{j}","coefficient_mm":v})
    # Q-type
    for m, v in QTYPE_COEFFS.items():
        coeff_rows.append({"surface":"Q_Type","index":f"Q{m}","coefficient_mm":v})
    # Chebyshev
    for (i,j), v in CHEBY_COEFFS.items():
        coeff_rows.append({"surface":"Chebyshev","index":f"T{i}T{j}","coefficient_mm":v})

    pd.DataFrame(coeff_rows).to_csv(DATA_CSV / "coefficients_all.csv", index=False)
    print("  coefficients_all.csv saved")

    # ── Placeholder CSVs for Zemax-dependent data ──
    placeholder_note = "SIMULATION_NOT_EXECUTED - requires OpticStudio"
    for fname in ["mtf_all","wfe_all","spot_all","distortion_all",
                  "tolerance_results","yield_results"]:
        df = pd.DataFrame({
            "surface":  SURFACES_FF,
            "value":    [placeholder_note]*len(SURFACES_FF),
            "unit":     ["N/A"]*len(SURFACES_FF),
            "note":     ["Run zemax_api.py with OpticStudio installed"]*len(SURFACES_FF),
        })
        df.to_csv(DATA_CSV / f"{fname}.csv", index=False)
    print("  Placeholder CSVs written for Zemax-dependent results")

    # ── Runtime CSV (placeholder — actual generated by plotting.py) ──
    print("  Runtime CSV will be generated by plotting.py fig34_runtime()")

    print("=== CSV GENERATION COMPLETE ===\n")


def generate_figures():
    print("=== GENERATING FIGURES ===")
    from plotting import generate_all
    generate_all()


def main():
    t0 = time.time()
    print("=" * 60)
    print("FREEFORM BASIS COMPARISON — MASTER PIPELINE")
    print("=" * 60)
    generate_csv_data()
    generate_figures()
    print(f"\nTotal elapsed: {time.time()-t0:.1f} s")
    print("Pipeline complete.")


if __name__ == "__main__":
    main()
