import urllib.request
import json
import time
import sys

sys.stdout.reconfigure(encoding='utf-8')

def query_crossref_doi(doi):
    url = f"https://api.crossref.org/works/{doi}"
    req = urllib.request.Request(url, headers={'User-Agent': 'OpticsResearchBibValidator/1.0 (mailto:researcher@opticslab.edu)'})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            msg = data.get('message', {})
            
            # Extract title
            titles = msg.get('title', [])
            title = titles[0] if titles and titles[0] is not None else ''
            
            # Extract authors
            authors_list = msg.get('author', [])
            author_names = []
            for a in authors_list:
                given = a.get('given', '')
                family = a.get('family', '')
                if given and family:
                    # initials for given
                    initials = " ".join([f"{n[0]}." for n in given.split() if n])
                    author_names.append(f"{initials} {family}")
                elif family:
                    author_names.append(family)
            
            # Extract journal
            container = msg.get('container-title', [])
            journal = container[0] if container else ''
            
            # Extract year
            pub = msg.get('published-print') or msg.get('published-online') or msg.get('created')
            year = pub['date-parts'][0][0] if pub and 'date-parts' in pub else ''
            
            volume = msg.get('volume', '')
            issue = msg.get('issue', '')
            page = msg.get('page', '')
            
            return {
                'status': 'ok',
                'doi': doi,
                'title': title,
                'authors': author_names,
                'journal': journal,
                'year': year,
                'volume': volume,
                'issue': issue,
                'page': page
            }
    except Exception as e:
        return {'status': 'error', 'doi': doi, 'error': str(e)}

# Test with a few known DOIs
test_dois = [
    "10.1364/oe.15.005218", # Forbes 2007
    "10.1364/oe.18.019700", # Forbes 2010
    "10.1364/oe.20.002483", # Forbes 2012
    "10.1364/oe.21.019061", # Forbes 2013
    "10.1364/josaa.22.001389", # Thompson 2005
    "10.1364/josaa.26.001090", # Thompson 2009
    "10.1364/oe.19.021975", # Fuerschbach 2011
    "10.1364/ol.39.002896", # Fuerschbach 2014
    "10.1364/oe.23.028141", # Bauer 2015
    "10.1016/j.optlastec.2025.114482", # Tan 2026 OLT
]

for doi in test_dois:
    res = query_crossref_doi(doi)
    if res['status'] == 'ok':
        print(f"DOI: {res['doi']} | Year: {res.get('year')} | Journal: {res.get('journal')} | Title: {res.get('title','')[:45]}")
    else:
        print(f"ERROR: {doi} -> {res.get('error')}")
    time.sleep(0.1)
