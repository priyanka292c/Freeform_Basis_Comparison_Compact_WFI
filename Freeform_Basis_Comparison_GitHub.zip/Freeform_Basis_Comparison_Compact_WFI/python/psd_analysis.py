﻿"""
psd_analysis.py
===============
Power Spectral Density (PSD) analysis of freeform surface maps.

Decomposes surface sag into:
  LSF  - Low Spatial Frequency  (f < f_LSF  cycles/mm)
  MSF  - Mid Spatial Frequency  (f_LSF <= f < f_HSF cycles/mm)
  HSF  - High Spatial Frequency (f >= f_HSF cycles/mm)

PSD is computed via 2-D FFT with a Hann window to reduce spectral leakage.
Radially averaged PSD is returned for circularly symmetric surfaces.

Author: [Author Name] | Date: 2026-09-02 | RANDOM SEED: N/A
"""

import numpy as np
import pandas as pd
from pathlib import Path


def hann2d(N: int, M: int) -> np.ndarray:
    """2-D Hann window as outer product of two 1-D Hann windows."""
    w1 = np.hanning(N)
    w2 = np.hanning(M)
    return np.outer(w1, w2)


def compute_psd_2d(z: np.ndarray, dx: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute 2-D PSD of surface sag map z [mm] with pixel size dx [mm].

    Returns
    -------
    fx, fy : spatial frequency axes [cycles/mm]
    psd2d  : 2-D power spectral density [mm^3] (mm^2 per spatial freq^2)
    """
    N, M = z.shape
    window = hann2d(N, M)
    # Normalise window
    win_norm = np.sqrt((window**2).mean())
    z_win = z * window / win_norm

    fft2 = np.fft.fftshift(np.fft.fft2(z_win))
    psd2d = (np.abs(fft2)**2) * (dx**2) / (N * M)

    fx = np.fft.fftshift(np.fft.fftfreq(M, d=dx))
    fy = np.fft.fftshift(np.fft.fftfreq(N, d=dx))
    return fx, fy, psd2d


def radial_psd(fx: np.ndarray, fy: np.ndarray,
               psd2d: np.ndarray,
               n_bins: int = 200) -> tuple[np.ndarray, np.ndarray]:
    """
    Radially average 2-D PSD to produce 1-D PSD(f).

    Parameters
    ----------
    n_bins : number of radial frequency bins

    Returns
    -------
    f_rad  : radial spatial frequency [cycles/mm]
    psd1d  : radially averaged PSD [mm^3]
    """
    FX, FY = np.meshgrid(fx, fy)
    FR = np.sqrt(FX**2 + FY**2)
    f_max = FR.max()
    f_bins = np.linspace(0, f_max, n_bins + 1)
    psd1d = np.zeros(n_bins)
    f_rad = 0.5 * (f_bins[:-1] + f_bins[1:])

    for i in range(n_bins):
        mask = (FR >= f_bins[i]) & (FR < f_bins[i+1])
        if mask.any():
            psd1d[i] = psd2d[mask].mean()

    return f_rad, psd1d


def bandpass_rms(f_rad: np.ndarray, psd1d: np.ndarray,
                 f_lo: float, f_hi: float, dx: float) -> float:
    """
    Compute RMS surface error in spatial frequency band [f_lo, f_hi] cycles/mm.

    Uses trapezoidal integration of PSD in the band.
    """
    mask = (f_rad >= f_lo) & (f_rad < f_hi)
    if not mask.any():
        return 0.0
    return float(np.sqrt(np.trapezoid(psd1d[mask], f_rad[mask])))


def analyse_surface(z: np.ndarray, dx: float,
                    f_lsf_max: float = 1.0,
                    f_msf_max: float = 10.0,
                    label: str = "surface") -> dict:
    """
    Full PSD analysis of a surface sag map.

    Parameters
    ----------
    z         : sag map [mm], shape (N, N)
    dx        : pixel size [mm]
    f_lsf_max : upper LSF boundary [cycles/mm]
    f_msf_max : upper MSF boundary [cycles/mm]
    label     : identifier for output

    Returns
    -------
    result : dict with PSD data and band RMS values
    """
    fx, fy, psd2d = compute_psd_2d(z, dx)
    f_rad, psd1d = radial_psd(fx, fy, psd2d)

    rms_lsf = bandpass_rms(f_rad, psd1d, 0.0,       f_lsf_max, dx)
    rms_msf = bandpass_rms(f_rad, psd1d, f_lsf_max, f_msf_max, dx)
    rms_hsf = bandpass_rms(f_rad, psd1d, f_msf_max, f_rad.max(), dx)
    rms_total = float(np.sqrt(np.mean((z - z.mean())**2)))

    return {
        "label":     label,
        "f_rad":     f_rad,
        "psd1d":     psd1d,
        "fx":        fx,
        "fy":        fy,
        "psd2d":     psd2d,
        "rms_lsf":   rms_lsf,
        "rms_msf":   rms_msf,
        "rms_hsf":   rms_hsf,
        "rms_total": rms_total,
        "f_lsf_max": f_lsf_max,
        "f_msf_max": f_msf_max,
    }


def save_psd_csv(results: list[dict], out_path: Path) -> None:
    """Save radial PSD data for all representations to a single CSV."""
    rows = []
    for r in results:
        for f, p in zip(r["f_rad"], r["psd1d"]):
            rows.append({"surface": r["label"], "f_cycles_per_mm": f, "psd_mm3": p})
    df = pd.DataFrame(rows)
    df.to_csv(out_path, index=False)
    print(f"PSD data saved: {out_path}")


if __name__ == "__main__":
    print("psd_analysis.py: module loaded. Import and call analyse_surface().")

