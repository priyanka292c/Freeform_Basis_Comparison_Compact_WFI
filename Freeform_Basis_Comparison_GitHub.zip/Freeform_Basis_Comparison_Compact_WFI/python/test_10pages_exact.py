import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Update \enlargethispage on Page 9 and Page 10
# Before section Discussion (Page 9)
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Discussion\}',
             r'\\enlargethispage{3\\baselineskip}\n\\section{Discussion}',
             tex)

# Before Scope and Limitations (Page 10)
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Scope and Limitations\}',
             r'\\enlargethispage{3\\baselineskip}\n\\section{Scope and Limitations}',
             tex)

# 2. Tighten itemsep in bibliography by 0.5pt
tex = tex.replace(r'\setlength{\itemsep}{-1.5pt}', r'\setlength{\itemsep}{-2.0pt}')

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex with enlargements and -2.0pt itemsep. Compiling...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
