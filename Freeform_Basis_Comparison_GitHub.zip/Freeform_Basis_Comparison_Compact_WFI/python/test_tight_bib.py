import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/bib_80_clean.tex', 'r', encoding='utf-8') as f:
    bib = f.read()

# Remove empty lines from bib
bib_lines = [l for l in bib.split('\n') if l.strip()]
# Add tight spacing
bib_header = r"""\begin{thebibliography}{80}
\fontsize{4.5pt}{5.2pt}\selectfont
\setlength{\itemsep}{-2.5pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}"""

bib_lines[0] = bib_header
# Remove previous font/spacing lines if they were separate
clean_bib_lines = []
for l in bib_lines:
    if l.startswith(r'\fontsize') or l.startswith(r'\setlength'):
        continue
    clean_bib_lines.append(l)

clean_bib = "\n".join(clean_bib_lines)

with open('manuscript/bib_80_clean.tex', 'w', encoding='utf-8') as f:
    f.write(clean_bib)

# Update main.tex
with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

bib_pattern = re.compile(r'\\begin\{thebibliography\}.*?\\end\{thebibliography\}', re.DOTALL)
tex = bib_pattern.sub(lambda m: clean_bib, tex)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Compiling main.tex...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
