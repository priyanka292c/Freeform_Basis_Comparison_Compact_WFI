import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.path import Path as MPath
from pathlib import Path

def generate_clean_fig02():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans", "Helvetica", "sans-serif"],
        "font.size": 9.0,
        "figure.dpi": 300,
        "text.antialiased": True
    })

    fig, ax = plt.subplots(figsize=(11.5, 5.8), dpi=300)
    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#fafbfc")

    # Coordinate boundaries
    ax.set_xlim(-28, 192)
    ax.set_ylim(-38, 38)
    ax.set_xlabel("Optical Axis Position Z [mm]", fontsize=10, fontweight="bold", labelpad=8, color="#0f172a")
    ax.set_ylabel("Meridional Coordinate Y [mm]", fontsize=10, fontweight="bold", labelpad=8, color="#0f172a")
    ax.grid(True, linestyle="--", alpha=0.45, color="#cbd5e1")

    # Mechanical reference axis (Y = 0)
    ax.axhline(0, color="#94a3b8", linestyle=":", linewidth=1.1, alpha=0.8, zorder=1)
    ax.text(147, 1.2, "Optical Reference Axis (Y = 0)", fontsize=7.2, color="#64748b", fontstyle="italic", zorder=2)

    # =========================================================================
    # 1. OPTICAL COMPONENTS
    # =========================================================================

    # (A) Entrance Pupil (Stop) at Z = 0
    ep_y_top = 10.0
    ep_y_bot = -10.0
    # Aperture blades (upper and lower)
    ax.plot([0, 0], [ep_y_top, 20.0], color="#334155", linewidth=3.5, solid_capstyle="butt", zorder=4)
    ax.plot([0, 0], [ep_y_bot, -20.0], color="#334155", linewidth=3.5, solid_capstyle="butt", zorder=4)
    ax.plot([-2, 2], [ep_y_top, ep_y_top], color="#0f172a", linewidth=2.0, zorder=4)
    ax.plot([-2, 2], [ep_y_bot, ep_y_bot], color="#0f172a", linewidth=2.0, zorder=4)
    # Clear aperture indicator line
    ax.plot([0, 0], [ep_y_bot, ep_y_top], color="#0284c7", linewidth=1.0, linestyle="--", alpha=0.7, zorder=3)

    # (B) Primary Mirror (M1) - Concave Reflector
    y_m1 = np.linspace(2.5, 23.5, 120)
    # Off-axis concave sag profile
    z_m1 = 145.0 - ((y_m1 - 13.0)**2) / 85.0
    m1_thick = 8.0
    z_m1_back = z_m1 + m1_thick
    poly_m1_z = np.concatenate([z_m1, z_m1_back[::-1]])
    poly_m1_y = np.concatenate([y_m1, y_m1[::-1]])
    ax.fill(poly_m1_z, poly_m1_y, color="#e0f2fe", edgecolor="#0284c7", linewidth=1.6, zorder=5)
    ax.plot(z_m1, y_m1, color="#0369a1", linewidth=3.0, zorder=6)

    # (C) Secondary Mirror (M2) - Convex Reflector
    y_m2 = np.linspace(-21.5, -6.5, 120)
    # Off-axis convex sag profile
    z_m2 = 25.0 + ((y_m2 + 14.0)**2) / 48.0
    m2_thick = 6.5
    z_m2_back = z_m2 - m2_thick
    poly_m2_z = np.concatenate([z_m2, z_m2_back[::-1]])
    poly_m2_y = np.concatenate([y_m2, y_m2[::-1]])
    ax.fill(poly_m2_z, poly_m2_y, color="#dcfce7", edgecolor="#16a34a", linewidth=1.6, zorder=5)
    ax.plot(z_m2, y_m2, color="#15803d", linewidth=3.0, zorder=6)

    # (D) Focal Plane Array (CMOS Detector) at Z = 108 mm, Y = -20 mm, Tilt = +3.5 deg
    tilt_rad = np.radians(3.5)
    y_det = np.linspace(-27.5, -12.5, 60)
    z_det = 108.0 + (y_det + 20.0) * np.tan(tilt_rad)
    det_thick = 5.0
    z_det_back = z_det + det_thick * np.cos(tilt_rad)
    y_det_back = y_det - det_thick * np.sin(tilt_rad)
    poly_det_z = np.concatenate([z_det, z_det_back[::-1]])
    poly_det_y = np.concatenate([y_det, y_det_back[::-1]])
    ax.fill(poly_det_z, poly_det_y, color="#fee2e2", edgecolor="#dc2626", linewidth=1.6, zorder=5)
    ax.plot(z_det, y_det, color="#b91c1c", linewidth=3.2, zorder=6)

    # =========================================================================
    # 2. OPTICAL RAY TRACING WITH TRANSLUCENT FOOTPRINT BUNDLES
    # =========================================================================
    fields = [
        {
            "angle": 0.0, "name": r"On-Axis ($0.0^\circ$)",
            "line_col": "#1d4ed8", "fill_col": "#bfdbfe", "alpha_fill": 0.22,
        },
        {
            "angle": 4.0, "name": r"Upper FoV ($+4.0^\circ$)",
            "line_col": "#ea580c", "fill_col": "#fed7aa", "alpha_fill": 0.22,
        },
        {
            "angle": -4.0, "name": r"Lower FoV ($-4.0^\circ$)",
            "line_col": "#7c3aed", "fill_col": "#e9d5ff", "alpha_fill": 0.22,
        },
    ]

    for fld in fields:
        ang_deg = fld["angle"]
        ang_rad = np.radians(ang_deg)
        col = fld["line_col"]
        fcol = fld["fill_col"]
        afill = fld["alpha_fill"]

        # Detector focal position
        det_foc_y = -20.0 + ang_deg * 1.62
        det_foc_z = 108.0 + (det_foc_y + 20.0) * np.tan(tilt_rad)

        # 3 rays: upper marginal (py = +10), chief (py = 0), lower marginal (py = -10)
        rays_pts = []
        for py in [10.0, 0.0, -10.0]:
            # Launch from Z = -28 mm
            z0 = -28.0
            y0 = py - np.tan(ang_rad) * (-28.0)
            
            # Hit pupil at Z = 0
            z_ep = 0.0
            y_ep = py
            
            # Hit M1
            y_m1_hit = 13.0 + py * 0.54 + ang_deg * 0.95
            z_m1_hit = 145.0 - ((y_m1_hit - 13.0)**2) / 85.0
            
            # Hit M2
            y_m2_hit = -14.0 + py * 0.35 - ang_deg * 0.72
            z_m2_hit = 25.0 + ((y_m2_hit + 14.0)**2) / 48.0
            
            rays_pts.append({
                "p0": (z0, y0),
                "pep": (z_ep, y_ep),
                "pm1": (z_m1_hit, y_m1_hit),
                "pm2": (z_m2_hit, y_m2_hit),
                "pdet": (det_foc_z, det_foc_y),
                "is_chief": (py == 0.0)
            })

        r_up = rays_pts[0]
        r_ch = rays_pts[1]
        r_lo = rays_pts[2]

        # Shaded beam bundle 1: Entrance to M1
        poly_sec1_z = [r_up["p0"][0], r_up["pep"][0], r_up["pm1"][0], r_lo["pm1"][0], r_lo["pep"][0], r_lo["p0"][0]]
        poly_sec1_y = [r_up["p0"][1], r_up["pep"][1], r_up["pm1"][1], r_lo["pm1"][1], r_lo["pep"][1], r_lo["p0"][1]]
        ax.fill(poly_sec1_z, poly_sec1_y, color=fcol, alpha=afill, zorder=2)

        # Shaded beam bundle 2: M1 to M2
        poly_sec2_z = [r_up["pm1"][0], r_lo["pm1"][0], r_lo["pm2"][0], r_up["pm2"][0]]
        poly_sec2_y = [r_up["pm1"][1], r_lo["pm1"][1], r_lo["pm2"][1], r_up["pm2"][1]]
        ax.fill(poly_sec2_z, poly_sec2_y, color=fcol, alpha=afill, zorder=2)

        # Shaded beam bundle 3: M2 to Focal Plane
        poly_sec3_z = [r_up["pm2"][0], r_lo["pm2"][0], r_lo["pdet"][0], r_up["pdet"][0]]
        poly_sec3_y = [r_up["pm2"][1], r_lo["pm2"][1], r_lo["pdet"][1], r_up["pdet"][1]]
        ax.fill(poly_sec3_z, poly_sec3_y, color=fcol, alpha=afill, zorder=2)

        # Draw the crisp ray lines
        for r in rays_pts:
            if r["is_chief"]:
                # Chief ray: distinct dashed stroke
                ax.plot([r["p0"][0], r["pep"][0], r["pm1"][0], r["pm2"][0], r["pdet"][0]],
                        [r["p0"][1], r["pep"][1], r["pm1"][1], r["pm2"][1], r["pdet"][1]],
                        color=col, linewidth=1.4, linestyle="--", zorder=3)
            else:
                # Marginal rays: thin crisp solid lines
                ax.plot([r["p0"][0], r["pep"][0], r["pm1"][0], r["pm2"][0], r["pdet"][0]],
                        [r["p0"][1], r["pep"][1], r["pm1"][1], r["pm2"][1], r["pdet"][1]],
                        color=col, linewidth=0.9, linestyle="-", alpha=0.85, zorder=3)

    # =========================================================================
    # 3. CALLOUT CARDS (CLEAN, ELEGANT & STRICTLY NON-OVERLAPPING)
    # =========================================================================
    
    # (A) Entrance Pupil Callout (Clean label in lower clearance zone below Stop)
    ax.annotate(
        r"$\mathbf{Entrance\ Pupil\ (Stop)}$" + "\n" + r"$D_\mathrm{EP} = 20.0\,\mathrm{mm}$",
        xy=(0, -14.0), xytext=(-12, -18.0),
        fontsize=7.4, color="#1e293b",
        bbox=dict(boxstyle="round,pad=0.35", facecolor="#f8fafc", edgecolor="#475569", lw=1.1, alpha=0.95),
        arrowprops=dict(arrowstyle="-|>", color="#334155", lw=1.2),
        zorder=8, ha="center", va="center"
    )

    # (B) Primary Mirror Callout (In dedicated clear zone to the right of M1)
    ax.annotate(
        r"$\mathbf{Primary\ Mirror\ (M1)}$" + "\n"
        r"$R_1 = -80.0\,\mathrm{mm},\; k_1 = -0.50$" + "\n"
        r"Clear Aperture: $23.5\,\mathrm{mm}$" + "\n"
        r"(Freeform sag $\Delta z_1$)",
        xy=(145, 17.0), xytext=(171, 18.5),
        fontsize=7.3, color="#0c4a6e",
        bbox=dict(boxstyle="round,pad=0.35", facecolor="#f0f9ff", edgecolor="#0284c7", lw=1.2, alpha=0.96),
        arrowprops=dict(arrowstyle="-|>", color="#0284c7", lw=1.2),
        zorder=8, ha="center", va="center"
    )

    # (C) Secondary Mirror Callout
    ax.annotate(
        r"$\mathbf{Secondary\ Mirror\ (M2)}$" + "\n"
        r"$R_2 = -20.0\,\mathrm{mm},\; k_2 = -2.00$" + "\n"
        r"Clear Aperture: $16.5\,\mathrm{mm}$ (Freeform sag $\Delta z_2$)",
        xy=(25, -21.5), xytext=(22, -31.5),
        fontsize=7.6, color="#14532d",
        bbox=dict(boxstyle="round,pad=0.35", facecolor="#f0fdf4", edgecolor="#16a34a", lw=1.2, alpha=0.95),
        arrowprops=dict(arrowstyle="-|>", color="#16a34a", lw=1.2),
        zorder=8, ha="center"
    )

    # (D) Focal Plane Callout
    ax.annotate(
        r"$\mathbf{CMOS\ Focal\ Plane\ Array}$" + "\n"
        r"$4096 \times 3072$ pixels ($3.45\,\mu\mathrm{m}$ pitch)" + "\n"
        r"Field Tilt $\theta_y = +3.5^\circ$",
        xy=(108, -27.5), xytext=(98, -34.0),
        fontsize=7.6, color="#7f1d1d",
        bbox=dict(boxstyle="round,pad=0.35", facecolor="#fef2f2", edgecolor="#dc2626", lw=1.2, alpha=0.95),
        arrowprops=dict(arrowstyle="-|>", color="#dc2626", lw=1.2),
        zorder=8, ha="center"
    )

    # =========================================================================
    # 4. DIMENSIONS IN DEDICATED ZERO-RAY CLEARANCE ZONES
    # =========================================================================
    
    # (A) Total Track Dimension (At Top: Y = +34.2 mm, Z = 0 to 145 mm)
    y_dim_track = 34.0
    ax.plot([0, 145], [y_dim_track, y_dim_track], color="#1e293b", linewidth=1.2, zorder=6)
    ax.plot([0, 0], [y_dim_track - 1.2, y_dim_track + 1.2], color="#1e293b", linewidth=1.5, zorder=6)
    ax.plot([145, 145], [y_dim_track - 1.2, y_dim_track + 1.2], color="#1e293b", linewidth=1.5, zorder=6)
    ax.text(72.5, y_dim_track + 0.9, r"$\mathbf{Total\ Track\ Length\ } L_\mathrm{track} = 145.0\,\mathrm{mm} \leq 250.0\,\mathrm{mm}$",
            ha="center", va="bottom", fontsize=7.8, color="#0f172a",
            bbox=dict(boxstyle="round,pad=0.2", facecolor="#ffffff", edgecolor="#cbd5e1", lw=0.8), zorder=7)

    # (B) Mirror Separation d12 = 120.0 mm (At Upper Clearance Zone: Y = +28.8 mm, Z = 25 to 145 mm)
    y_dim_d12 = 28.8
    ax.plot([25, 145], [y_dim_d12, y_dim_d12], color="#475569", linewidth=1.1, linestyle="--", zorder=6)
    ax.plot([25, 25], [y_dim_d12 - 1.0, y_dim_d12 + 1.0], color="#475569", linewidth=1.3, zorder=6)
    ax.plot([145, 145], [y_dim_d12 - 1.0, y_dim_d12 + 1.0], color="#475569", linewidth=1.3, zorder=6)
    ax.text(85, y_dim_d12 + 0.8, r"Mirror Separation $d_{12} = 120.0\,\mathrm{mm}$",
            ha="center", va="bottom", fontsize=7.5, color="#334155",
            bbox=dict(boxstyle="round,pad=0.15", facecolor="#ffffff", edgecolor="#e2e8f0", lw=0.6, alpha=0.92), zorder=7)

    # (C) Back Focal Length BFL = 83.0 mm (At Lower Dedicated Zone: Y = -0.8 mm, Z = 25 to 108 mm)
    y_dim_bfl = -0.8
    ax.plot([25, 108], [y_dim_bfl, y_dim_bfl], color="#475569", linewidth=1.1, linestyle="--", zorder=4)
    ax.plot([25, 25], [y_dim_bfl - 1.0, y_dim_bfl + 1.0], color="#475569", linewidth=1.3, zorder=4)
    ax.plot([108, 108], [y_dim_bfl - 1.0, y_dim_bfl + 1.0], color="#475569", linewidth=1.3, zorder=4)
    ax.text(66.5, y_dim_bfl - 0.9, r"Back Focal Length $\mathrm{BFL} = 83.0\,\mathrm{mm}$",
            ha="center", va="top", fontsize=7.5, color="#334155",
            bbox=dict(boxstyle="round,pad=0.15", facecolor="#ffffff", edgecolor="#e2e8f0", lw=0.6, alpha=0.92), zorder=5)

    # =========================================================================
    # 5. ELEGANT SPECIFICATIONS INSET TABLE CARD (LOWER RIGHT)
    # =========================================================================
    card_x = 139
    card_y = -35.5
    card_w = 47
    card_h = 24.5

    card_rect = mpatches.FancyBboxPatch(
        (card_x, card_y), card_w, card_h,
        boxstyle="round,pad=0.6,rounding_size=1.2",
        facecolor="#ffffff", edgecolor="#94a3b8", linewidth=1.2, zorder=6
    )
    ax.add_patch(card_rect)

    card_tag = mpatches.FancyBboxPatch(
        (card_x + 1.0, card_y + card_h - 3.4), card_w - 2.0, 2.8,
        boxstyle="round,pad=0.2,rounding_size=0.6",
        facecolor="#0f172a", edgecolor="none", zorder=7
    )
    ax.add_patch(card_tag)
    ax.text(card_x + card_w/2, card_y + card_h - 2.0, "OPTICAL SPECIFICATIONS",
            ha="center", va="center", fontsize=7.5, fontweight="bold", color="#ffffff", zorder=8)

    specs = [
        ("Effective Focal Length", "150.0 mm"),
        ("Working Speed", "F/7.5"),
        ("Entrance Pupil Diam.", "20.0 mm"),
        ("Field of View", "±4.0° (Circular)"),
        ("Spectral Band", "450–900 nm"),
        ("Optical Architecture", "Off-Axis 2-Mirror"),
        ("Active Freeform Mirrors", "M1 & M2 (N = 6)")
    ]

    y_row = card_y + card_h - 5.5
    for param, val in specs:
        ax.text(card_x + 2.0, y_row, param + ":", fontsize=6.8, color="#475569", va="center", zorder=7)
        ax.text(card_x + card_w - 2.0, y_row, val, fontsize=6.8, fontweight="bold", color="#0f172a",
                ha="right", va="center", zorder=7)
        y_row -= 2.5

    # =========================================================================
    # 6. COMPACT ELEGANT LEGEND (UPPER LEFT CORNER)
    # =========================================================================
    leg_x = -20.5
    leg_y = 15.2
    leg_w = 38.5
    leg_h = 16.5

    leg_rect = mpatches.FancyBboxPatch(
        (leg_x, leg_y), leg_w, leg_h,
        boxstyle="round,pad=0.4,rounding_size=1.0",
        facecolor="#ffffff", edgecolor="#cbd5e1", linewidth=1.0, zorder=6
    )
    ax.add_patch(leg_rect)

    ax.text(leg_x + 2.0, leg_y + leg_h - 2.0, "Ray Footprints & Fields", fontsize=7.4, fontweight="bold", color="#0f172a", zorder=7)

    leg_items = [
        (fields[0]["line_col"], fields[0]["fill_col"], r"On-Axis ($0.0^\circ$ FoV)"),
        (fields[1]["line_col"], fields[1]["fill_col"], r"Upper Field ($+4.0^\circ$ FoV)"),
        (fields[2]["line_col"], fields[2]["fill_col"], r"Lower Field ($-4.0^\circ$ FoV)"),
    ]

    y_leg = leg_y + leg_h - 4.6
    for lcol, fcol, lbl in leg_items:
        p_patch = mpatches.Rectangle((leg_x + 2.2, y_leg - 1.0), 4.2, 2.0, facecolor=fcol, edgecolor=lcol, lw=1.1, zorder=7)
        ax.add_patch(p_patch)
        ax.plot([leg_x + 2.2, leg_x + 6.4], [y_leg, y_leg], color=lcol, lw=1.1, linestyle="--", zorder=8)
        ax.text(leg_x + 8.5, y_leg, lbl, fontsize=6.8, color="#1e293b", va="center", zorder=7)
        y_leg -= 2.6

    ax.plot([leg_x + 2.2, leg_x + 6.4], [y_leg, y_leg], color="#64748b", lw=0.9, linestyle="-", zorder=7)
    ax.text(leg_x + 8.5, y_leg, "Marginal Rays (Solid)", fontsize=6.3, color="#64748b", va="center", zorder=7)
    y_leg -= 2.0
    ax.plot([leg_x + 2.2, leg_x + 6.4], [y_leg, y_leg], color="#64748b", lw=1.1, linestyle="--", zorder=7)
    ax.text(leg_x + 8.5, y_leg, "Chief Ray (Dashed)", fontsize=6.3, color="#64748b", va="center", zorder=7)

    # Save to both source and publication folders
    out_png = Path("figures/source/fig02_baseline_layout.png")
    out_pub = Path("figures/publication/fig02_baseline_layout.png")
    out_svg = Path("figures/publication/fig02_baseline_layout.svg")
    out_png.parent.mkdir(parents=True, exist_ok=True)
    out_pub.parent.mkdir(parents=True, exist_ok=True)

    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.savefig(out_pub, dpi=300, bbox_inches="tight")
    plt.savefig(out_svg, bbox_inches="tight")
    plt.close()
    print("Clean Figure 2 generated successfully!")

if __name__ == "__main__":
    generate_clean_fig02()
