import json
import re
import html
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Replace item 32 (Davis2018) with Bauer, Schiesser, Rolland 2018 Nature Communications
for item in data:
    if item['key'] == 'Davis2018':
        item['title'] = "Starting geometry creation and design method for freeform optics"
        item['journal'] = "Nature Communications"
        item['year'] = 2018
        item['volume'] = "9"
        item['issue'] = "1"
        item['page'] = "1756"
        item['doi'] = "10.1038/s41467-018-04186-9"
        item['authors'] = ["A. Bauer", "E. M. Schiesser", "J. P. Rolland"]
        item['key'] = "Bauer2018NatComm"

# Ensure all 80 items are clean
cleaned_items = []
seen_dois = set()

for i, item in enumerate(data, 1):
    doi = item['doi'].strip()
    title = html.unescape(item['title']).strip()
    title = re.sub(r'\s+', ' ', title)
    
    journal = html.unescape(item.get('journal', '')).strip()
    journal = re.sub(r'&amp;', r'\&', journal)
    journal = re.sub(r'&', r'\&', journal)
    
    year = str(item.get('year', '')).strip()
    volume = str(item.get('volume', '')).strip()
    page = str(item.get('page', '')).strip()
    
    # Clean authors
    raw_authors = item.get('authors', [])
    if isinstance(raw_authors, list):
        # Format author list: "A. Author, B. Author, and C. Author"
        auth_strs = []
        for a in raw_authors:
            cleaned_a = html.unescape(str(a)).strip()
            if cleaned_a:
                auth_strs.append(cleaned_a)
        if len(auth_strs) == 1:
            authors = auth_strs[0]
        elif len(auth_strs) == 2:
            authors = f"{auth_strs[0]} and {auth_strs[1]}"
        elif len(auth_strs) > 2:
            authors = ", ".join(auth_strs[:-1]) + f", and {auth_strs[-1]}"
        else:
            authors = "Anonymous"
    else:
        authors = html.unescape(str(raw_authors)).strip()
        
    authors = re.sub(r'&amp;', r'\&', authors)
    authors = re.sub(r'&', r'\&', authors)
    
    item_clean = {
        'order': i,
        'key': item['key'],
        'authors': authors,
        'title': title,
        'journal': journal,
        'year': year,
        'volume': volume,
        'page': page,
        'doi': doi
    }
    cleaned_items.append(item_clean)
    seen_dois.add(doi.lower())

print(f"Total entries: {len(cleaned_items)}")
print(f"Unique DOIs: {len(seen_dois)}")
assert len(cleaned_items) == 80, f"Expected 80, got {len(cleaned_items)}"
assert len(seen_dois) == 80, f"Expected 80 unique DOIs, got {len(seen_dois)}"

# Check for arXiv
arxiv_count = sum(1 for it in cleaned_items if 'arxiv' in it['doi'].lower() or 'arxiv' in it['journal'].lower())
print(f"arXiv entries: {arxiv_count}")
assert arxiv_count == 0, "No arXiv entries allowed!"

# Save finalized json
with open('python/verified_80_final.json', 'w', encoding='utf-8') as f:
    json.dump(cleaned_items, f, indent=2, ensure_ascii=False)

# Generate LaTeX bibliography
bib_lines = []
bib_lines.append(r"\begin{thebibliography}{80}")
bib_lines.append(r"\scriptsize")
bib_lines.append(r"\setlength{\itemsep}{0pt plus 0.2pt}")
bib_lines.append(r"\setlength{\parskip}{0pt}")
bib_lines.append("")

for it in cleaned_items:
    # Format: \bibitem{key} Authors, ``Title,'' \textit{Journal}, vol.~X, no.~Y, pp.~Z, Year. \doi{DOI}
    vol_str = f"vol.~{it['volume']}, " if it['volume'] else ""
    page_str = f"pp.~{it['page']}, " if it['page'] else ""
    year_str = f"{it['year']}." if it['year'] else ""
    
    entry = (
        f"\\bibitem{{{it['key']}}}\n"
        f"{it['authors']}, ``{it['title']},'' \\textit{{{it['journal']}}}, "
        f"{vol_str}{page_str}{year_str} \\doi{{{it['doi']}}}\n"
    )
    bib_lines.append(entry)

bib_lines.append(r"\end{thebibliography}")

with open('manuscript/bib_80_clean.tex', 'w', encoding='utf-8') as f:
    f.write("\n".join(bib_lines))

print("Successfully written manuscript/bib_80_clean.tex with 80 verified references!")
