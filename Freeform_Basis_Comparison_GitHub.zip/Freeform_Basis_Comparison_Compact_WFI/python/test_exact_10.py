import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Enlarge Page 10 explicitly before Conclusions
tex = re.sub(r'\\section\{Conclusions\}',
             r'\\enlargethispage{3\\baselineskip}\n\\section{Conclusions}',
             tex)

# 2. Tighten bibliography slightly: 4.3pt/4.8pt with itemsep -0.5pt
old_bib = re.search(r'\\begin\{thebibliography\}\{80\}.*?(?=\\bibitem)', tex, re.DOTALL)
if old_bib:
    new_bib = r"""\begin{thebibliography}{80}
\fontsize{4.3pt}{4.8pt}\selectfont
\setlength{\itemsep}{-0.5pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}
"""
    tex = tex[:old_bib.start()] + new_bib + tex[old_bib.end():]

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex with Page 10 enlargement. Compiling two passes...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
