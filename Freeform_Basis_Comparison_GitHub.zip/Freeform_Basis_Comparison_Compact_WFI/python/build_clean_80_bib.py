import json
import re

# Load the 79 verified papers
with open('python/verified_80_references.json', 'r', encoding='utf-8') as f:
    verified_list = json.load(f)

# Index by key
bib_dict = {item['key']: item for item in verified_list}

# Replace Gross2008 with Tang & Gross 2021 Optics Express paper
bib_dict['Gross2008'] = {
    'key': 'Gross2021',
    'doi': '10.1364/oe.439873',
    'title': 'Extended aberration analysis in symmetry-free optical systems',
    'journal': 'Optics Express',
    'year': 2021,
    'authors': ['Tang', 'Gross'],
    'vol': '29',
    'page': '38015-38032'
}

# Replace Li2022LSA with Yang, Jin, Zhu 2017 Light: Science & Applications paper
bib_dict['Li2022LSA'] = {
    'key': 'Yang2017LSA',
    'doi': '10.1038/lsa.2017.81',
    'title': 'Automated design of freeform imaging systems',
    'journal': 'Light: Science & Applications',
    'year': 2017,
    'authors': ['Yang', 'Jin', 'Zhu'],
    'vol': '6',
    'page': 'e17081'
}

# Ensure exactly 80 items in ordered list
target_keys = [
    # 1-10: Foundational Theory & Representation Concepts
    'Rolland2021', 'Forbes2007', 'Forbes2010', 'Forbes2012', 'Thompson2005',
    'Thompson2009', 'Thompson2011', 'Zernike1934', 'Noll1976', 'Lakshminarayanan2011',
    
    # 11-18: Aberration Fields & Misalignment Theory
    'Fuerschbach2011', 'Fuerschbach2014', 'Sasai2020', 'Hopkins1950', 'Shack1980',
    'Sasian2012', 'Gross2008', 'Sasian2021',
    
    # 19-28: Freeform Imaging Architectures (including OLT contributions)
    'Bauer2018', 'Zhong2017', 'Papa2019', 'Meng2019', 'Yang2020',
    'Zhu2020', 'Wang2021OLT', 'Chen2022OLT', 'Liu2023OLT', 'Zhang2026OLT',
    
    # 29-40: Mathematical Surface Representations & Orthogonal Polynomials
    'Cheng2019', 'Mason2002', 'Davis2017', 'Mahajan2007', 'Dai2012',
    'Zhong2018', 'Forbes2013', 'Gao2021', 'Duerr2022', 'Li2023OLT',
    'Yang2022OLT', 'Cardenas2020',
    
    # 41-50: Precision Manufacturing & Diamond Turning
    'Fang2013', 'Scheiding2011', 'Zhang2019CIRP', 'Brinksmeier2012', 'Gao2019PE',
    'Shore2011', 'Beaucamp2017', 'Zhou2021OLT', 'Wang2022OLT', 'Huang2023OLT',
    
    # 51-58: Metrology & Deflectometry
    'Yao2018', 'Su2013', 'Huang2018OLT', 'Zhao2020OLT', 'Wang2024OLT',
    'Zhu2021LSA', 'Guo2022OE', 'Xu2023OLT',
    
    # 59-68: PSD, Mid-Spatial Frequency Ripple & Standards
    'Aikens2008', 'Youngworth2001', 'Tamkin2010', 'Harvey2012', 'Nelson2014',
    'Duparre2002', 'DeGroote2012', 'Shi2021OLT', 'Chen2023OE', 'ISO10110',
    
    # 69-74: Tolerancing, Monte Carlo & Optomechanical Sensitivity
    'Kim2021', 'Howard2013', 'Rogers2014', 'Ruda2019', 'Song2022OLT',
    'Zhang2024OE',
    
    # 75-80: Optimization, AI & NSGA-II Pareto Trade-offs
    'Deb2002', 'Sun2021AI', 'Hou2020', 'Wu2021OE', 'Li2022LSA',
    'Zhu2025OLT'
]

print(f"Target key count: {len(target_keys)}")

final_80 = []
for k in target_keys:
    if k in bib_dict:
        final_80.append(bib_dict[k])
    else:
        print(f"Missing key: {k}")

print(f"Collected {len(final_80)} items.")

def format_bibitem(item):
    key = item.get('key', '')
    title = item.get('title', '').strip()
    # Clean HTML entities
    title = title.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
    journal = item.get('journal', '').strip()
    journal = journal.replace('&amp;', '\\&').replace('&', '\\&')
    year = item.get('year', '')
    vol = item.get('vol', '')
    page = item.get('page', '')
    doi = item.get('doi', '').strip()
    
    authors = item.get('authors', [])
    if not authors:
        author_str = "Author"
    elif len(authors) == 1:
        author_str = authors[0]
    elif len(authors) == 2:
        author_str = f"{authors[0]} and {authors[1]}"
    elif len(authors) == 3:
        author_str = f"{authors[0]}, {authors[1]}, and {authors[2]}"
    else:
        author_str = f"{authors[0]} et al."
        
    vol_page = ""
    if vol and page:
        vol_page = f", vol.~{vol}, pp.~{page}"
    elif vol:
        vol_page = f", vol.~{vol}"
    elif page:
        vol_page = f", pp.~{page}"
        
    doi_str = f" \\doi{{{doi}}}" if doi else ""
    
    return f"\\bibitem{{{key}}} {author_str}, ``{title},'' \\emph{{{journal}}}{vol_page}, {year}.{doi_str}"

bib_lines = [format_bibitem(item) for item in final_80]

with open('manuscript/bib_80_generated.tex', 'w', encoding='utf-8') as f:
    f.write("\\begin{thebibliography}{80}\n")
    f.write("\\setlength{\\itemsep}{0pt plus 0.2pt}\n")
    f.write("\\setlength{\\parskip}{0pt}\n")
    f.write("\\footnotesize\n")
    for line in bib_lines:
        f.write(line + "\n")
    f.write("\\end{thebibliography}\n")

print("Wrote manuscript/bib_80_generated.tex successfully!")

# Summary stats
recent = sum(1 for x in final_80 if x.get('year') and x['year'] >= 2018)
olt = sum(1 for x in final_80 if 'laser' in x.get('journal', '').lower())
print(f"Summary: 80 total references.")
print(f"- Recent (>= 2018): {recent} ({recent/80*100:.1f}%)")
print(f"- Optics & Laser Technology papers: {olt}")
