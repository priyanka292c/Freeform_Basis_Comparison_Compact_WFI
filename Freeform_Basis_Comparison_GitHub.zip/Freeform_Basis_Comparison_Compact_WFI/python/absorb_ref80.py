import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Enlarge Page 10 by 4 baselineskip
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Conclusions\}',
             r'\\enlargethispage{4\\baselineskip}\n\\section{Conclusions}',
             tex)

# 2. Tighten itemsep to -0.6pt
tex = tex.replace(r'\setlength{\itemsep}{-0.5pt}', r'\setlength{\itemsep}{-0.6pt}')

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex with 4 baselineskip enlargement. Compiling...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
