﻿"""
fci_calculator.py
=================
Freeform Complexity Index (FCI) computation.

FCI is a composite manufacturability-proxy index defined as:

    FCI = w1 * C_coeff + w2 * C_sag + w3 * C_slope + w4 * C_curv

where:
    C_coeff  = L2 norm of coefficients / reference L2 norm
    C_sag    = RMS sag departure / reference sag
    C_slope  = RMS surface slope / reference slope
    C_curv   = RMS curvature variation / reference curvature

All components are normalised to [0, 1] across the set of surfaces being compared.
Weights w1=0.25, w2=0.30, w3=0.30, w4=0.15 (equal emphasis on slope and sag;
curvature weighted less due to higher noise sensitivity).

These weights are a DESIGN CHOICE; sensitivity analysis over weight values is
performed in statistics_analysis.py.

Author: [Author Name] | Date: 2026-09-02 | RANDOM SEED: N/A
"""

import numpy as np
import pandas as pd
from pathlib import Path


# Default FCI weights (must sum to 1.0)
FCI_WEIGHTS = {
    "coeff":  0.25,
    "sag":    0.30,
    "slope":  0.30,
    "curv":   0.15,
}


def coeff_complexity(coeffs: dict | np.ndarray) -> dict:
    """
    Coefficient complexity metrics.

    Parameters
    ----------
    coeffs : dict {index: value} or 1-D array of coefficient values

    Returns
    -------
    dict with l1_norm, l2_norm, max_abs, n_coeffs
    """
    if isinstance(coeffs, dict):
        vals = np.array(list(coeffs.values()), dtype=float)
    else:
        vals = np.asarray(coeffs, dtype=float)
    return {
        "n_coeffs":  len(vals),
        "l1_norm":   float(np.sum(np.abs(vals))) if len(vals) > 0 else 0.0,
        "l2_norm":   float(np.sqrt(np.sum(vals**2))) if len(vals) > 0 else 0.0,
        "max_abs":   float(np.max(np.abs(vals))) if len(vals) > 0 else 0.0,
        "mean_abs":  float(np.mean(np.abs(vals))) if len(vals) > 0 else 0.0,
    }


def surface_complexity_metrics(z_departure: np.ndarray, dx: float) -> dict:
    """
    Surface geometry complexity metrics.

    Parameters
    ----------
    z_departure : sag departure from base conic [mm], shape (N, N)
    dx          : grid spacing [mm]

    Returns
    -------
    dict with pv_sag, rms_sag, max_slope, rms_slope, rms_curv
    """
    # Sag metrics
    pv_sag  = float(z_departure.max() - z_departure.min())
    rms_sag = float(np.sqrt(np.mean(z_departure**2)))

    # Slope metrics
    dzdx = np.gradient(z_departure, dx, axis=1)
    dzdy = np.gradient(z_departure, dx, axis=0)
    slope_mag = np.sqrt(dzdx**2 + dzdy**2)
    max_slope = float(slope_mag.max())
    rms_slope = float(np.sqrt(np.mean(slope_mag**2)))

    # Curvature metrics (mean curvature approximation)
    zxx = np.gradient(dzdx, dx, axis=1)
    zyy = np.gradient(dzdy, dx, axis=0)
    H = 0.5 * (zxx + zyy)
    rms_curv = float(np.sqrt(np.mean(H**2)))

    return {
        "pv_sag_mm":    pv_sag,
        "rms_sag_mm":   rms_sag,
        "max_slope":    max_slope,    # dimensionless (mm/mm)
        "rms_slope":    rms_slope,
        "rms_curv_mm1": rms_curv,     # mm^{-1}
    }


def compute_fci(coeff_metrics: dict,
                geom_metrics: dict,
                ref_values: dict | None = None,
                weights: dict | None = None) -> dict:
    """
    Compute Freeform Complexity Index.

    FCI = w1*C_coeff + w2*C_sag + w3*C_slope + w4*C_curv

    When ref_values is None, raw (un-normalised) components are returned.
    When ref_values is provided, each component is normalised by the reference.

    Parameters
    ----------
    coeff_metrics : output of coeff_complexity()
    geom_metrics  : output of surface_complexity_metrics()
    ref_values    : dict {"coeff_l2", "sag_rms", "slope_rms", "curv_rms"}
                    Reference normalization values (e.g. from baseline asphere)
    weights       : FCI weight dict; defaults to FCI_WEIGHTS

    Returns
    -------
    dict with individual components and FCI score
    """
    w = weights if weights is not None else FCI_WEIGHTS

    c_coeff = coeff_metrics["l2_norm"]
    c_sag   = geom_metrics["rms_sag_mm"]
    c_slope = geom_metrics["rms_slope"]
    c_curv  = geom_metrics["rms_curv_mm1"]

    if ref_values is not None:
        c_coeff /= (ref_values.get("coeff_l2", 1.0) or 1.0)
        c_sag   /= (ref_values.get("sag_rms",  1.0) or 1.0)
        c_slope /= (ref_values.get("slope_rms", 1.0) or 1.0)
        c_curv  /= (ref_values.get("curv_rms",  1.0) or 1.0)

    fci = (w["coeff"] * c_coeff +
           w["sag"]   * c_sag   +
           w["slope"] * c_slope +
           w["curv"]  * c_curv)

    return {
        "C_coeff":  c_coeff,
        "C_sag":    c_sag,
        "C_slope":  c_slope,
        "C_curv":   c_curv,
        "FCI":      fci,
        "w_coeff":  w["coeff"],
        "w_sag":    w["sag"],
        "w_slope":  w["slope"],
        "w_curv":   w["curv"],
    }


def batch_fci(surfaces: list[dict], dx: float,
              normalise: bool = True) -> pd.DataFrame:
    """
    Compute FCI for a list of surfaces and return a DataFrame.

    Each element of surfaces is a dict:
        {"label": str, "coeffs": dict, "z_departure": ndarray}

    Parameters
    ----------
    normalise : if True, normalise by the baseline (first surface)
    """
    rows = []
    ref_values = None

    for i, surf in enumerate(surfaces):
        cm = coeff_complexity(surf.get("coeffs", {}))
        gm = surface_complexity_metrics(surf["z_departure"], dx)
        if normalise and i == 0:
            ref_values = {
                "coeff_l2":  cm["l2_norm"] if cm["l2_norm"] > 0 else 1e-12,
                "sag_rms":   gm["rms_sag_mm"] if gm["rms_sag_mm"] > 0 else 1e-12,
                "slope_rms": gm["rms_slope"] if gm["rms_slope"] > 0 else 1e-12,
                "curv_rms":  gm["rms_curv_mm1"] if gm["rms_curv_mm1"] > 0 else 1e-12,
            }
        fci_result = compute_fci(cm, gm, ref_values)
        row = {"surface": surf["label"]}
        row.update(cm)
        row.update(gm)
        row.update(fci_result)
        rows.append(row)

    return pd.DataFrame(rows)


if __name__ == "__main__":
    print("fci_calculator.py: module loaded.")

