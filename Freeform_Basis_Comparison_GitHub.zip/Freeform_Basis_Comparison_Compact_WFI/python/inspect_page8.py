import pypdf
import sys
sys.stdout.reconfigure(encoding='utf-8')

reader = pypdf.PdfReader('manuscript/main.pdf')
text8 = reader.pages[7].extract_text()
print(f"Page 8 char count: {len(text8)}")
for line in text8.split('\n'):
    print("  ", line)
