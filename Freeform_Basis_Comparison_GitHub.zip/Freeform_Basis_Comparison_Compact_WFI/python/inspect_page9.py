import pypdf
import sys
sys.stdout.reconfigure(encoding='utf-8')

reader = pypdf.PdfReader('manuscript/main.pdf')
text = reader.pages[8].extract_text() # Page 9
print(f"Page 9 character count: {len(text)}")
for line in text.split('\n'):
    print(line)
