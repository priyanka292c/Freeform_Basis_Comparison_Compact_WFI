﻿"""
bibliography.py
===============
DOI verification and bibliography management.

Queries doi.org (via HTTP redirect) and Crossref API to:
  1. Resolve each DOI to its metadata
  2. Compare the retrieved title with the cited title
  3. Flag mismatches and update status in bibliography_verification.csv

Usage:
  python bibliography.py

Author: [Author Name] | Date: 2026-09-02
"""

import re
import time
import json
import requests
import pandas as pd
from pathlib import Path
from difflib import SequenceMatcher

BASE      = Path(__file__).parent.parent
REF_DIR   = BASE / "references"
REF_DIR.mkdir(exist_ok=True)

CROSSREF_API  = "https://api.crossref.org/works/{doi}"
DOI_BASE_URL  = "https://doi.org/"
HEADERS       = {"User-Agent": "FreeformOpticsResearch/1.0 (research; contact@example.com)"}
RATE_LIMIT_S  = 1.0   # seconds between API calls


def normalise_title(t: str) -> str:
    """Lower-case, strip punctuation, collapse whitespace."""
    t = t.lower()
    t = re.sub(r"[^a-z0-9\s]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def title_similarity(t1: str, t2: str) -> float:
    """Return SequenceMatcher similarity score [0, 1]."""
    return SequenceMatcher(None, normalise_title(t1), normalise_title(t2)).ratio()


def verify_doi(doi: str, cited_title: str) -> dict:
    """
    Verify a single DOI via Crossref API.

    Returns dict with status, retrieved title, and similarity score.
    """
    if not doi or doi.strip().lower() in ("", "doi unavailable", "n/a"):
        return {"doi": doi, "status": "NO_DOI",
                "retrieved_title": "", "similarity": -1.0,
                "note": "DOI not provided"}

    url = CROSSREF_API.format(doi=doi.strip())
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        if resp.status_code == 404:
            return {"doi": doi, "status": "DOI_NOT_FOUND",
                    "retrieved_title": "", "similarity": 0.0,
                    "note": "DOI returned 404"}
        resp.raise_for_status()
        data  = resp.json().get("message", {})
        title_list = data.get("title", [])
        retr_title = title_list[0] if title_list else ""
        sim = title_similarity(cited_title, retr_title)
        status = "VERIFIED" if sim >= 0.70 else "TITLE_MISMATCH"
        return {
            "doi":             doi,
            "status":          status,
            "retrieved_title": retr_title,
            "similarity":      round(sim, 4),
            "note":            "OK" if status == "VERIFIED" else
                               f"Similarity={sim:.2f} below threshold 0.70",
        }
    except requests.exceptions.Timeout:
        return {"doi": doi, "status": "TIMEOUT", "retrieved_title": "",
                "similarity": -1.0, "note": "Request timed out"}
    except Exception as exc:
        return {"doi": doi, "status": "ERROR", "retrieved_title": "",
                "similarity": -1.0, "note": str(exc)}


def verify_bibliography(refs: list[dict],
                        output_csv: Path,
                        delay: float = RATE_LIMIT_S) -> pd.DataFrame:
    """
    Verify all references and write bibliography_verification.csv.

    Parameters
    ----------
    refs : list of dicts with keys: ID, Authors, Title, Journal, Year,
           Volume, Issue, Pages, DOI, Publisher
    """
    results = []
    dois_seen = set()
    titles_seen = set()

    for i, ref in enumerate(refs):
        doi   = ref.get("DOI", "").strip()
        title = ref.get("Title", "").strip()
        print(f"  [{i+1}/{len(refs)}] Verifying: {doi or 'NO_DOI'} — {title[:60]}...")

        # Duplicate check
        norm_title = normalise_title(title)
        dup_doi    = doi in dois_seen and doi != ""
        dup_title  = norm_title in titles_seen

        if dup_doi or dup_title:
            results.append({**ref,
                "DOI_Verified":   "DUPLICATE",
                "Retrieved_Title":"",
                "Similarity":     -1.0,
                "Duplicate_Check":"DUPLICATE_DOI" if dup_doi else "DUPLICATE_TITLE",
                "Status":         "REJECTED",
                "Verification_Date": "2026-09-02",
                "Note":           "Duplicate — excluded from bibliography"})
            continue

        if doi:
            dois_seen.add(doi)
        titles_seen.add(norm_title)

        ver = verify_doi(doi, title)
        results.append({
            **ref,
            "DOI_Verified":    ver["status"],
            "Retrieved_Title": ver["retrieved_title"],
            "Similarity":      ver["similarity"],
            "Duplicate_Check": "OK",
            "Status":          "VERIFIED" if ver["status"] == "VERIFIED"
                               else ("NEEDS_REVIEW" if ver["status"] == "NO_DOI"
                                     else "REJECTED"),
            "Verification_Date": "2026-09-02",
            "Note":              ver["note"],
        })
        time.sleep(delay)

    df = pd.DataFrame(results)
    df.to_csv(output_csv, index=False)
    n_ok  = (df["Status"] == "VERIFIED").sum()
    n_rej = (df["Status"] == "REJECTED").sum()
    print(f"\n  Bibliography: {n_ok} VERIFIED, {n_rej} REJECTED out of {len(df)}")
    return df


# ─── Reference list ────────────────────────────────────────────────────────────
# Only references with plausible DOIs are included here for verification.
# This list will be expanded by the user after manual Google Scholar checks.
REFERENCES = [
    {"ID":"R001","Authors":"Forbes, G.W.","Title":"Robust, efficient computational methods for axially symmetric optical aspheres",
     "Journal":"Optics Express","Year":2010,"Volume":18,"Issue":19,"Pages":"19700-19712",
     "DOI":"10.1364/OE.18.019700","Publisher":"Optica Publishing Group"},
    {"ID":"R002","Authors":"Forbes, G.W.","Title":"Characterizing the shape of freeform optics",
     "Journal":"Optics Express","Year":2012,"Volume":20,"Issue":3,"Pages":"2483-2499",
     "DOI":"10.1364/OE.20.002483","Publisher":"Optica Publishing Group"},
    {"ID":"R003","Authors":"Fang, F.Z. et al.","Title":"Manufacturing and measurement of freeform optics",
     "Journal":"CIRP Annals","Year":2013,"Volume":62,"Issue":2,"Pages":"823-846",
     "DOI":"10.1016/j.cirp.2013.05.003","Publisher":"Elsevier"},
    {"ID":"R004","Authors":"Fuerschbach, K. et al.","Title":"A new family of optical systems employing phi-polynomial surfaces",
     "Journal":"Optics Express","Year":2011,"Volume":19,"Issue":22,"Pages":"21919-21928",
     "DOI":"10.1364/OE.19.021919","Publisher":"Optica Publishing Group"},
    {"ID":"R005","Authors":"Rolland, J.P. et al.","Title":"Freeform optics for imaging",
     "Journal":"Optica","Year":2021,"Volume":8,"Issue":2,"Pages":"161-176",
     "DOI":"10.1364/OPTICA.413762","Publisher":"Optica Publishing Group"},
    {"ID":"R006","Authors":"Noll, R.J.","Title":"Zernike polynomials and atmospheric turbulence",
     "Journal":"Journal of the Optical Society of America","Year":1976,"Volume":66,"Issue":3,"Pages":"207-211",
     "DOI":"10.1364/JOSA.66.000207","Publisher":"Optica Publishing Group"},
    {"ID":"R007","Authors":"Sasian, J.","Title":"Introduction to Aberrations in Optical Imaging Systems",
     "Journal":"Cambridge University Press","Year":2013,"Volume":"","Issue":"","Pages":"",
     "DOI":"10.1017/CBO9781139025485","Publisher":"Cambridge University Press"},
    {"ID":"R008","Authors":"Papa, J.C. et al.","Title":"Efficient freeform optics design methodology with no assumed symmetry",
     "Journal":"Applied Optics","Year":2019,"Volume":58,"Issue":13,"Pages":"3671-3681",
     "DOI":"10.1364/AO.58.003671","Publisher":"Optica Publishing Group"},
    {"ID":"R009","Authors":"Bauer, A. et al.","Title":"Starting geometry creation and design method for freeform optics",
     "Journal":"Nature Communications","Year":2018,"Volume":9,"Issue":1,"Pages":"1756",
     "DOI":"10.1038/s41467-018-04186-9","Publisher":"Nature"},
    {"ID":"R010","Authors":"Zhong, Y. and Gross, H.","Title":"Initial system design method for non-rotationally symmetric systems",
     "Journal":"Applied Optics","Year":2017,"Volume":56,"Issue":24,"Pages":"6894-6901",
     "DOI":"10.1364/AO.56.006894","Publisher":"Optica Publishing Group"},
]


def main():
    print("=== BIBLIOGRAPHY VERIFICATION ===")
    out_csv = REF_DIR / "bibliography_verification.csv"
    df = verify_bibliography(REFERENCES, out_csv, delay=0.5)

    # Also write DOI verification CSV
    doi_csv = REF_DIR / "DOI_verification.csv"
    df[["ID","DOI","Retrieved_Title","Similarity","DOI_Verified","Note"]].to_csv(
        doi_csv, index=False)
    print(f"\n  DOI verification saved: {doi_csv}")
    print("=== DONE ===")


if __name__ == "__main__":
    main()
