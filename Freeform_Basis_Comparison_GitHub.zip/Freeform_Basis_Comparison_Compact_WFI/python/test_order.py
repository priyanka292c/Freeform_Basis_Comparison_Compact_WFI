import re
import json

with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    bib_data = json.load(f)

expected_keys = [it['key'] for it in bib_data]
print(f"Total verified keys: {len(expected_keys)}")
for i, k in enumerate(expected_keys, 1):
    print(f"[{i:02d}] {k}")
