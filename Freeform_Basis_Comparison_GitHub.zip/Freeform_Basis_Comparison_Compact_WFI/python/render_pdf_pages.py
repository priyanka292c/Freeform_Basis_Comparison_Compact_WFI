import fitz
import os

doc = fitz.open('manuscript/main.pdf')
out_dir = r"C:\Users\I7\.gemini\antigravity-ide\brain\c164dfa0-3104-4e46-874d-3ced51071590"

pages_to_render = [1, 9, 10]
for p in pages_to_render:
    page = doc[p-1]
    pix = page.get_pixmap(dpi=150)
    out_path = os.path.join(out_dir, f"main_page_{p:02d}.png")
    pix.save(out_path)
    print(f"Rendered Page {p} to {out_path}")
