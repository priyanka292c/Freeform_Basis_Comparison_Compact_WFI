import json

with open(r'C:\Users\I7\.gemini\antigravity-ide\brain\c164dfa0-3104-4e46-874d-3ced51071590\.system_generated\logs\transcript.jsonl', 'r', encoding='utf-8') as f:
    for i, line in enumerate(f):
        if i == 635:
            data = json.loads(line)
            content = data.get('content', '')
            import sys, io
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            lines = content.split('\n')
            for l in lines:
                if any(w in l.lower() for w in ['ai', 'declaration', 'statement', 'competing', 'interest', 'author', 'submission']):
                    print(l[:120])
