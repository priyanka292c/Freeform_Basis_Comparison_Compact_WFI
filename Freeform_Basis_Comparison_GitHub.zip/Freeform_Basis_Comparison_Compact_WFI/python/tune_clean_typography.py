import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Scale Fig 9 and Fig 10 on Page 9 slightly
tex = tex.replace(
    r'\includegraphics[width=0.62\columnwidth]{../figures/source/fig34_runtime.png}',
    r'\includegraphics[width=0.54\columnwidth]{../figures/source/fig34_runtime.png}'
)
tex = tex.replace(
    r'\includegraphics[width=0.62\columnwidth]{../figures/source/fig35_ranking.png}',
    r'\includegraphics[width=0.54\columnwidth]{../figures/source/fig35_ranking.png}'
)

# 2. Add \enlargethispage{4\baselineskip} before Discussion on Page 9
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Discussion\}',
             r'\\enlargethispage{4\\baselineskip}\n\\section{Discussion}',
             tex)

# 3. Use clean, non-overlapping font metrics for bibliography:
# \fontsize{4.6pt}{5.4pt} with \itemsep=0pt plus 0.1pt (NO negative itemsep so zero overlap!)
new_bib_header = r"""\begin{thebibliography}{80}
\fontsize{4.6pt}{5.3pt}\selectfont
\setlength{\itemsep}{0pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}"""

tex = re.sub(
    r'\\begin\{thebibliography\}\{80\}.*?(?=\\bibitem)',
    lambda m: new_bib_header + '\n',
    tex,
    flags=re.DOTALL
)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex with clean font and figure scaling. Compiling...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
