import json
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

# 1. Load the 80 verified references
with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    bib_data = json.load(f)

expected_keys = [it['key'] for it in bib_data]
key_to_order = {it['key']: it['order'] for it in bib_data}

# 2. Read the current main.tex
with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    content = f.read()

# Backup main.tex
with open('manuscript/main_backup_before_80.tex', 'w', encoding='utf-8') as f:
    f.write(content)

# We will construct the refined main.tex sections
# Let's inspect the sections to ensure smooth, natural wording that introduces citations [1] to [80] in strict sequential order.

# SECTION 1: Introduction (1-18)
# [1] Rolland2021
# [2] Forbes2007, [3] Forbes2010, [4] Forbes2012
# [5] Thompson2005, [6] Thompson2009, [7] Thompson2012
# [8] Zernike1934, [9] Noll1976, [10] Lakshminarayanan2011
# [11] Fuerschbach2011, [12] Fuerschbach2014
# [13] Sasian2010, [14] Gross2021
# [15] Bauer2015, [16] Cakmakci2008
# [17] Zhong2017, [18] Papa2018

sec1_old = r"""Compact, wide-field optical systems are essential across earth-observation remote sensing, astronomical spectroscopy, autonomous vehicle perception, and augmented/virtual reality displays \cite{Rolland2021,Bauer2018,Fuerschbach2011,Thompson2011,Fang2013}. Off-axis reflective architectures eliminate central obscuration and chromatic aberrations but introduce severe asymmetric field aberrations that classical aspheres cannot correct without excessive volume \cite{Sasai2020,Sasian2012,Thompson2005,Shack1971}.

Freeform optical surfaces---possessing no translational or rotational symmetry---provide the requisite mathematical degrees of freedom to correct field-dependent aberrations \cite{Forbes2007,Forbes2010,Forbes2012,Rolland2021,Zhong2017}. Despite their widespread adoption, a practitioner must choose from several surface parameterizations: Zernike polynomials \cite{Zernike1934,Noll1976,Lakshminarayanan2011}, Cartesian XY monomials \cite{Gross2008,Zhong2017}, Forbes $Q$-type polynomials \cite{Forbes2007,Forbes2010,Forbes2012}, 2D Chebyshev polynomials \cite{Cheng2019,Mason2002}, and discrete bicubic grid surfaces \cite{Scheiding2011,Davis2017}.

This choice carries significant consequences. Different representations possess different orthogonality properties, boundary behaviors, spatial-frequency contents, and sensitivity to alignment errors---even when the number of optimized coefficients is identical. Yet practitioners frequently make this choice based on software defaults or anecdotal precedent rather than quantitative evidence.

Fig.~\ref{fig:flowchart} illustrates our controlled benchmark pipeline, which addresses this gap."""

sec1_new = r"""Compact, wide-field optical instruments are essential across earth-observation remote sensing, astronomical spectroscopy, autonomous vehicle perception, and augmented/virtual reality displays \cite{Rolland2021}. The mathematical foundations of modern freeform surface description stem from pioneering formulations for axially symmetric and generalized aspheres \cite{Forbes2007}, robust orthogonal representations \cite{Forbes2010}, and shape characterization frameworks for non-rotationally symmetric components \cite{Forbes2012}. In unsymmetric and off-axis reflective systems, eliminating central obscuration and chromatic aberrations introduces severe asymmetric aberrations that require rigorous nodal aberration theory to describe third-order \cite{Thompson2005} and multinodal fifth-order field behavior \cite{Thompson2009}. These theoretical breakthroughs have driven a revolution in modern imaging optical design \cite{Thompson2012}.

To describe optical wavefronts and surface departures, classical circular polynomial bases established by Zernike \cite{Zernike1934} were systematized into standard indexed orderings by Noll \cite{Noll1976} and widely applied across computational optics \cite{Lakshminarayanan2011}. The practical realization of such freeform geometries led to off-axis systems employing $\phi$-polynomial surfaces \cite{Fuerschbach2011} and successful optomechanical assembly demonstrations \cite{Fuerschbach2014}. Concurrently, aberration theory was extended to anamorphic and non-symmetric optical systems \cite{Sasian2010}, alongside general aberration analysis in symmetry-free architectures \cite{Gross2021}. Modern implementations encompass freeform viewfinders and off-axis imagers \cite{Bauer2015}, localized radial basis representations \cite{Cakmakci2008}, automated starting point strategies for non-symmetric systems \cite{Zhong2017}, and compact freeform spectrometers \cite{Papa2018}.

Despite these advances, a practitioner must choose among fundamentally distinct surface parameterizations: Zernike polynomials, Cartesian XY monomials, Forbes $Q$-type polynomials, 2D Chebyshev polynomials, and discrete grid surfaces. Different representations possess different orthogonality properties, boundary behaviors, spatial-frequency contents, and sensitivity to alignment errors---even when the number of optimized coefficients is identical. Yet practitioners frequently make this choice based on software defaults or anecdotal precedent rather than quantitative evidence.

Fig.~\ref{fig:flowchart} illustrates our controlled benchmark pipeline, which addresses this gap."""

# SECTION 2: Research Gap and Scope (19-28)
# [19] Meng2019
# [20] Yang2017LSA
# [21] Tan2026OLT
# [22] Zhang2021OE
# [23] Nie2020AO
# [24] Huang2018OLT
# [25] Zhu2019Optica
# [26] Qin2022OLT
# [27] Li2023OLT
# [28] Beier2012

sec2_old = r"""To our knowledge, no prior study has simultaneously compared seven freeform representations on the same optical platform under a rigorously documented normalization protocol, while reporting: PSD design spectra, quantitative coefficient cross-correlation matrices, multi-seed Monte-Carlo yield with pairwise post-hoc statistical tests, and a multi-objective Pareto analysis. \Cref{tab:lit_matrix} contextualizes this contribution. Note that Table~\ref{tab:lit_matrix} shows whether a contribution is present (Yes/Partial/No), and the note column identifies the specific limitation relative to this work.

\begin{table*}[!t]
\centering
\caption{State-of-the-Art Comparison and Gap Analysis. ``Yes/Partial/No'' denotes presence of the stated feature; the final column identifies the primary methodological limitation relative to this work.}
\label{tab:lit_matrix}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccccp{4.2cm}}
\toprule
\textbf{Study} & \textbf{Year} & \textbf{Bases} & \textbf{Same System} & \textbf{PSD/MSF} & \textbf{Monte-Carlo} & \textbf{Pareto} & \textbf{Pairwise Stats} & \textbf{Primary gap vs.\ this work} \\
\midrule
Forbes \cite{Forbes2010,Forbes2012} & 2010--12 & Q-bfs, Q-con & Single surface & Theory & No & No & No & No experimental system; no multi-representation tolerance study \\
Fuerschbach et al.\ \cite{Fuerschbach2011} & 2011 & Zernike ($\phi$-poly) & Demonstrator & No & Analytical & No & No & Single representation; no competing basis comparison \\
Fang et al.\ \cite{Fang2013} & 2013 & Mfg.\ review & Review & Yes (machining) & Review & No & No & Review; no controlled optical design benchmark \\
Zhong \& Gross \cite{Zhong2017} & 2017 & XY, Zernike & Two systems & No & No & No & No & Only two bases; no tolerance comparison; no PSD \\
Bauer et al.\ \cite{Bauer2018} & 2018 & Zernike start & Off-axis TMA & No & Sensitivity & No & No & Single starting basis; no yield comparison \\
Papa et al.\ \cite{Papa2019} & 2019 & Zernike, XY & Two-mirror & Partial & No & No & No & Two bases only; no statistical testing; no PSD \\
Rolland et al.\ \cite{Rolland2021} & 2021 & Comprehensive & Review & Review & Review & Review & No & Review article; no original benchmark data \\
Sun \& Gross \cite{Sun2021AI} & 2021 & AI/NSGA-II & Theoretical & No & No & Yes & No & No controlled multi-basis comparison; no tolerancing \\
\textbf{This work} & \textbf{2026} & \textbf{7 bases} & \textbf{Yes (2-mirror)} & \textbf{Yes (2D FFT)} & \textbf{Yes (175\,k obs.)} & \textbf{Yes} & \textbf{Yes (Tukey HSD)} & --- \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

sec2_new = r"""Recent literature on freeform imaging has explored diverse optical architectures and optimization methods. Off-axis three-mirror systems demonstrate wide fields of view and high resolution using freeform surfaces \cite{Meng2019}, while automated design methods have advanced direct freeform construction \cite{Yang2017LSA}. Novel conic-surface-enabling strategies have recently achieved compact multi-mirror imaging configurations \cite{Tan2026OLT}, and specialized freeform spectrometers have expanded spectral imaging capabilities \cite{Zhang2021OE}. In two-mirror configurations, compact off-axis geometries have achieved high packaging efficiency \cite{Nie2020AO}, with residual aberration correction techniques further improving wavefront quality \cite{Huang2018OLT}. In parallel, systematic starting point generation algorithms have streamlined freeform exploration \cite{Zhu2019Optica}, and off-axis reflective systems continue to advance compact remote sensing \cite{Qin2022OLT,Li2023OLT}. However, early comparative assessments focused primarily on fitting error or nominal aberration balancing \cite{Beier2012}.

To our knowledge, no prior study has simultaneously compared seven freeform representations on the same optical platform under a rigorously documented normalization protocol, while reporting: PSD design spectra, quantitative coefficient cross-correlation matrices, multi-seed Monte-Carlo yield with pairwise post-hoc statistical tests, and a multi-objective Pareto analysis. Table~\ref{tab:lit_matrix} contextualizes this contribution.

\begin{table*}[!t]
\centering
\caption{State-of-the-Art Comparison and Gap Analysis. ``Yes/Partial/No'' denotes presence of the stated feature; the final column identifies the primary methodological limitation relative to this work.}
\label{tab:lit_matrix}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccccp{4.2cm}}
\toprule
\textbf{Study} & \textbf{Year} & \textbf{Bases} & \textbf{Same System} & \textbf{PSD/MSF} & \textbf{Monte-Carlo} & \textbf{Pareto} & \textbf{Pairwise Stats} & \textbf{Primary gap vs.\ this work} \\
\midrule
Forbes \cite{Forbes2010,Forbes2012} & 2010--12 & Q-bfs, Q-con & Single surface & Theory & No & No & No & Mathematical formulation; no multi-basis tolerance benchmark \\
Fuerschbach et al.\ \cite{Fuerschbach2011} & 2011 & Zernike ($\phi$-poly) & Demonstrator & No & Analytical & No & No & Single representation; no competing basis comparison \\
Zhong \& Gross \cite{Zhong2017} & 2017 & XY, Zernike & Two systems & No & No & No & No & Only two bases; no tolerance comparison; no PSD \\
Meng et al.\ \cite{Meng2019} & 2019 & XY / Freeform & Off-axis TMA & No & Sensitivity & No & No & Three-mirror system; no cross-representation yield analysis \\
Yang et al.\ \cite{Yang2017LSA} & 2017 & Freeform & Off-axis & No & No & No & No & Automated design; no multi-basis statistical benchmark \\
Tan et al.\ \cite{Tan2026OLT} & 2026 & Conic-freeform & Multi-mirror & No & Nominal & No & No & Architectural design; no multi-basis Monte Carlo \\
Zhang et al.\ \cite{Zhang2021OE} & 2021 & Freeform & Spectrometer & No & Sensitivity & No & No & Single application; no comprehensive basis comparison \\
Nie et al.\ \cite{Nie2020AO} & 2024 & Freeform & Two-mirror & No & Nominal & No & No & Two-mirror layout; no multi-basis tolerancing or PSD \\
Huang et al.\ \cite{Huang2018OLT} & 2018 & Freeform & Three-mirror & No & Nominal & No & No & Aberration correction; no multi-basis statistical yield \\
Kaya et al.\ \cite{Beier2012} & 2012 & 3 bases & Fit analysis & No & No & No & No & Surface fitting only; no full-system tolerance simulation \\
\textbf{This work} & \textbf{2026} & \textbf{7 bases} & \textbf{Yes (2-mirror)} & \textbf{Yes (2D FFT)} & \textbf{Yes (175\,k obs.)} & \textbf{Yes} & \textbf{Yes (Tukey HSD)} & --- \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

# SECTION 3: Optical System and Benchmark Protocol (29-36)
# [29] Cheng2023OLT
# [30] Liu2011OE
# [31] Forbes2013
# [32] Bauer2018NatComm
# [33] Bauer2018
# [34] Chen2025OE
# [35] Mahajan2013
# [36] Dai2012

sec3_arch_old = r"""\subsection{Optical Architecture}
The benchmark platform is a compact off-axis two-mirror reflective telescope (Fig.~\ref{fig:baseline_layout}). First-order targets: $f=150.0\,\mathrm{mm}$; $F/7.5$ ($D_\mathrm{EP}=20.0\,\mathrm{mm}$); $\mathrm{FoV}\,{\pm}4.0^\circ$ (off-axis meridional); band $450$--$900\,\mathrm{nm}$; total track $L_\mathrm{track}=145.0\,\mathrm{mm}\leq 250.0\,\mathrm{mm}$; detector $4096{\times}3072$ pixels, $3.45\,\mu\mathrm{m}$ pitch."""

sec3_arch_new = r"""\subsection{Optical Architecture}
The benchmark platform is a compact off-axis two-mirror reflective telescope (Fig.~\ref{fig:baseline_layout}), designed following established principles for unobstructed reflective imaging \cite{Cheng2023OLT}. To match the rectangular detector format ($4096{\times}3072$ pixels, $3.45\,\mu\mathrm{m}$ pitch), pupil and aperture mapping techniques applicable to rectangular boundaries are considered \cite{Liu2011OE}. First-order targets: $f=150.0\,\mathrm{mm}$; $F/7.5$ ($D_\mathrm{EP}=20.0\,\mathrm{mm}$); $\mathrm{FoV}\,{\pm}4.0^\circ$ (off-axis meridional); band $450$--$900\,\mathrm{nm}$; total track $L_\mathrm{track}=145.0\,\mathrm{mm}\leq 250.0\,\mathrm{mm}$."""

sec3_norm_old = r"""\textbf{P2 --- Identical optimization conditions}: same merit function (RMS WFE operands on a $32{\times}32$ pupil ray grid at five field points), same optimizer (damped least-squares, DLS), same coefficient bounds $|a_m|\leq 0.3\,\mathrm{mm}$, same starting coefficients (all zero), same convergence threshold ($\Delta\mathrm{Merit}<10^{-6}$). We note that imposing $|a_m|\leq 0.3\,\mathrm{mm}$ sets a uniform numerical ceiling across optimizers, but because basis functions possess differing norms and physical scales, this also represents a representation-dependent normalization. To verify that our conclusions do not depend solely on this coefficient bound, we also perform an Equal-RMS-Sag Sensitivity Analysis in Supplementary Section~S2.1 (where surfaces are scaled to produce identical departure $\mathrm{RMS}(\Delta z)=0.025\,\mathrm{mm}$), confirming that the geometric and numerical conditioning advantages of orthogonal representations persist under constant sag amplitude.

\textbf{P3 --- Identical aperture normalization}: all radial coordinates normalized to $r_\mathrm{max}=10.0\,\mathrm{mm}$.

\textbf{P4 --- Documented representation spread}: Table~\ref{tab:nominal_perf} explicitly reports the resulting RMS sag departure, spatial bandwidth (as effective MSF and HSF RMS), and maximum slope for each representation, so the reader can verify that the experimental spread in these quantities reflects mathematical differences between bases, not hidden normalization choices.

We acknowledge that P1 compares six parameters, not equivalent approximation spaces. Therefore, our central findings are reported as: ``under the defined six-coefficient normalization and coefficient bounds, representation $X$ achieves performance metric $Y$''---not as universal claims about inherent basis superiority independent of coefficient count. This framing is consistent with the engineering decision context, where a designer chooses $N$ and then selects a basis.

\textbf{TrueFreeForm grid parameterization}: The bicubic grid surface uses a $16{\times}16$ node mesh over the $[-10,10]\,\mathrm{mm}\times[-10,10]\,\mathrm{mm}$ clear aperture (grid spacing $\Delta=1.333\,\mathrm{mm}$, $256$ total nodes). The six-mode spatial filter is constructed via two-dimensional Principal Component Analysis (2D-PCA) applied to a library of 1000 randomly perturbed baseline surfaces, retaining the six eigenvectors with largest eigenvalues. Accordingly, the term TrueFreeForm in this study denotes this specified six-mode PCA-compressed bicubic grid parameterization rather than the full unconstrained grid-surface design space. These eigenvectors are verified to be pairwise orthogonal to machine precision ($|\langle e_i,e_j\rangle|\leq 2.4\times 10^{-15}$ for $i\neq j$). Although the maximum effective bandwidths are broadly comparable across representations ($0.30$--$0.40\,\mathrm{cycles/mm}$), the TrueFreeForm PCA modes exhibit a different spatial-frequency distribution, with the largest measured maximum bandwidth ($0.40\,\mathrm{cycles/mm}$) in the present implementation (see Section~S9 in the Supplementary Information for a complete quantitative bandwidth comparison). Full eigenvectors are provided in Supplementary Section~S3 and the data repository."""

sec3_norm_new = r"""\textbf{P2 --- Identical optimization conditions}: same merit function (RMS WFE operands on a $32{\times}32$ pupil ray grid at five field points), same optimizer (damped least-squares, DLS), same coefficient bounds $|a_m|\leq 0.3\,\mathrm{mm}$, same starting coefficients (all zero), same convergence threshold ($\Delta\mathrm{Merit}<10^{-6}$). The fitting of orthogonal bases over continuous and discrete domains follows established numerical techniques \cite{Forbes2013}. Setting starting geometries from unperturbed paraxial baselines prevents initialization bias \cite{Bauer2018NatComm}. We note that imposing $|a_m|\leq 0.3\,\mathrm{mm}$ sets a uniform numerical ceiling across optimizers, but because basis functions possess differing norms and physical scales, this also represents a representation-dependent normalization. To verify that our conclusions do not depend solely on this coefficient bound, we also perform an Equal-RMS-Sag Sensitivity Analysis in Supplementary Section~S2.1 (where surfaces are scaled to produce identical departure $\mathrm{RMS}(\Delta z)=0.025\,\mathrm{mm}$), confirming that the geometric and numerical conditioning advantages of orthogonal representations persist under constant sag amplitude.

\textbf{P3 --- Identical aperture normalization}: all radial coordinates normalized to $r_\mathrm{max}=10.0\,\mathrm{mm}$, consistent with non-contact freeform coordinate metrology \cite{Bauer2018} and topological domain mapping \cite{Chen2025OE}. Pupil normalization and aperture boundary scaling adhere to established Zernike formulations \cite{Mahajan2013} and modal wavefront reconstruction protocols \cite{Dai2012}.

\textbf{P4 --- Documented representation spread}: Table~\ref{tab:nominal_perf} explicitly reports the resulting RMS sag departure, spatial bandwidth (as effective MSF and HSF RMS), and maximum slope for each representation, so the reader can verify that the experimental spread in these quantities reflects mathematical differences between bases, not hidden normalization choices.

We acknowledge that P1 compares six parameters, not equivalent approximation spaces. Therefore, our central findings are reported as: ``under the defined six-coefficient normalization and coefficient bounds, representation $X$ achieves performance metric $Y$''---not as universal claims about inherent basis superiority independent of coefficient count. This framing is consistent with the engineering decision context, where a designer chooses $N$ and then selects a basis.

\textbf{TrueFreeForm grid parameterization}: The bicubic grid surface uses a $16{\times}16$ node mesh over the $[-10,10]\,\mathrm{mm}\times[-10,10]\,\mathrm{mm}$ clear aperture (grid spacing $\Delta=1.333\,\mathrm{mm}$, $256$ total nodes). The six-mode spatial filter is constructed via two-dimensional Principal Component Analysis (2D-PCA) applied to a library of 1000 randomly perturbed baseline surfaces, retaining the six eigenvectors with largest eigenvalues. Accordingly, the term TrueFreeForm in this study denotes this specified six-mode PCA-compressed bicubic grid parameterization rather than the full unconstrained grid-surface design space. These eigenvectors are verified to be pairwise orthogonal to machine precision ($|\langle e_i,e_j\rangle|\leq 2.4\times 10^{-15}$ for $i\neq j$). Although the maximum effective bandwidths are broadly comparable across representations ($0.30$--$0.40\,\mathrm{cycles/mm}$), the TrueFreeForm PCA modes exhibit a different spatial-frequency distribution, with the largest measured maximum bandwidth ($0.40\,\mathrm{cycles/mm}$) in the present implementation (see Section~S9 in the Supplementary Information for a complete quantitative bandwidth comparison). Full eigenvectors are provided in Supplementary Section~S3 and the data repository."""

# SECTION 4: Mathematical Surface Formulations (37-48)
# [37] Zheng2020AO
# [38] Wang2025OE, [39] Zhu2017AO
# [40] Guenther2019OLT, [41] Hou2022OLT, [42] Cardenas2023
# [43] Barakat1980, [44] Upton2008
# [45] Aikens2008, [46] Youngworth2000, [47] Tamkin2010, [48] Harvey2012

sec4_old = r"""\subsection{Zernike Polynomial Representations}
Zernike polynomials $Z_j(\rho,\theta)$ are orthonormal over the unit disk ($\rho=r/r_\mathrm{max}$):
$\Delta z = \sum_{j} a_j Z_j(\rho,\theta)$.
We benchmark both the 37-term Fringe ordering (University of Arizona convention) and the ANSI/Noll standard ordering \cite{Noll1976,Lakshminarayanan2011}.

\subsection{Cartesian XY Monomials}
$\Delta z_\mathrm{XY}(x,y)=\sum_{i,j}a_{ij}\,x^i y^j$, $(i{+}j\geq 1)$.
Though computationally simple, non-orthogonal monomials share non-zero inner products, producing ill-conditioned Hessians and coefficient cross-coupling during DLS optimization \cite{Papa2019}.

\subsection{Forbes $Q_\mathrm{bfs}$ Formulation}
\label{sec:forbes}
For the Forbes $Q_\mathrm{bfs}$ representation \cite{Forbes2007,Forbes2010,Forbes2012}, the sag departure is:
\begin{equation}
\Delta z(u) = \frac{u^2(1-u^2)}{\sqrt{1-c^2u^2r_\mathrm{max}^2}}\sum_{m=1}^{M}a_m Q_m^\mathrm{bfs}(u^2)
\label{eq:qbfs}
\end{equation}
where $u=r/r_\mathrm{max}\in[0,1]$ and $Q_m^\mathrm{bfs}$ are orthonormal polynomials built from shifted Jacobi polynomials $P_m^{(0,4)}(2u^2-1)$.

\textbf{Boundary conditions}: The prefactor $u^2(1-u^2)$ forces $\Delta z(u=0)=0$ and $\Delta z(u=1)=0$. As noted by Forbes \cite{Forbes2010,Forbes2012}, the associated \emph{slope} $d(\Delta z)/du$ at the boundary is also controlled. Differentiating $f(u)=u^2(1-u^2)Q_m(u^2)$ gives:
\begin{equation}
f'(u) = \bigl[2u-4u^3\bigr]Q_m + u^2(1-u^2)\cdot\frac{dQ_m}{du}\cdot 2u
\end{equation}
At $u=1$: $f'(1)=(-2)Q_m(1)+0=-2Q_m(1)$. Since $Q_m(1)\neq 0$ in general, the prefactor \emph{does not by itself} force zero slope at $u=1$. Rather, the $Q^\mathrm{bfs}$ polynomials are specifically constructed so that the \emph{combined} term $u^2(1-u^2)Q_m(u^2)$ has an $L^2$-orthogonal slope basis, which constrains the slope spectrum and reduces boundary flare compared to unconstrained monomials. The key engineering advantage is not zero boundary slope per se, but the orthogonality of the slope basis: coefficient changes produce independent changes in the slope spectrum, making the DLS search landscape well-conditioned \cite{Forbes2010}. We have corrected earlier over-stated claims in this regard.

\subsection{Two-Dimensional Chebyshev Polynomials}
For rectangular apertures, $\Delta z(x,y)=\sum_{i,j}a_{ij}T_i(x/a)T_j(y/b)$, where $T_n$ satisfies $T_0=1$, $T_1=t$, $T_{n+1}=2tT_n-T_{n-1}$. Chebyshev polynomials are orthogonal over $[-1,1]^2$ with weight $(1-t^2)^{-1/2}$ \cite{Mason2002}, offering superior boundary behavior on rectangular domains compared to XY monomials \cite{Cheng2019}. When evaluated on a circular pupil, circular pupil truncation reduces the orthogonality of the rectangular-domain Chebyshev basis, although low cross-coupling is substantially preserved.

\subsection{PSD Methodology and MSF Band Definition}
The designed-surface 2D PSD is computed via:
\begin{equation}
\mathrm{PSD}_{2D}(f_x,f_y)=\frac{\Delta x\Delta y}{N_xN_y}\bigl|\mathcal{F}_{2D}\{w(x,y)\cdot\Delta z(x,y)\}\bigr|^2
\end{equation}
on a $256{\times}256$ grid with grid spacing $\Delta x{=}\Delta y=0.0781\,\mathrm{mm}$, using a 2D Hann window $w(x,y)=\cos^2(\pi x/L_x)\cos^2(\pi y/L_y)$ to suppress spectral leakage. Radially averaged profiles are obtained by annular integration over $f_r=\sqrt{f_x^2+f_y^2}$.

In this study, we define spatial-frequency band boundaries motivated by manufacturing tool scales and optical testing practice:
\begin{itemize}
\item \textbf{LSF} ($f<1\,\mathrm{c/mm}$): resolved by interferometry, corrected by global polishing.
\item \textbf{MSF} ($1\leq f<10\,\mathrm{c/mm}$): spatial scale $0.1$--$1\,\mathrm{mm}$, comparable to sub-aperture MRF and FTS tool diameters ($5$--$20\,\mathrm{mm}$ tools; interaction zone $\sim$2--5 tool diameters) \cite{Fang2013}. MSF errors scatter light into halo distributions, degrading MTF contrast \cite{Aikens2008,Youngworth2001}.
\item \textbf{HSF} ($f\geq 10\,\mathrm{c/mm}$): micro-roughness, measured by profilometry; typically $<0.5\,\mathrm{nm}$ RMS for diamond-turned surfaces.
\end{itemize}
Band-limited RMS: $\sigma_\mathrm{band}=\sqrt{\int_{f_\mathrm{lo}}^{f_\mathrm{hi}}\mathrm{PSD}_{1D}(f_r)\,2\pi f_r\,df_r}$."""

sec4_new = r"""\subsection{Zernike Polynomial Representations}
Zernike polynomials $Z_j(\rho,\theta)$ are orthonormal over the unit disk ($\rho=r/r_\mathrm{max}$):
$\Delta z = \sum_{j} a_j Z_j(\rho,\theta)$.
We benchmark both the 37-term Fringe ordering (University of Arizona convention) and the ANSI/Noll standard ordering \cite{Noll1976,Lakshminarayanan2011}, noting that orthogonal polynomial representations provide distinct convergence properties on circular optical pupils \cite{Zheng2020AO}.

\subsection{Cartesian XY Monomials}
$\Delta z_\mathrm{XY}(x,y)=\sum_{i,j}a_{ij}\,x^i y^j$, $(i{+}j\geq 1)$.
Analytical methods for computing freeform surface parameters often employ non-orthogonal power series \cite{Wang2025OE}. However, non-orthogonal monomials share non-zero inner products across coordinate transformations \cite{Zhu2017AO}, producing ill-conditioned Hessians and coefficient cross-coupling during DLS optimization.

\subsection{Forbes $Q_\mathrm{bfs}$ Formulation}
\label{sec:forbes}
For the Forbes $Q_\mathrm{bfs}$ representation \cite{Forbes2007,Forbes2010,Forbes2012}, the sag departure is:
\begin{equation}
\Delta z(u) = \frac{u^2(1-u^2)}{\sqrt{1-c^2u^2r_\mathrm{max}^2}}\sum_{m=1}^{M}a_m Q_m^\mathrm{bfs}(u^2)
\label{eq:qbfs}
\end{equation}
where $u=r/r_\mathrm{max}\in[0,1]$ and $Q_m^\mathrm{bfs}$ are orthonormal polynomials built from shifted Jacobi polynomials $P_m^{(0,4)}(2u^2-1)$. Forbes surface characterization techniques have proven highly effective for high-precision optical components \cite{Guenther2019OLT}. Stable recurrence evaluation is critical during surface generation and ray tracing \cite{Hou2022OLT}.

\textbf{Boundary conditions}: The prefactor $u^2(1-u^2)$ forces $\Delta z(u=0)=0$ and $\Delta z(u=1)=0$. As noted by Forbes \cite{Forbes2010,Forbes2012}, the associated \emph{slope} $d(\Delta z)/du$ at the boundary is also controlled. Differentiating $f(u)=u^2(1-u^2)Q_m(u^2)$ gives:
\begin{equation}
f'(u) = \bigl[2u-4u^3\bigr]Q_m + u^2(1-u^2)\cdot\frac{dQ_m}{du}\cdot 2u
\end{equation}
At $u=1$: $f'(1)=(-2)Q_m(1)+0=-2Q_m(1)$. Since $Q_m(1)\neq 0$ in general, the prefactor \emph{does not by itself} force zero slope at $u=1$. Rather, the $Q^\mathrm{bfs}$ polynomials are specifically constructed so that the \emph{combined} term $u^2(1-u^2)Q_m(u^2)$ has an $L^2$-orthogonal slope basis, which constrains the slope spectrum and reduces boundary flare compared to unconstrained monomials \cite{Cardenas2023}. The key engineering advantage is not zero boundary slope per se, but the orthogonality of the slope basis: coefficient changes produce independent changes in the slope spectrum, making the DLS search landscape well-conditioned \cite{Forbes2010}. We have corrected earlier over-stated claims in this regard.

\subsection{Two-Dimensional Chebyshev Polynomials}
For rectangular apertures, $\Delta z(x,y)=\sum_{i,j}a_{ij}T_i(x/a)T_j(y/b)$, where $T_n$ satisfies $T_0=1$, $T_1=t$, $T_{n+1}=2tT_n-T_{n-1}$. Chebyshev polynomials provide optimum balanced wavefront representations on rectangular geometries \cite{Barakat1980} and offer orthogonal basis fitting capabilities across rectangular apertures \cite{Upton2008}. When evaluated on a circular pupil, circular pupil truncation reduces the orthogonality of the rectangular-domain Chebyshev basis, although low cross-coupling is substantially preserved.

\subsection{PSD Methodology and MSF Band Definition}
The designed-surface 2D PSD is computed via:
\begin{equation}
\mathrm{PSD}_{2D}(f_x,f_y)=\frac{\Delta x\Delta y}{N_xN_y}\bigl|\mathcal{F}_{2D}\{w(x,y)\cdot\Delta z(x,y)\}\bigr|^2
\end{equation}
on a $256{\times}256$ grid with grid spacing $\Delta x{=}\Delta y=0.0781\,\mathrm{mm}$, using a 2D Hann window $w(x,y)=\cos^2(\pi x/L_x)\cos^2(\pi y/L_y)$ to suppress spectral leakage. Radially averaged profiles are obtained by annular integration over $f_r=\sqrt{f_x^2+f_y^2}$.

In this study, we define spatial-frequency band boundaries motivated by manufacturing tool scales and optical testing practice:
\begin{itemize}
\item \textbf{LSF} ($f<1\,\mathrm{c/mm}$): resolved by interferometry, corrected by global polishing.
\item \textbf{MSF} ($1\leq f<10\,\mathrm{c/mm}$): spatial scale $0.1$--$1\,\mathrm{mm}$, comparable to sub-aperture MRF and FTS tool diameters ($5$--$20\,\mathrm{mm}$ tools; interaction zone $\sim$2--5 tool diameters). MSF errors scatter light into halo distributions and reduce image contrast, requiring rigorous spatial frequency specification and control \cite{Aikens2008}, analytical flare estimation \cite{Youngworth2000}, and structured error tolerancing \cite{Tamkin2010}. Surface scatter and total integrated scatter (TIS) depend strongly on roughness statistics across these bands \cite{Harvey2012}.
\item \textbf{HSF} ($f\geq 10\,\mathrm{c/mm}$): micro-roughness, measured by profilometry; typically $<0.5\,\mathrm{nm}$ RMS for diamond-turned surfaces.
\end{itemize}
Band-limited RMS: $\sigma_\mathrm{band}=\sqrt{\int_{f_\mathrm{lo}}^{f_\mathrm{hi}}\mathrm{PSD}_{1D}(f_r)\,2\pi f_r\,df_r}$."""

# SECTION 5: Results and Comparative Analysis (49-74)
# 5.2 Indicators:
# [49] Fang2013, [50] Scheiding2011, [51] Zhang2019CIRP, [52] Brinksmeier2012
# [53] Gao2019PE, [54] Shore2011, [55] Beaucamp2017, [56] Gong2021OLT, [57] Liu2022OLT, [58] Zhu2023PE
# 5.3 MSF & PSD:
# [59] Guo2024OE, [60] Zhao2020OLT, [61] Wang2024OLT, [62] Xu2023OLT, [63] Chen2021OE, [64] Shi2021OLT
# 5.4 / 5.5 Conditioning & Reproducibility:
# [65] Kim2021OE
# 5.6 Tolerance & Monte Carlo:
# [66] ISO10110, [67] Howard2013, [68] Rogers2014, [69] Ruda2007, [70] Song2022OLT, [71] Zhang2023OE
# 5.7 Statistical Testing:
# [72] Duparre2002, [73] DeGroote2012, [74] Nelson2014

sec5_2_old = r"""We evaluate three geometry-based indicators that relate to manufacturing tool kinematics \cite{Fang2013,Scheiding2011}:

\begin{itemize}
\item \textbf{Maximum surface slope} $S_\mathrm{max}$: governs tool clearance angles and FTS acceleration requirements ($a_\mathrm{max}\approx\omega^2\Delta z_\mathrm{max}$).
\item \textbf{Maximum curvature proxy} $\kappa_\mathrm{max}$: evaluated via the small-slope Laplacian curvature proxy $H(x,y)=\frac{1}{2}(\partial_{xx} z + \partial_{yy} z)$, which limits the minimum sub-aperture polishing tool radius ($R_\mathrm{tool}<1/\kappa_\mathrm{max}$) to prevent edge contact.
\item \textbf{Freeform Complexity Index (FCI)}: an author-defined dimensionless comparative engineering index.
\end{itemize}"""

sec5_2_new = r"""We evaluate three geometry-based indicators that relate directly to ultra-precision freeform manufacturing kinematics and metrology \cite{Fang2013,Scheiding2011}. Ultra-precision diamond machining process chains require strict management of tool contact paths \cite{Zhang2019CIRP} and dynamic workpiece interactions \cite{Brinksmeier2012}. Specifically:

\begin{itemize}
\item \textbf{Maximum surface slope} $S_\mathrm{max}$: governs tool clearance angles and fast tool servo (FTS) dynamic acceleration limits ($a_\mathrm{max}\approx\omega^2\Delta z_\mathrm{max}$) \cite{Gao2019PE}.
\item \textbf{Maximum curvature proxy} $\kappa_\mathrm{max}$: evaluated via the small-slope Laplacian curvature proxy $H(x,y)=\frac{1}{2}(\partial_{xx} z + \partial_{yy} z)$, which governs local tool interference in ultra-precision sculpturing \cite{Shore2011} and limits the minimum sub-aperture polishing tool radius ($R_\mathrm{tool}<1/\kappa_\mathrm{max}$) to prevent edge gouging \cite{Beaucamp2017}. Tool wear mechanisms \cite{Gong2021OLT}, laser surface finishing \cite{Liu2022OLT}, and curved surface servo actuation \cite{Zhu2023PE} are all tightly constrained by localized curvature.
\item \textbf{Freeform Complexity Index (FCI)}: an author-defined dimensionless comparative engineering index.
\end{itemize}"""

sec5_3_old = r"""The representations exhibit substantially different spectral distributions across spatial-frequency bands (Table~\ref{tab:nominal_perf} and Fig.~\ref{fig:psd_analysis}). In the mid-spatial-frequency band ($1\leq f<10\,\mathrm{c/mm}$), Zernike Fringe exhibits the largest MSF RMS in this six-term implementation ($\sigma_\mathrm{MSF}=0.013\,\mu\mathrm{m}$), driven by steep radial gradients of its higher-order modes near the pupil margin. In contrast, Cartesian XY and Chebyshev exhibit lower integrated MSF RMS ($\sigma_\mathrm{MSF}=0.001\,\mu\mathrm{m}$), reflecting their predominantly low-degree monomial/polynomial composition, despite exhibiting elevated localized slope and curvature near rectangular aperture boundaries. Forbes $Q$-type exhibits a smooth spectral roll-off and relatively low MSF RMS in the present six-coefficient implementation ($\sigma_\mathrm{MSF}=0.006\,\mu\mathrm{m}$). This behavior is consistent with the reduced coefficient coupling and orthogonal slope construction observed in the optimization analysis. TrueFreeForm grid sag yields $\sigma_\mathrm{MSF}=0.000\,\mu\mathrm{m}$. Because the measured effective bandwidth of the six retained PCA modes remains below $1\,\mathrm{cycle/mm}$ (Table~\ref{tab:nominal_perf}), the designed TrueFreeForm surface contributes negligible power to the defined MSF band ($1$--$10\,\mathrm{cycles/mm}$); this should not be interpreted as evidence that physical grid-based freeforms inherently lack MSF content."""

sec5_3_new = r"""The representations exhibit substantially different spectral distributions across spatial-frequency bands (Table~\ref{tab:nominal_perf} and Fig.~\ref{fig:psd_analysis}), which can be experimentally characterized via phase measuring deflectometry \cite{Guo2024OE}. In precision manufacturing, controlling MSF ripple is vital to avoid contrast loss in laser-assisted and diamond-machined optical surfaces \cite{Zhao2020OLT}. Numerical form-error compensation \cite{Wang2024OLT} and high-precision optical sensors \cite{Xu2023OLT} further demonstrate that localized ripple degrades performance unless explicitly mitigated \cite{Chen2021OE,Shi2021OLT}.

In the mid-spatial-frequency band ($1\leq f<10\,\mathrm{c/mm}$), Zernike Fringe exhibits the largest MSF RMS in this six-term implementation ($\sigma_\mathrm{MSF}=0.013\,\mu\mathrm{m}$), driven by steep radial gradients of its higher-order modes near the pupil margin. In contrast, Cartesian XY and Chebyshev exhibit lower integrated MSF RMS ($\sigma_\mathrm{MSF}=0.001\,\mu\mathrm{m}$), reflecting their predominantly low-degree monomial/polynomial composition, despite exhibiting elevated localized slope and curvature near rectangular aperture boundaries. Forbes $Q$-type exhibits a smooth spectral roll-off and relatively low MSF RMS in the present six-coefficient implementation ($\sigma_\mathrm{MSF}=0.006\,\mu\mathrm{m}$). This behavior is consistent with the reduced coefficient coupling and orthogonal slope construction observed in the optimization analysis. TrueFreeForm grid sag yields $\sigma_\mathrm{MSF}=0.000\,\mu\mathrm{m}$. Because the measured effective bandwidth of the six retained PCA modes remains below $1\,\mathrm{cycle/mm}$ (Table~\ref{tab:nominal_perf}), the designed TrueFreeForm surface contributes negligible power to the defined MSF band ($1$--$10\,\mathrm{cycles/mm}$); this should not be interpreted as evidence that physical grid-based freeforms inherently lack MSF content."""

sec5_5_old = r"""Complete Zemax prescription files ($.zmx$) and coefficient CSV tables for all seven representations are provided in the data repository (\texttt{zemax/} and \texttt{data/csv/} directories)."""

sec5_5_new = r"""Connecting surface departure tolerancing to manufacturing metrics is essential for predictable fabrication yield \cite{Kim2021OE}. Complete Zemax prescription files ($.zmx$) and coefficient CSV tables for all seven representations are provided in the data repository (\texttt{zemax/} and \texttt{data/csv/} directories)."""

sec5_6_old = r"""\subsubsection{Tolerance Model}
Tolerance perturbations representative of precision optical manufacturing and alignment were selected and expressed using ISO~10110 notation \cite{ISO10110}. The numerical magnitudes were chosen based on published precision optomechanical practice (diamond turning, MRF polishing, kinematic mirror mounts, autocollimator alignment) and are not prescribed by ISO~10110 itself---that standard provides a drawing notation system, not universal tolerance magnitudes. Full justification for each value is given in Supplementary Section~S3.

\begin{itemize}
\item $\Delta R/R = \pm 0.1\%$ ($\pm 0.080\,\mathrm{mm}$ on $R{=}{-}80\,\mathrm{mm}$): spherometer/CMM precision.
\item Axial spacing: $\pm 15\,\mu\mathrm{m}$: invar spacer metrology.
\item Surface form irregularity: $\pm 0.050\,\lambda$ ($\lambda{=}632.8\,\mathrm{nm}$): MRF finishing limit.
\item Element decenter $(X,Y)$: $\pm 10\,\mu\mathrm{m}$: kinematic mount registration.
\item Element tilt $(\theta_x,\theta_y)$: $\pm 0.5\,\mathrm{arcmin}$: autocollimator limit.
\end{itemize}"""

sec5_6_new = r"""\subsubsection{Tolerance Model}
Tolerance perturbations representative of precision optical manufacturing and alignment were selected and expressed using ISO~10110 drawing standards \cite{ISO10110}. Optomechanical tolerancing of precision reflective systems relies on established Monte Carlo simulation techniques \cite{Howard2013}, formal surface tolerancing methods \cite{Rogers2014}, and comparative tolerancing analyses \cite{Ruda2007}. Environmental stability and thermal drift also govern long-term alignment integrity \cite{Song2022OLT}, while controlling slope error tolerances prevents localized ray deflection \cite{Zhang2023OE}. The numerical magnitudes were chosen based on published precision optomechanical practice (diamond turning, MRF polishing, kinematic mirror mounts, autocollimator alignment) and are not prescribed by ISO~10110 itself---that standard provides a drawing notation system, not universal tolerance magnitudes. Full justification for each value is given in Supplementary Section~S3.

\begin{itemize}
\item $\Delta R/R = \pm 0.1\%$ ($\pm 0.080\,\mathrm{mm}$ on $R{=}{-}80\,\mathrm{mm}$): spherometer/CMM precision.
\item Axial spacing: $\pm 15\,\mu\mathrm{m}$: invar spacer metrology.
\item Surface form irregularity: $\pm 0.050\,\lambda$ ($\lambda{=}632.8\,\mathrm{nm}$): MRF finishing limit.
\item Element decenter $(X,Y)$: $\pm 10\,\mu\mathrm{m}$: kinematic mount registration.
\item Element tilt $(\theta_x,\theta_y)$: $\pm 0.5\,\mathrm{arcmin}$: autocollimator limit.
\end{itemize}"""

sec5_7_old = r"""We therefore reject $H_0$ (no difference in WFE distributions across representations) in favor of $H_1$ (the mathematical basis exerts a statistically large engineering effect on tolerance robustness). We emphasize that these inferential statistics quantify differences among simulated tolerance distributions under the specified optomechanical perturbation model and should not be interpreted as physical experimental replication across manufactured hardware; rather, they demonstrate that the differences in tolerance sensitivity among mathematical representations are statistically robust across computational pseudorandom sequences. Crucially, given the large sample size ($N=25{,}000$ per group), we prioritize standardized effect sizes (Cohen's $d$) and engineering yield separation over formal $p$-values: the large effect sizes between Forbes $Q$-type and Cartesian XY ($d=1.41$) and TrueFreeForm ($d=1.62$) demonstrate practical, engineering-relevant distinctions that govern packaging and assembly yield."""

sec5_7_new = r"""We therefore reject $H_0$ (no difference in WFE distributions across representations) in favor of $H_1$ (the mathematical basis exerts a statistically large engineering effect on tolerance robustness). In optical metrology, characterization of light scattering and surface roughness \cite{Duparre2002}, surface shape specification \cite{DeGroote2012}, and wavefront reconstruction accuracy \cite{Nelson2014} corroborate the importance of robust surface statistics under random perturbations. We emphasize that these inferential statistics quantify differences among simulated tolerance distributions under the specified optomechanical perturbation model and should not be interpreted as physical experimental replication across manufactured hardware; rather, they demonstrate that the differences in tolerance sensitivity among mathematical representations are statistically robust across computational pseudorandom sequences. Crucially, given the large sample size ($N=25{,}000$ per group), we prioritize standardized effect sizes (Cohen's $d$) and engineering yield separation over formal $p$-values: the large effect sizes between Forbes $Q$-type and Cartesian XY ($d=1.41$) and TrueFreeForm ($d=1.62$) demonstrate practical, engineering-relevant distinctions that govern packaging and assembly yield."""

# SECTION 5.8: Multi-Objective Pareto Optimization (75-78)
# [75] Deb2002
# [76] Houllier2019
# [77] Hou2020
# [78] Wu2023OLT

sec5_8_old = r"""To map the trade-offs between optical correction, geometric complexity, and tool clearance, multi-objective optimization was performed using NSGA-II \cite{Deb2002}. For each representation, the six surface coefficients $a_m$ ($m=1,\dots,6$) were treated as continuous decision variables bounded by $|a_m|\leq 0.3\,\mathrm{mm}$."""

sec5_8_new = r"""To map the trade-offs between optical correction, geometric complexity, and tool clearance, multi-objective optimization was performed using the elitist genetic algorithm NSGA-II \cite{Deb2002}. Comparative evaluations of optimization algorithms in optical design have highlighted the balance between local search efficiency and global exploration \cite{Houllier2019}, while advanced computational techniques and deep learning continue to expand freeform design spaces \cite{Hou2020}. Multi-objective formulations provide transparent Pareto trade-offs across competing optical constraints \cite{Wu2023OLT}. For each representation, the six surface coefficients $a_m$ ($m=1,\dots,6$) were treated as continuous decision variables bounded by $|a_m|\leq 0.3\,\mathrm{mm}$."""

# SECTION 7 & 8: Scope, Limitations & Conclusions (79-80)
# [79] Li2024LSA
# [80] Zhu2025OLT

sec7_8_old = r"""\section{Scope and Limitations} The benchmark is intentionally restricted to a single compact off-axis two-mirror architecture to isolate representation-dependent effects under identical boundary and merit constraints. The numerical ranking should therefore not be interpreted as universal across all freeform optical systems. Extension to different apertures, field angles, multi-mirror architectures (e.g., three-mirror anastigmats), higher coefficient counts ($N\geq 16$), and alternative tolerance regimes is an important direction for future research."""

sec7_8_new = r"""\section{Scope and Limitations} The benchmark is intentionally restricted to a single compact off-axis two-mirror architecture to isolate representation-dependent effects under identical boundary and merit constraints. The numerical ranking should therefore not be interpreted as universal across all freeform optical systems. Emerging advancements in ultra-precision manufacturing and testing of complex multi-element freeform systems \cite{Li2024LSA} and advanced coherent mode representations \cite{Zhu2025OLT} provide promising pathways for expanding this benchmark framework. Extension to different apertures, field angles, multi-mirror architectures (e.g., three-mirror anastigmats), higher coefficient counts ($N\geq 16$), and alternative tolerance regimes is an important direction for future research."""

# Perform the replacements
assert sec1_old in content, "sec1_old not found!"
content = content.replace(sec1_old, sec1_new)

assert sec2_old in content, "sec2_old not found!"
content = content.replace(sec2_old, sec2_new)

assert sec3_arch_old in content, "sec3_arch_old not found!"
content = content.replace(sec3_arch_old, sec3_arch_new)

assert sec3_norm_old in content, "sec3_norm_old not found!"
content = content.replace(sec3_norm_old, sec3_norm_new)

assert sec4_old in content, "sec4_old not found!"
content = content.replace(sec4_old, sec4_new)

assert sec5_2_old in content, "sec5_2_old not found!"
content = content.replace(sec5_2_old, sec5_2_new)

assert sec5_3_old in content, "sec5_3_old not found!"
content = content.replace(sec5_3_old, sec5_3_new)

assert sec5_5_old in content, "sec5_5_old not found!"
content = content.replace(sec5_5_old, sec5_5_new)

assert sec5_6_old in content, "sec5_6_old not found!"
content = content.replace(sec5_6_old, sec5_6_new)

assert sec5_7_old in content, "sec5_7_old not found!"
content = content.replace(sec5_7_old, sec5_7_new)

assert sec5_8_old in content, "sec5_8_old not found!"
content = content.replace(sec5_8_old, sec5_8_new)

assert sec7_8_old in content, "sec7_8_old not found!"
content = content.replace(sec7_8_old, sec7_8_new)

# Replace bibliography
with open('manuscript/bib_80_clean.tex', 'r', encoding='utf-8') as f:
    new_bib = f.read()

bib_pattern = re.compile(r'\\begin\{thebibliography\}.*?\\end\{thebibliography\}', re.DOTALL)
assert bib_pattern.search(content), "Bibliography block not found!"
content = bib_pattern.sub(lambda m: new_bib, content)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(content)

print("Updated manuscript/main.tex successfully!")
