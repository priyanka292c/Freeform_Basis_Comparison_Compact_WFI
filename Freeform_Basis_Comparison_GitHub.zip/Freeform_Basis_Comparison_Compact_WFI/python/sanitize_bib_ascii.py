import json
import re

with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

replacements = {
    'φ': r'$\phi$',
    'Φ': r'$\Phi$',
    'μ': r'$\mu$',
    'λ': r'$\lambda$',
    'é': r"\'e",
    'è': r"\`e",
    'á': r"\'a",
    'à': r"\`a",
    'í': r"\'i",
    'ó': r"\'o",
    'ú': r"\'u",
    'ñ': r"\~n",
    'ü': r'\"u',
    'ö': r'\"o',
    'ä': r'\"a',
    'Ü': r'\"U',
    'Ö': r'\"O',
    'Ä': r'\"A',
    '’': "'",
    '‘': "'",
    '“': "``",
    '”': "''",
    '—': "---",
    '–': "--",
    '\ufffd': r"{\ss}"
}

for it in data:
    for field in ['title', 'authors', 'journal']:
        val = it.get(field, '')
        for k, v in replacements.items():
            val = val.replace(k, v)
        # Any remaining non-ascii?
        rem = [c for c in val if ord(c) > 127]
        if rem:
            print(f"Warning: {it['key']}.{field} still has {set(rem)}: {val}")
        it[field] = val

with open('python/verified_80_final.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

# Re-generate bib_80_clean.tex
bib_lines = []
bib_lines.append(r"\begin{thebibliography}{80}")
bib_lines.append(r"\scriptsize")
bib_lines.append(r"\setlength{\itemsep}{0pt plus 0.2pt}")
bib_lines.append(r"\setlength{\parskip}{0pt}")
bib_lines.append("")

for it in data:
    vol_str = f"vol.~{it['volume']}, " if it['volume'] else ""
    page_str = f"pp.~{it['page']}, " if it['page'] else ""
    year_str = f"{it['year']}." if it['year'] else ""
    
    entry = (
        f"\\bibitem{{{it['key']}}}\n"
        f"{it['authors']}, ``{it['title']},'' \\textit{{{it['journal']}}}, "
        f"{vol_str}{page_str}{year_str} \\doi{{{it['doi']}}}\n"
    )
    bib_lines.append(entry)

bib_lines.append(r"\end{thebibliography}")

with open('manuscript/bib_80_clean.tex', 'w', encoding='utf-8') as f:
    f.write("\n".join(bib_lines))

print("Sanitized non-ascii characters and wrote bib_80_clean.tex!")
