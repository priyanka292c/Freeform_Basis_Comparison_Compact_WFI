import json
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('python/verified_80_clean.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Total: {len(data)}")
for i, d in enumerate(data, 1):
    k = d['key']
    y = d.get('year', '')
    authors = d.get('authors', '')
    if isinstance(authors, list):
        a = ", ".join(authors)[:30]
    else:
        a = str(authors)[:30]
    j = d.get('journal', '')[:25]
    t = d.get('title', '')[:45]
    doi = d.get('doi', '')
    print(f"{i:02d}: {k:18s} | {y} | {a:30s} | {j:25s} | {doi}")
