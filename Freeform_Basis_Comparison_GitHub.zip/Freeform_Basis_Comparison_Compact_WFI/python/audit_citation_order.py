import re
import json
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('python/verified_80_final.json', 'r', encoding='utf-8') as f:
    bib_data = json.load(f)

expected_keys = [it['key'] for it in bib_data]
key_to_order = {it['key']: it['order'] for it in bib_data}

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove comments
content_no_comments = re.sub(r'%.*', '', content)

# Find all cites
cites = re.findall(r'\\cite\{([^}]+)\}', content_no_comments)

seen_keys = []
first_appearance = {}

for idx, cite in enumerate(cites, 1):
    keys = [k.strip() for k in cite.split(',')]
    if len(keys) > 4:
        print(f"WARNING: Large cluster ({len(keys)} items): {cite}")
    for k in keys:
        if k not in first_appearance:
            first_appearance[k] = len(seen_keys) + 1
            seen_keys.append(k)

print(f"Total unique keys cited in text: {len(seen_keys)}")
print(f"Total expected keys in bibliography: {len(expected_keys)}")

missing_keys = set(expected_keys) - set(seen_keys)
if missing_keys:
    print(f"MISSING KEYS ({len(missing_keys)}): {missing_keys}")

extra_keys = set(seen_keys) - set(expected_keys)
if extra_keys:
    print(f"EXTRA KEYS ({len(extra_keys)}): {extra_keys}")

order_mismatches = []
for i, (k_seen, k_exp) in enumerate(zip(seen_keys, expected_keys), 1):
    if k_seen != k_exp:
        order_mismatches.append((i, k_seen, k_exp))

if order_mismatches:
    print(f"ORDER MISMATCHES ({len(order_mismatches)}):")
    for idx, seen, exp in order_mismatches[:15]:
        print(f"  Pos {idx:02d}: Seen '{seen}' vs Expected '{exp}'")
else:
    print("PERFECT MATCH! All keys appear in strict monotonic sequential order 1 to 80!")
