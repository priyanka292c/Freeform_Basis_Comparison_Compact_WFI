"""
verify_references.py
Cross-verify all 80 references in main.tex using CrossRef API.
Outputs a JSON report and a human-readable markdown summary.
"""

import re
import json
import time
import urllib.request
import urllib.parse
import urllib.error
import sys
import io

# Force UTF-8 output on Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# ── 1. Parse all bibitems from main.tex ────────────────────────────────────────
TEX_PATH = "manuscript/main.tex"

with open(TEX_PATH, "r", encoding="utf-8") as f:
    tex = f.read()

# Extract bibliography block
bib_block_m = re.search(r"\\begin\{thebibliography\}(.*?)\\end\{thebibliography\}", tex, re.DOTALL)
assert bib_block_m, "No thebibliography found"
bib_block = bib_block_m.group(1)

# Split into individual items
bibitem_pattern = re.compile(r"\\bibitem\{([^}]+)\}(.*?)(?=\\bibitem|\Z)", re.DOTALL)
raw_items = bibitem_pattern.findall(bib_block)

refs = []
for key, body in raw_items:
    body = body.strip()
    if not body:
        continue

    # Extract DOI
    doi_m = re.search(r"\\doi\{([^}]+)\}", body)
    doi = doi_m.group(1).strip() if doi_m else None

    # Extract title (between ``,'' or between ``...,'')
    title_m = re.search(r"``([^']+)''", body)
    title = title_m.group(1).strip() if title_m else ""

    # Extract journal/venue
    journal_m = re.search(r"\\textit\{([^}]+)\}", body)
    journal = journal_m.group(1).strip() if journal_m else ""

    # Extract year
    year_m = re.search(r"\((\d{4})\)", body)
    year = int(year_m.group(1)) if year_m else None

    # First author
    author_m = re.match(r"^([A-Z\.\s,a-z]+?),\s", body)
    first_author = author_m.group(1).strip() if author_m else body[:30]

    refs.append({
        "num": len(refs) + 1,
        "key": key,
        "doi": doi,
        "title_tex": title,
        "journal_tex": journal,
        "year_tex": year,
        "first_author_tex": first_author,
        "body": body[:300],
    })

print(f"Parsed {len(refs)} references")

# ── 2. Verify each DOI via CrossRef ───────────────────────────────────────────
CROSSREF_BASE = "https://api.crossref.org/works/"
HEADERS = {"User-Agent": "RefVerifier/1.0 (mailto:priyanka292c@gmail.com)"}

results = []

for ref in refs:
    result = dict(ref)
    doi = ref["doi"]
    num = ref["num"]

    if not doi:
        result["status"] = "NO_DOI"
        result["cr_title"] = ""
        result["cr_journal"] = ""
        result["cr_year"] = None
        result["cr_authors"] = []
        result["issues"] = ["Missing DOI"]
        results.append(result)
        print(f"[{num:02d}] {ref['key']}: NO DOI")
        continue

    url = CROSSREF_BASE + urllib.parse.quote(doi, safe="")
    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
        
        work = data.get("message", {})
        cr_title_list = work.get("title", [])
        cr_title = cr_title_list[0] if cr_title_list else ""
        
        # Journal name
        cr_journal = ""
        for field in ["container-title", "publisher"]:
            vals = work.get(field, [])
            if vals:
                cr_journal = vals[0]
                break
        
        # Year
        cr_year = None
        for date_field in ["published-print", "published-online", "issued"]:
            dp = work.get(date_field, {}).get("date-parts", [[]])
            if dp and dp[0]:
                cr_year = dp[0][0]
                break
        
        # Authors
        cr_authors = []
        for auth in work.get("author", [])[:3]:
            name = auth.get("family", "") + (", " + auth.get("given", "") if auth.get("given") else "")
            cr_authors.append(name)
        
        # ── Check for issues ────────────────────────────────────────────────
        issues = []
        
        # Title match (case-insensitive, partial)
        tex_title_clean = re.sub(r"[${}\\]", "", ref["title_tex"]).lower().strip()
        cr_title_clean = cr_title.lower().strip()
        
        # Compute simple word overlap
        tex_words = set(tex_title_clean.split())
        cr_words = set(cr_title_clean.split())
        common = tex_words & cr_words
        stopwords = {"the","a","an","of","in","on","for","and","with","by","to","is","at","as","from"}
        meaningful_common = common - stopwords
        meaningful_tex = tex_words - stopwords
        
        overlap = len(meaningful_common) / max(len(meaningful_tex), 1)
        
        if overlap < 0.3 and len(tex_title_clean) > 10:
            issues.append(f"TITLE_MISMATCH (overlap={overlap:.0%})")
        
        # Year check
        if cr_year and ref["year_tex"] and abs(cr_year - ref["year_tex"]) > 1:
            issues.append(f"YEAR_MISMATCH (tex={ref['year_tex']}, cr={cr_year})")
        
        # arXiv check
        if "arxiv" in doi.lower():
            issues.append("ARXIV_DOI")
        
        status = "FAIL" if issues else "OK"
        result["status"] = status
        result["cr_title"] = cr_title
        result["cr_journal"] = cr_journal
        result["cr_year"] = cr_year
        result["cr_authors"] = cr_authors
        result["issues"] = issues
        result["title_overlap"] = round(overlap, 2)
        
        flag = "✅" if status == "OK" else "❌"
        issue_str = " | ".join(issues) if issues else ""
        print(f"[{num:02d}] {flag} {ref['key']}: {issue_str or 'OK'}")
        
    except urllib.error.HTTPError as e:
        result["status"] = "DOI_NOT_FOUND" if e.code == 404 else f"HTTP_{e.code}"
        result["cr_title"] = ""
        result["cr_journal"] = ""
        result["cr_year"] = None
        result["cr_authors"] = []
        result["issues"] = [f"CrossRef HTTP {e.code}"]
        print(f"[{num:02d}] ❌ {ref['key']}: HTTP {e.code}")
    except Exception as e:
        result["status"] = "ERROR"
        result["cr_title"] = ""
        result["cr_journal"] = ""
        result["cr_year"] = None
        result["cr_authors"] = []
        result["issues"] = [str(e)[:80]]
        print(f"[{num:02d}] ⚠ {ref['key']}: {e}")
    
    time.sleep(0.25)  # polite delay for CrossRef API
    results.append(result)

# ── 3. Save JSON report ────────────────────────────────────────────────────────
report_path = "python/reference_verification_report.json"
with open(report_path, "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)
print(f"\nJSON report saved: {report_path}")

# ── 4. Generate Markdown summary ───────────────────────────────────────────────
ok = [r for r in results if r["status"] == "OK"]
fails = [r for r in results if r["status"] != "OK"]
arxiv = [r for r in results if "ARXIV_DOI" in r.get("issues", [])]
no_doi = [r for r in results if r["status"] == "NO_DOI"]
not_found = [r for r in results if "NOT_FOUND" in r.get("status","") or "404" in r.get("status","")]
title_mismatch = [r for r in results if any("TITLE_MISMATCH" in i for i in r.get("issues",[]))]
year_mismatch = [r for r in results if any("YEAR_MISMATCH" in i for i in r.get("issues",[]))]

md = f"""# Reference Verification Report

**Total references parsed:** {len(results)}  
**Verified OK (DOI resolves, title matches):** {len(ok)}  
**Failed / Issues:** {len(fails)}  

## Summary of Issues

| Category | Count |
|---|---|
| ✅ OK | {len(ok)} |
| ❌ Title mismatch (wrong paper for that DOI) | {len(title_mismatch)} |
| ❌ DOI not found in CrossRef | {len(not_found)} |
| ❌ Year mismatch | {len(year_mismatch)} |
| ❌ No DOI provided | {len(no_doi)} |
| ❌ arXiv DOI | {len(arxiv)} |

---

## Problematic References (need replacement)

"""
for r in fails:
    md += f"### [{r['num']}] `\\bibitem{{{r['key']}}}`\n"
    md += f"- **Status:** {r['status']}\n"
    md += f"- **Issues:** {', '.join(r['issues'])}\n"
    md += f"- **TEX Title:** {r['title_tex'][:100]}\n"
    if r.get("cr_title"):
        md += f"- **CrossRef Title:** {r['cr_title'][:100]}\n"
    md += f"- **DOI:** `{r.get('doi','—')}`\n"
    md += f"- **TEX Journal/Year:** {r['journal_tex']} ({r['year_tex']})\n"
    if r.get('cr_journal'):
        md += f"- **CrossRef Journal/Year:** {r['cr_journal']} ({r['cr_year']})\n"
    md += "\n"

md += "---\n\n## All References Status\n\n"
md += "| # | Key | Status | Issues |\n|---|---|---|---|\n"
for r in results:
    flag = "✅" if r["status"] == "OK" else "❌"
    issue_str = "; ".join(r.get("issues", [])) or "—"
    md += f"| {r['num']} | `{r['key']}` | {flag} {r['status']} | {issue_str} |\n"

md_path = "python/reference_verification_report.md"
with open(md_path, "w", encoding="utf-8") as f:
    f.write(md)
print(f"Markdown report saved: {md_path}")
print(f"\n✅ {len(ok)} OK  |  ❌ {len(fails)} issues  |  Total {len(results)}")
