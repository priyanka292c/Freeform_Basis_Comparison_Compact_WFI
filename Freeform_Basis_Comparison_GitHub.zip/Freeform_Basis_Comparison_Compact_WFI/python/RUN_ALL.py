﻿#!/usr/bin/env python3
"""
RUN_ALL.py
==========
Master reproducibility script.

Runs the complete research pipeline:
  1. Install/check dependencies
  2. Generate all CSV data
  3. Generate all figures
  4. Verify bibliography (requires internet)
  5. Report completion status

Author: [Author Name] | Date: 2026-09-02
"""

import sys
import subprocess
from pathlib import Path

BASE = Path(__file__).parent.parent

def check_deps():
    required = ["numpy","scipy","matplotlib","pandas","tqdm"]
    missing  = []
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"Installing missing packages: {missing}")
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
    else:
        print("All required packages available.")


def main():
    print("=" * 60)
    print("FREEFORM BASIS COMPARISON — RUN ALL")
    print("=" * 60)
    sys.path.insert(0, str(Path(__file__).parent))
    check_deps()

    from master_pipeline import main as run_pipeline
    run_pipeline()

    print("\nTo verify bibliography (requires internet):")
    print("  python bibliography.py")
    print("\nTo run OpticStudio-dependent analysis:")
    print("  Ensure OpticStudio is installed, then: python zemax_api.py")
    print("\nAll analytically computed results are in: data/csv/")
    print("All figures are in: figures/source/ and figures/publication/")
    print("=" * 60)


if __name__ == "__main__":
    main()
