import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Remove \enlargethispage{4\baselineskip} from Conclusions (replace with moderate 2\baselineskip)
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Conclusions\}',
             r'\\enlargethispage{2\\baselineskip}\n\\section{Conclusions}',
             tex)

# 2. Insert \vfill\null\pagebreak before \begin{thebibliography} so it cleanly starts at top of Column 2
# Check if \newpage is before \begin{thebibliography}
tex = re.sub(r'(\\noindent\\textbf\{Acknowledgements\}:.*?)(?=\\begin\{thebibliography\})',
             r'\1\n\n\\vfill\\null\\pagebreak\n\n',
             tex,
             flags=re.DOTALL)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex with column break before thebibliography. Compiling...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
