import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# 1. Compact enumerate in Conclusions
old_enum = r"""\begin{enumerate}
\item Under $N=6$ active freeform departure coefficients"""

new_enum = r"""\begin{enumerate}\setlength{\itemsep}{1pt plus 0.5pt}\setlength{\parskip}{0pt}\setlength{\topsep}{2pt}
\item Under $N=6$ active freeform departure coefficients"""

tex = tex.replace(old_enum, new_enum)

# 2. Compact Declarations block
old_decl = r"""\noindent\textbf{Data and Code Availability}: The computational scripts, optical design models, tolerance routines, and simulation datasets supporting the findings of this study are available in the public repository at \url{https://github.com/Priyanka-Optics/Freeform_Basis_Comparison_Compact_WFI}, with permanent digital archive deposited on Zenodo (\doi{10.5281/zenodo.14028461}).

\noindent\textbf{Author Contributions}: P.S.\ formulated the models, developed the Python and MATLAB pipelines, conducted all simulations, and wrote the manuscript.

\noindent\textbf{Funding}: Supported by the Advanced Optical Systems and Computational Photonics Research Initiative.

\noindent\textbf{Conflict of Interest}: The author declares no competing conflicts of interest.

\noindent\textbf{Acknowledgements}: The author acknowledges NumPy, SciPy, Matplotlib, Pandas, Pymoo, MiKTeX, and Ansys Zemax for computational modeling resources."""

new_decl = r"""\noindent\textbf{Data and Code Availability}: The computational scripts, optical design models, tolerance routines, and simulation datasets supporting the findings of this study are available at \url{https://github.com/Priyanka-Optics/Freeform_Basis_Comparison_Compact_WFI}, with permanent archive on Zenodo (\doi{10.5281/zenodo.14028461}).\\[0.2em]
\noindent\textbf{Author Contributions}: P.S.\ formulated the models, developed pipelines, conducted all simulations, and wrote the manuscript.\\[0.2em]
\noindent\textbf{Funding}: Supported by the Advanced Optical Systems and Computational Photonics Research Initiative.\\[0.2em]
\noindent\textbf{Conflict of Interest}: The author declares no competing conflicts of interest.\\[0.2em]
\noindent\textbf{Acknowledgements}: Computational modeling resources provided by NumPy, SciPy, Matplotlib, Pandas, Pymoo, MiKTeX, and Zemax."""

assert old_decl in tex, "old_decl not found!"
tex = tex.replace(old_decl, new_decl)

# 3. Moderate \enlargethispage{2\baselineskip} on Conclusions
tex = re.sub(r'\\enlargethispage\{.*?\}\s*\\section\{Conclusions\}',
             r'\\enlargethispage{2\\baselineskip}\n\\section{Conclusions}',
             tex)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Saved main.tex with compact declarations and conclusions. Compiling...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
