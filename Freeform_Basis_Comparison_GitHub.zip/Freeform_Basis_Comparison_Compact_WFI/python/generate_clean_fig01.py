import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

def generate_clean_fig01():
    # Configure clean, elegant typography
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans", "Helvetica", "sans-serif"],
        "font.size": 9.0,
        "figure.dpi": 300,
        "text.antialiased": True
    })

    fig, ax = plt.subplots(figsize=(11.5, 7.8), dpi=300)
    ax.set_xlim(0, 115)
    ax.set_ylim(0, 100)
    ax.axis("off")

    fig.patch.set_facecolor("#ffffff")
    ax.set_facecolor("#ffffff")

    # =========================================================================
    # STAGE 1: OPTICAL REQUIREMENTS & BASELINE INITIALIZATION
    # =========================================================================
    stage1_rect = mpatches.FancyBboxPatch(
        (4, 82), 107, 15,
        boxstyle="round,pad=1.2,rounding_size=2.0",
        facecolor="#f8fafc", edgecolor="#94a3b8", linewidth=1.2, zorder=1
    )
    ax.add_patch(stage1_rect)
    
    # Header tag
    tag1 = mpatches.FancyBboxPatch(
        (7, 93.5), 36, 4.2,
        boxstyle="round,pad=0.5,rounding_size=1.0",
        facecolor="#1e293b", edgecolor="none", zorder=2
    )
    ax.add_patch(tag1)
    ax.text(25, 95.6, "STAGE 1: SYSTEM SPECIFICATION", ha="center", va="center",
            fontsize=8.2, fontweight="bold", color="#ffffff")

    # Left Section: Specifications
    ax.text(30, 91.0, "Optical Requirements & Packaging Envelope", ha="center", va="center",
            fontsize=8.5, fontweight="bold", color="#0f172a")
    spec_text = (
        r"$\bullet$ Focal length: $f = 150.0\,\mathrm{mm}$   $\bullet$ Speed: $F/7.5$   $\bullet$ FoV: $\pm 4.0^\circ$" + "\n"
        r"$\bullet$ Band: $450\text{--}900\,\mathrm{nm}$   $\bullet$ Clear aperture: $20\,\mathrm{mm}$   $\bullet$ Track $\leq 250\,\mathrm{mm}$"
    )
    ax.text(30, 86.0, spec_text, ha="center", va="center", fontsize=7.8, color="#334155", linespacing=1.4)

    # Divider line
    ax.plot([55, 55], [84, 94], color="#cbd5e1", lw=1.2, ls="--")

    # Right Section: Baseline System
    ax.text(82, 91.0, "Baseline Aspheric System Initialization", ha="center", va="center",
            fontsize=8.5, fontweight="bold", color="#0f172a")
    base_text = (
        r"$\bullet$ Off-axis two-mirror reflective architecture (unobscured)" + "\n"
        r"$\bullet$ Primary (M1): $R_1 = -80.0\,\mathrm{mm},\; k_1 = -0.50$ (Even asphere)" + "\n"
        r"$\bullet$ Secondary (M2): $R_2 = -20.0\,\mathrm{mm},\; k_2 = -2.00$ (Even asphere)"
    )
    ax.text(82, 85.8, base_text, ha="center", va="center", fontsize=7.6, color="#334155", linespacing=1.35)

    # Connector Arrow Stage 1 -> Stage 2
    ax.annotate("", xy=(57.5, 78.8), xytext=(57.5, 82.0),
                arrowprops=dict(arrowstyle="-|>", color="#0284c7", lw=2.0, mutation_scale=15))

    # =========================================================================
    # STAGE 2: SEVEN SURFACE REPRESENTATIONS
    # =========================================================================
    stage2_rect = mpatches.FancyBboxPatch(
        (4, 53), 107, 25.5,
        boxstyle="round,pad=1.2,rounding_size=2.0",
        facecolor="#f0fdf4", edgecolor="#86efac", linewidth=1.2, zorder=1
    )
    ax.add_patch(stage2_rect)

    tag2 = mpatches.FancyBboxPatch(
        (7, 75.0), 50, 4.2,
        boxstyle="round,pad=0.5,rounding_size=1.0",
        facecolor="#166534", edgecolor="none", zorder=2
    )
    ax.add_patch(tag2)
    ax.text(32, 77.1, "STAGE 2: SEVEN FREEFORM SURFACE REPRESENTATIONS", ha="center", va="center",
            fontsize=8.2, fontweight="bold", color="#ffffff")

    reps = [
        # Row 1 (4 bases)
        {"name": "Even Asphere", "sub": "Rotational Baseline", "math": r"1D series: $z(r) = \mathrm{conic} + \sum a_i r^{2i}$",
         "col": "#f8fafc", "border": "#64748b", "tag": "Baseline", "x": 18, "y": 66.5, "w": 25, "h": 7.8},
        {"name": "Zernike Fringe", "sub": "Optical Metrology", "math": r"37-term standard circular ordering",
         "col": "#f0f9ff", "border": "#0284c7", "tag": "Fringe Set", "x": 45, "y": 66.5, "w": 25, "h": 7.8},
        {"name": "Zernike Standard", "sub": "ANSI / Noll Ordering", "math": r"Orthogonal circular basis $Z_n^m(\rho,\theta)$",
         "col": "#f0fdfa", "border": "#0d9488", "tag": "Noll Order", "x": 72, "y": 66.5, "w": 25, "h": 7.8},
        {"name": "Cartesian XY", "sub": "Standard Monomials", "math": r"Power series: $\sum c_{ij} x^i y^j$ (Coupled)",
         "col": "#fffbeb", "border": "#d97706", "tag": "Monomials", "x": 98.5, "y": 66.5, "w": 24, "h": 7.8},
        
        # Row 2 (3 advanced bases)
        {"name": r"Forbes $Q$-Type ($Q_\mathrm{bfs}$)", "sub": "Slope-Orthogonal Basis", "math": r"Jacobi polynomials orthonormal in $\nabla z$",
         "col": "#ecfdf5", "border": "#059669", "tag": "Orthogonal Slope", "x": 23, "y": 57.2, "w": 33, "h": 7.8},
        {"name": "2D Chebyshev", "sub": "Tensor-Product Orthogonal", "math": r"$T_m(x) T_n(y)$ on mapped rectangular domain",
         "col": "#faf5ff", "border": "#7c3aed", "tag": "Rectangular", "x": 58, "y": 57.2, "w": 33, "h": 7.8},
        {"name": "TrueFreeForm (Grid PCA)", "sub": "PCA-Filtered Bicubic Grid", "math": r"$16\times 16$ mesh with 6 dominant PCA modes",
         "col": "#fff1f2", "border": "#e11d48", "tag": "Discrete / Spline", "x": 93, "y": 57.2, "w": 33, "h": 7.8},
    ]

    for r in reps:
        rc = mpatches.FancyBboxPatch(
            (r["x"] - r["w"]/2, r["y"] - r["h"]/2), r["w"], r["h"],
            boxstyle="round,pad=0.3,rounding_size=1.0",
            facecolor=r["col"], edgecolor=r["border"], linewidth=1.1, zorder=3
        )
        ax.add_patch(rc)
        
        badge = mpatches.FancyBboxPatch(
            (r["x"] + r["w"]/2 - 11.5, r["y"] + r["h"]/2 - 2.5), 11.0, 2.2,
            boxstyle="round,pad=0.2,rounding_size=0.6",
            facecolor=r["border"], edgecolor="none", zorder=4
        )
        ax.add_patch(badge)
        ax.text(r["x"] + r["w"]/2 - 6.0, r["y"] + r["h"]/2 - 1.4, r["tag"],
                ha="center", va="center", fontsize=6.2, fontweight="bold", color="#ffffff", zorder=5)

        ax.text(r["x"] - r["w"]/2 + 1.2, r["y"] + 1.7, r["name"],
                ha="left", va="center", fontsize=7.8, fontweight="bold", color="#0f172a", zorder=5)
        ax.text(r["x"] - r["w"]/2 + 1.2, r["y"] - 0.2, r["sub"],
                ha="left", va="center", fontsize=6.8, color="#475569", zorder=5)
        ax.text(r["x"] - r["w"]/2 + 1.2, r["y"] - 2.2, r["math"],
                ha="left", va="center", fontsize=6.5, color="#1e293b", zorder=5)

    # Connector Arrow Stage 2 -> Stage 3
    ax.annotate("", xy=(57.5, 49.5), xytext=(57.5, 53.0),
                arrowprops=dict(arrowstyle="-|>", color="#0284c7", lw=2.0, mutation_scale=15))

    # =========================================================================
    # STAGE 3: NORMALIZATION & FAIR-COMPARISON PROTOCOL
    # =========================================================================
    stage3_rect = mpatches.FancyBboxPatch(
        (4, 38.2), 107, 11.5,
        boxstyle="round,pad=0.8,rounding_size=1.5",
        facecolor="#eff6ff", edgecolor="#93c5fd", linewidth=1.2, zorder=1
    )
    ax.add_patch(stage3_rect)

    tag3 = mpatches.FancyBboxPatch(
        (30, 46.5), 55, 3.2,
        boxstyle="round,pad=0.4,rounding_size=0.8",
        facecolor="#1e40af", edgecolor="none", zorder=2
    )
    ax.add_patch(tag3)
    ax.text(57.5, 48.1, "STAGE 3: FAIR-COMPARISON PROTOCOL (P1–P4)", ha="center", va="center",
            fontsize=8.2, fontweight="bold", color="#ffffff", zorder=3)

    proto_cards = [
        {
            "x": 5.5, "w": 25.0, "h": 7.0,
            "title": "P1: Equal Active DoF",
            "tag_col": "#2563eb",
            "lines": [r"$\bullet$ $N = 6$ active terms", r"$\bullet$ Matched 6-mode PCA"]
        },
        {
            "x": 32.2, "w": 25.0, "h": 7.0,
            "title": "P2: Normalized Bounds",
            "tag_col": "#2563eb",
            "lines": [r"$\bullet$ $|a_m| \leq 0.3\,\mathrm{mm}$ envelope", r"$\bullet$ $R_\mathrm{norm} = 10.0\,\mathrm{mm}$ pupil"]
        },
        {
            "x": 58.8, "w": 25.0, "h": 7.0,
            "title": "P3: Identical Engine",
            "tag_col": "#2563eb",
            "lines": [r"$\bullet$ Damped Least Squares", r"$\bullet$ Identical merit weights"]
        },
        {
            "x": 85.5, "w": 25.0, "h": 7.0,
            "title": "P4: Packaging Invariance",
            "tag_col": "#2563eb",
            "lines": [r"$\bullet$ Identical clearances", r"$\bullet$ $\theta_y = +3.5^\circ$, track $\leq 250\,\mathrm{mm}$"]
        }
    ]

    for c in proto_cards:
        c_rect = mpatches.FancyBboxPatch(
            (c["x"], 39.0), c["w"], c["h"],
            boxstyle="round,pad=0.4,rounding_size=1.0",
            facecolor="#ffffff", edgecolor="#bfdbfe", linewidth=0.9, zorder=2
        )
        ax.add_patch(c_rect)

        c_tag = mpatches.FancyBboxPatch(
            (c["x"] + 1.0, 43.6), c["w"] - 2.0, 2.0,
            boxstyle="round,pad=0.2,rounding_size=0.5",
            facecolor=c["tag_col"], edgecolor="none", zorder=3
        )
        ax.add_patch(c_tag)
        ax.text(c["x"] + c["w"]/2, 44.6, c["title"], ha="center", va="center",
                fontsize=7.0, fontweight="bold", color="#ffffff", zorder=4)

        y_cl = 42.0
        for l in c["lines"]:
            ax.text(c["x"] + 1.8, y_cl, l, ha="left", va="center",
                    fontsize=6.8, color="#1e293b", zorder=4)
            y_cl -= 1.8

    # Connectors Stage 3 -> Stage 4 (3 clean parallel arrows strictly in the vertical gap)
    arrow_props4 = dict(arrowstyle="-|>", color="#2563eb", lw=1.8, mutation_scale=14)
    ax.annotate("", xy=(21, 34.7), xytext=(21, 37.8), arrowprops=arrow_props4)
    ax.annotate("", xy=(57.5, 34.7), xytext=(57.5, 37.8), arrowprops=arrow_props4)
    ax.annotate("", xy=(94, 34.7), xytext=(94, 37.8), arrowprops=arrow_props4)

    # =========================================================================
    # STAGE 4: THREE MULTI-PHYSICS EVALUATION PILLARS
    # =========================================================================
    pillars = [
        {
            "x": 21, "w": 34, "h": 32,
            "title": "PILLAR A: GEOMETRY & PSD SPECTRA",
            "tag_col": "#0284c7",
            "bg_col": "#f0f9ff", "border_col": "#bae6fd",
            "items": [
                r"$\bullet$ Nominal Wavefront Error (RMS WFE)",
                r"$\bullet$ Freeform Sag Departure $\Delta z(x,y)$",
                r"$\bullet$ Surface Gradient & Peak Slope $S_\mathrm{max}$",
                r"$\bullet$ Laplacian Curvature Proxy $\nabla^2 z$",
                r"$\bullet$ 2D Power Spectral Density (PSD):",
                r"   - LSF Band ($f_r < 0.1\,\mathrm{c/mm}$)",
                r"   - MSF Band ($0.1 \leq f_r \leq 2.0\,\mathrm{c/mm}$)",
                r"   - HSF Band ($f_r > 2.0\,\mathrm{c/mm}$)",
                r"$\bullet$ Freeform Complexity Index (FCI)",
            ]
        },
        {
            "x": 57.5, "w": 36, "h": 32,
            "title": "PILLAR B: 175,000 MONTE-CARLO RUNS",
            "tag_col": "#ea580c",
            "bg_col": "#fff7ed", "border_col": "#ffedd5",
            "items": [
                r"$\bullet$ ISO 10110 Optomechanical Perturbations:",
                r"   - Decenter: $\Delta x, \Delta y \in [-50, +50]\,\mu\mathrm{m}$",
                r"   - Tilt: $\theta_x, \theta_y \in [-0.5, +0.5]\,\mathrm{mrad}$",
                r"   - Airspace Despace: $\Delta z \in [-50, +50]\,\mu\mathrm{m}$",
                r"   - Surface Irregularity: $\pm 0.1\,\mu\mathrm{m}$ RMS",
                r"$\bullet$ Multi-Seed Reproducibility ($5 \times 5,000$ trials)",
                r"$\bullet$ As-Built Tolerance Yield ($\mathrm{WFE} \leq \lambda/14$)",
                r"$\bullet$ Statistical Hypothesis Testing:",
                r"   - One-way ANOVA ($F = 35047, p < 10^{-15}$)",
                r"   - Pairwise Tukey HSD ($p < 10^{-4}$)",
            ]
        },
        {
            "x": 94, "w": 34, "h": 32,
            "title": "PILLAR C: PARETO & DECISION MATRIX",
            "tag_col": "#7c3aed",
            "bg_col": "#faf5ff", "border_col": "#f3e8ff",
            "items": [
                r"$\bullet$ Coefficient Cross-Coupling Matrix $|C_{ij}|$",
                r"$\bullet$ Optimizer Hessian Conditioning $\kappa(H)$",
                r"$\bullet$ 3-Objective NSGA-II Pareto Optimization:",
                r"   - Minimize Nominal RMS WFE",
                r"   - Minimize Geometric Complexity (FCI)",
                r"   - Minimize Surface Slope ($S_\mathrm{max}$)",
                r"$\bullet$ Multi-Criteria Engineering Decision Matrix",
                r"$\bullet$ Independent Cross-Validation (Python/MATLAB):",
                r"   - Sag residual agreement $< 10^{-13}\,\mathrm{mm}$",
            ]
        },
    ]

    for p in pillars:
        prect = mpatches.FancyBboxPatch(
            (p["x"] - p["w"]/2, 2.5), p["w"], p["h"],
            boxstyle="round,pad=0.8,rounding_size=1.8",
            facecolor=p["bg_col"], edgecolor=p["border_col"], linewidth=1.2, zorder=1
        )
        ax.add_patch(prect)

        ptag = mpatches.FancyBboxPatch(
            (p["x"] - p["w"]/2 + 1.5, 30.8), p["w"] - 3.0, 3.2,
            boxstyle="round,pad=0.4,rounding_size=0.8",
            facecolor=p["tag_col"], edgecolor="none", zorder=2
        )
        ax.add_patch(ptag)
        ax.text(p["x"], 32.4, p["title"], ha="center", va="center",
                fontsize=7.3, fontweight="bold", color="#ffffff", zorder=3)

        y_cursor = 28.5
        for item in p["items"]:
            is_sub = item.startswith(r"   -")
            fsize = 6.6 if is_sub else 7.1
            fcol = "#475569" if is_sub else "#0f172a"
            ax.text(p["x"] - p["w"]/2 + 2.0, y_cursor, item, ha="left", va="center",
                    fontsize=fsize, color=fcol, zorder=3)
            y_cursor -= 2.65

    # Bottom Synthesis Banner
    synth_rect = mpatches.FancyBboxPatch(
        (4, 0.4), 107, 1.8,
        boxstyle="round,pad=0.2,rounding_size=0.6",
        facecolor="#1e293b", edgecolor="none", zorder=2
    )
    ax.add_patch(synth_rect)
    ax.text(57.5, 1.3,
            "SYNTHESIS: Trade-Off Analysis between Optical Performance, Geometric Complexity, and Manufacturing Tolerance Robustness",
            ha="center", va="center", fontsize=7.2, fontweight="bold", color="#f8fafc", zorder=3)

    out_png = Path("figures/source/fig01_flowchart.png")
    out_pub = Path("figures/publication/fig01_flowchart.png")
    out_png.parent.mkdir(parents=True, exist_ok=True)
    out_pub.parent.mkdir(parents=True, exist_ok=True)

    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.savefig(out_pub, dpi=300, bbox_inches="tight")
    plt.close()
    print("Clean Figure 1 generated successfully!")

if __name__ == "__main__":
    generate_clean_fig01()
