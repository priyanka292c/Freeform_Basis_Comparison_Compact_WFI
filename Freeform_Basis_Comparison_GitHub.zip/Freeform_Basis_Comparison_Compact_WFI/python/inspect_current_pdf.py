import pypdf
import sys
sys.stdout.reconfigure(encoding='utf-8')

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Total pages: {len(reader.pages)}")
for p in range(7, len(reader.pages)+1):
    print(f"\n=== PAGE {p} ===")
    text = reader.pages[p-1].extract_text()
    lines = text.split('\n')
    for line in lines[:6]:
        print(" TOP: ", line)
    print(" ...")
    for line in lines[-6:]:
        print(" BOT: ", line)
