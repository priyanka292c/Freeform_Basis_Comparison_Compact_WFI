﻿"""
statistics.py
=============
Statistical analysis of freeform surface comparison results.

Methods:
  - Descriptive statistics (mean, std, median, CI)
  - One-way ANOVA (parametric)
  - Kruskal-Wallis test (non-parametric)
  - Tukey HSD post-hoc test
  - Effect size (eta-squared, Cohen d)
  - Multiple comparison correction (Bonferroni, Holm)
  - Pareto front analysis

Author: [Author Name] | Date: 2026-09-02 | RANDOM SEED: 42
"""

import numpy as np
import pandas as pd
from scipy import stats
from itertools import combinations
from pathlib import Path


def descriptive_stats(groups: dict[str, np.ndarray]) -> pd.DataFrame:
    """
    Compute descriptive statistics for each group.

    Parameters
    ----------
    groups : dict {label: array_of_values}

    Returns
    -------
    DataFrame with mean, std, median, CI95, min, max, n
    """
    rows = []
    for label, data in groups.items():
        data = np.asarray(data)
        n = len(data)
        mean = data.mean()
        std  = data.std(ddof=1)
        ci95 = 1.96 * std / np.sqrt(n)
        rows.append({
            "surface":  label,
            "n":        n,
            "mean":     mean,
            "std":      std,
            "median":   np.median(data),
            "p5":       np.percentile(data, 5),
            "p95":      np.percentile(data, 95),
            "ci95_lo":  mean - ci95,
            "ci95_hi":  mean + ci95,
            "min":      data.min(),
            "max":      data.max(),
        })
    return pd.DataFrame(rows)


def one_way_anova(groups: dict[str, np.ndarray]) -> dict:
    """
    One-way ANOVA across groups.

    Returns F-statistic, p-value, and eta-squared effect size.
    Assumptions: normality within groups, homoscedasticity.
    """
    keys = list(groups.keys())
    arrays = [np.asarray(groups[k]) for k in keys]
    F, p = stats.f_oneway(*arrays)
    # Eta-squared
    all_data = np.concatenate(arrays)
    grand_mean = all_data.mean()
    ss_between = sum(len(a) * (a.mean() - grand_mean)**2 for a in arrays)
    ss_total   = sum((a - grand_mean)**2 for a in arrays for a in [a]).sum()
    eta2 = ss_between / ss_total if ss_total > 0 else np.nan
    return {"F": F, "p": p, "eta_squared": eta2, "groups": keys}


def kruskal_wallis(groups: dict[str, np.ndarray]) -> dict:
    """
    Kruskal-Wallis H test (non-parametric ANOVA alternative).
    """
    keys = list(groups.keys())
    arrays = [np.asarray(groups[k]) for k in keys]
    H, p = stats.kruskal(*arrays)
    return {"H": H, "p": p, "groups": keys}


def tukey_hsd(groups: dict[str, np.ndarray]) -> pd.DataFrame:
    """
    Pairwise Tukey HSD post-hoc comparisons.

    Returns DataFrame with pairs, mean difference, and adjusted p-values.
    Note: uses scipy statsmodels if available; falls back to manual t-test
    with Bonferroni correction.
    """
    try:
        from statsmodels.stats.multicomp import pairwise_tukeyhsd
        all_data   = np.concatenate([np.asarray(v) for v in groups.values()])
        all_labels = np.concatenate([[k]*len(v) for k, v in groups.items()])
        result = pairwise_tukeyhsd(all_data, all_labels, alpha=0.05)
        df = pd.DataFrame(data=result._results_table.data[1:],
                          columns=result._results_table.data[0])
        df["method"] = "Tukey_HSD"
        return df
    except ImportError:
        # Fallback: pairwise t-tests with Bonferroni correction
        keys = list(groups.keys())
        pairs = list(combinations(keys, 2))
        rows = []
        for g1, g2 in pairs:
            a1, a2 = np.asarray(groups[g1]), np.asarray(groups[g2])
            t, p = stats.ttest_ind(a1, a2)
            p_bonf = min(p * len(pairs), 1.0)
            rows.append({"group1": g1, "group2": g2,
                         "mean_diff": a1.mean() - a2.mean(),
                         "t_stat": t, "p_raw": p, "p_bonferroni": p_bonf,
                         "method": "t-test_Bonferroni"})
        return pd.DataFrame(rows)


def shapiro_normality(data: np.ndarray, label: str = "") -> dict:
    """Shapiro-Wilk normality test (n <= 5000)."""
    if len(data) > 5000:
        data = data[:5000]
    stat, p = stats.shapiro(data)
    return {"label": label, "W": stat, "p": p,
            "normal_at_0.05": p > 0.05}


def cohen_d(a: np.ndarray, b: np.ndarray) -> float:
    """Cohen's d effect size between two groups."""
    pooled_std = np.sqrt((a.std(ddof=1)**2 + b.std(ddof=1)**2) / 2)
    return (a.mean() - b.mean()) / pooled_std if pooled_std > 0 else 0.0


def pareto_front(objectives: pd.DataFrame,
                 maximise: list[str] | None = None) -> pd.DataFrame:
    """
    Find the Pareto-optimal solutions from a DataFrame of objectives.

    Parameters
    ----------
    objectives : DataFrame where each row is a solution and each column an objective
    maximise   : list of column names to maximise (others are minimised)

    Returns
    -------
    DataFrame of Pareto-optimal rows
    """
    df = objectives.copy()
    # Convert maximise objectives to negative (so all become minimise)
    sign = pd.Series(1.0, index=df.columns)
    if maximise:
        for col in maximise:
            sign[col] = -1.0
    data = (df * sign).values
    n = len(data)
    is_pareto = np.ones(n, dtype=bool)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            if np.all(data[j] <= data[i]) and np.any(data[j] < data[i]):
                is_pareto[i] = False
                break
    return objectives[is_pareto].reset_index(drop=True)


if __name__ == "__main__":
    print("statistics.py: module loaded.")
