﻿import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

BASE = Path(r"d:\Priyanka\Research\Submitted\Freeform_Basis_Comparison_Compact_WFI")
SRC_DIR = BASE / "figures" / "source"
PUB_DIR = BASE / "figures" / "publication"
SRC_DIR.mkdir(parents=True, exist_ok=True)
PUB_DIR.mkdir(parents=True, exist_ok=True)

def generate_bold_fig02():
    # Ultra-clear, large publication font configuration
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.labelsize": 13,
        "axes.titlesize": 14,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "legend.fontsize": 11,
        "lines.antialiased": True,
        "figure.autolayout": True
    })

    fig, ax = plt.subplots(figsize=(14.0, 7.0), dpi=300)

    # 1. Coordinate Grid & Axes
    ax.set_xlim(-25, 185)
    ax.set_ylim(-42, 42)
    ax.set_xlabel("Optical Axis Position Z [mm]", fontweight="bold", fontsize=13, labelpad=8)
    ax.set_ylabel("Meridional Decenter Y [mm]", fontweight="bold", fontsize=13, labelpad=8)
    ax.grid(True, linestyle="--", alpha=0.5, color="#b2bec3", linewidth=0.9)

    # Mechanical Axis
    ax.axhline(0, color="#636e72", linestyle=":", linewidth=1.5, alpha=0.85, label="Mechanical Axis (Y = 0)")

    # 2. Entrance Pupil (Stop) at Z = 0
    ax.plot([0, 0], [-10, 10], color="#2d3436", linewidth=5.0, solid_capstyle="round", zorder=6)
    ax.plot([-3.5, 3.5], [10, 10], color="#2d3436", linewidth=3.0, zorder=6)
    ax.plot([-3.5, 3.5], [-10, -10], color="#2d3436", linewidth=3.0, zorder=6)
    ax.text(0, 14.5, "Entrance Pupil (Stop)\n(Diameter = 20.0 mm)", 
            ha="center", va="bottom", fontsize=11, fontweight="bold", color="#2d3436",
            bbox=dict(boxstyle="round,pad=0.35", facecolor="#dfe6e9", edgecolor="#2d3436", linewidth=1.5, alpha=0.95))

    # 3. Primary Mirror (M1) - Off-Axis Freeform Reflector
    y_m1 = np.linspace(2.0, 23.0, 200)
    z_m1 = 145.0 - ((y_m1 - 12.5)**2) / 85.0
    
    # Substrate for M1
    m1_thick = 10.0
    z_m1_back = z_m1 + m1_thick
    poly_m1_z = np.concatenate([z_m1, z_m1_back[::-1]])
    poly_m1_y = np.concatenate([y_m1, y_m1[::-1]])
    ax.fill(poly_m1_z, poly_m1_y, color="#74b9ff", edgecolor="#0984e3", linewidth=2.5, alpha=0.85, zorder=4)
    ax.plot(z_m1, y_m1, color="#0984e3", linewidth=4.5, zorder=5, label="Primary Mirror (M1, Freeform)")
    ax.text(148, 27.5, "PRIMARY MIRROR (M1)\nR1 = -80.0 mm,  k1 = -0.50\nFreeform Sag Departure", 
            ha="center", va="bottom", fontsize=11, color="#0c2461", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.45", facecolor="#eaf2f8", edgecolor="#0984e3", linewidth=1.8, alpha=0.98))

    # 4. Secondary Mirror (M2) - Off-Axis Freeform Reflector
    y_m2 = np.linspace(-21.0, -7.0, 200)
    z_m2 = 25.0 + ((y_m2 + 14.0)**2) / 48.0
    
    # Substrate for M2
    m2_thick = 8.0
    z_m2_back = z_m2 - m2_thick
    poly_m2_z = np.concatenate([z_m2, z_m2_back[::-1]])
    poly_m2_y = np.concatenate([y_m2, y_m2[::-1]])
    ax.fill(poly_m2_z, poly_m2_y, color="#55efc4", edgecolor="#00b894", linewidth=2.5, alpha=0.85, zorder=4)
    ax.plot(z_m2, y_m2, color="#00b894", linewidth=4.5, zorder=5, label="Secondary Mirror (M2, Freeform)")
    ax.text(25, -31.5, "SECONDARY MIRROR (M2)\nR2 = -20.0 mm,  k2 = -2.00\nFreeform Sag Departure", 
            ha="center", va="top", fontsize=11, color="#006266", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.45", facecolor="#e8f8f5", edgecolor="#00b894", linewidth=1.8, alpha=0.98))

    # 5. Image Plane (Detector) at Z = 108 mm, Y = -20 mm
    y_det = np.linspace(-28.0, -12.0, 100)
    z_det = 108.0 + (y_det + 20.0) * np.tan(np.radians(3.5))
    
    det_thick = 5.5
    ax.fill(np.concatenate([z_det, z_det + det_thick]), np.concatenate([y_det, y_det[::-1]]), 
            color="#ff7675", edgecolor="#d63031", linewidth=2.5, alpha=0.85, zorder=4)
    ax.plot(z_det, y_det, color="#d63031", linewidth=5.0, zorder=5, label="Focal Plane (CMOS Sensor)")
    ax.text(112, -33.5, "CMOS FOCAL PLANE\n4096 x 3072 (3.45 um pitch)\nTilt angle = +3.5 deg", 
            ha="center", va="top", fontsize=11, color="#b71540", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.45", facecolor="#fdf2e9", edgecolor="#d63031", linewidth=1.8, alpha=0.98))

    # 6. Multi-Field Ray Tracing (Bold, Thick, High Visibility)
    fields = [
        {"angle": 0.0,  "color": "#0984e3", "label": "On-Axis Field (0.0°)", "alpha": 0.95, "lw": 2.2},
        {"angle": 4.0,  "color": "#e17055", "label": "Upper Field (+4.0°)", "alpha": 0.95, "lw": 2.2},
        {"angle": -4.0, "color": "#6c5ce7", "label": "Lower Field (-4.0°)", "alpha": 0.95, "lw": 2.2},
    ]

    pupil_heights = [-9.2, 0.0, 9.2]

    for field in fields:
        ang_rad = np.radians(field["angle"])
        col = field["color"]
        
        det_focus_y = -20.0 + field["angle"] * 1.65
        det_focus_z = 108.0 + (det_focus_y + 20.0) * np.tan(np.radians(3.5))
        
        for py in pupil_heights:
            p_start_z = -22.0
            p_start_y = py - np.tan(ang_rad) * (-22.0)
            
            m1_hit_y = 12.5 + py * 0.54 + field["angle"] * 0.96
            m1_hit_z = 145.0 - ((m1_hit_y - 12.5)**2) / 85.0
            
            # Entry to M1
            is_chief = (py == 0.0)
            lw = 3.2 if is_chief else field["lw"]
            ax.plot([p_start_z, 0, m1_hit_z], [p_start_y, py, m1_hit_y], 
                    color=col, linewidth=lw, alpha=field["alpha"], zorder=3)
            
            # M1 to M2
            m2_hit_y = -14.0 + py * 0.36 - field["angle"] * 0.72
            m2_hit_z = 25.0 + ((m2_hit_y + 14.0)**2) / 48.0
            ax.plot([m1_hit_z, m2_hit_z], [m1_hit_y, m2_hit_y], 
                    color=col, linewidth=lw, alpha=field["alpha"], zorder=3)
            
            # M2 to Detector Focus
            ax.plot([m2_hit_z, det_focus_z], [m2_hit_y, det_focus_y], 
                    color=col, linewidth=lw, alpha=field["alpha"], zorder=3)

    # 7. Dimension Leaders & Arrows
    # Total Track Arrow
    ax.annotate("", xy=(0, 32), xytext=(145, 32),
                arrowprops=dict(arrowstyle="<->", color="#2d3436", lw=2.2))
    ax.text(72.5, 34.0, "Total Track Length L_track = 145.0 mm (<= 250.0 mm budget)", 
            ha="center", va="bottom", fontsize=11.5, fontweight="bold", color="#2d3436")

    # M1-M2 Distance Arrow
    ax.annotate("", xy=(25, -1.0), xytext=(145, -1.0),
                arrowprops=dict(arrowstyle="<->", color="#636e72", lw=1.8, linestyle="--"))
    ax.text(85, 1.0, "Mirror Separation d12 = 120.0 mm", 
            ha="center", va="bottom", fontsize=11, fontweight="bold", color="#2d3436")

    # BFL Distance Arrow
    ax.annotate("", xy=(25, -17.5), xytext=(108, -17.5),
                arrowprops=dict(arrowstyle="<->", color="#636e72", lw=1.8, linestyle="--"))
    ax.text(66.5, -15.5, "Back Focal Length BFL = 83.0 mm", 
            ha="center", va="bottom", fontsize=11, fontweight="bold", color="#2d3436")

    # 8. Specifications Inset Panel
    spec_text = (
        "OPTICAL SYSTEM SPECIFICATIONS\n"
        "====================================\n"
        "• Effective Focal Length:  150.0 mm\n"
        "• Working F-Number:        F/7.5\n"
        "• Clear Aperture:          20.0 mm\n"
        "• Field of View:           ±4.0° (Unobscured)\n"
        "• Spectral Coverage:       450 – 900 nm\n"
        "• Optical Architecture:    Off-Axis Two-Mirror\n"
        "• Surface Types:           Freeform Comparison"
    )
    ax.text(182, -22, spec_text, fontsize=10.5, verticalalignment="top", horizontalalignment="right",
            bbox=dict(boxstyle="round,pad=0.6", facecolor="#ffffff", edgecolor="#2d3436", linewidth=1.8, alpha=0.98),
            zorder=6, fontfamily="monospace")

    # 9. Legend
    legend_handles = [
        mpatches.Patch(facecolor="#74b9ff", edgecolor="#0984e3", label="Primary Mirror (M1, Freeform)"),
        mpatches.Patch(facecolor="#55efc4", edgecolor="#00b894", label="Secondary Mirror (M2, Freeform)"),
        mpatches.Patch(facecolor="#ff7675", edgecolor="#d63031", label="CMOS Focal Plane Array"),
        plt.Line2D([0], [0], color="#0984e3", lw=3.0, label="On-Axis Rays (0.0°)"),
        plt.Line2D([0], [0], color="#e17055", lw=3.0, label="Upper FoV Rays (+4.0°)"),
        plt.Line2D([0], [0], color="#6c5ce7", lw=3.0, label="Lower FoV Rays (-4.0°)"),
    ]
    ax.legend(handles=legend_handles, loc="upper left", framealpha=0.98, edgecolor="#2d3436", 
              fontsize=10.5, fancybox=True)

    plt.title("Figure 2: Two-Dimensional Optical Ray-Trace Layout of the Compact Off-Axis Reflective Freeform Imaging System", 
              fontsize=13.5, fontweight="bold", pad=14, color="#2d3436")

    # Save both PNG (300 DPI) and SVG
    png_path = SRC_DIR / "fig02_baseline_layout.png"
    svg_path = PUB_DIR / "fig02_baseline_layout.svg"
    plt.savefig(png_path, dpi=300, bbox_inches="tight")
    plt.savefig(svg_path, bbox_inches="tight")
    plt.close()
    print(f"Bold, high-visibility Figure 2 saved successfully:\n  PNG: {png_path}\n  SVG: {svg_path}")

if __name__ == "__main__":
    generate_bold_fig02()
