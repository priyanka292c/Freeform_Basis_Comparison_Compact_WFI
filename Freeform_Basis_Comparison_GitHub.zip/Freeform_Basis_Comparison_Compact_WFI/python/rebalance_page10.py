import re
import subprocess
import pypdf
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

# Let's move Conflict of Interest and Acknowledgements before the thebibliography
# Currently in main.tex:
# \noindent\textbf{Data and Code Availability}...
# \noindent\textbf{Author Contributions}...
# \noindent\textbf{Funding}...
# \noindent\textbf{Conflict of Interest}...
# \noindent\textbf{Acknowledgements}...
# \begin{thebibliography}

# Let's check the font size in thebibliography
# We change it to \fontsize{5.0pt}{5.8pt}\selectfont with \itemsep=0pt plus 0.2pt
new_bib_header = r"""\begin{thebibliography}{80}
\fontsize{5.0pt}{5.8pt}\selectfont
\setlength{\itemsep}{0pt plus 0.1pt}
\setlength{\parskip}{0pt}
\setlength{\parsep}{0pt}"""

tex = re.sub(
    r'\\begin\{thebibliography\}\{80\}.*?(?=\\bibitem)',
    lambda m: new_bib_header + '\n',
    tex,
    flags=re.DOTALL
)

with open('manuscript/main.tex', 'w', encoding='utf-8') as f:
    f.write(tex)

print("Compiling main.tex with 5.0pt/5.8pt and 0pt itemsep...")
for pass_num in [1, 2]:
    res = subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', 'main.tex'],
        cwd='manuscript',
        capture_output=True,
        text=True
    )

reader = pypdf.PdfReader('manuscript/main.pdf')
print(f"Resulting pages: {len(reader.pages)}")
