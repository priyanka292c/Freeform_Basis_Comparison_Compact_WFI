import pypdf

reader = pypdf.PdfReader('manuscript/main.pdf')
text = reader.pages[9].extract_text()
print('Does text have References?:', 'References' in text)
lines = text.split('\n')
for i, l in enumerate(lines):
    if any(k in l for k in ['References', 'Conflict', 'Acknowledge', '[1]', '[2]']):
        print(f"{i:03d}: {l}")
