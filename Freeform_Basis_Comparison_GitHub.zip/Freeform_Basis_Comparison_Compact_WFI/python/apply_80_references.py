import json
import re

# Load the 80 verified clean references in exact order
with open('python/verified_80_clean.json', 'r', encoding='utf-8') as f:
    clean_refs = json.load(f)

# The keys in sequential order (1 to 80)
ordered_keys = [item['key'] for item in clean_refs]
print(f"Total keys: {len(ordered_keys)}")
assert len(ordered_keys) == 80

# Build the LaTeX bibliography string
def build_bib_string(items):
    lines = []
    lines.append("\\begin{thebibliography}{80}")
    lines.append("\\setlength{\\itemsep}{0pt plus 0.1pt}")
    lines.append("\\setlength{\\parskip}{0pt}")
    lines.append("\\scriptsize")
    
    for item in items:
        key = item['key']
        title = item.get('title', '').strip()
        title = title.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
        title = title.replace('%', '\\%').replace('#', '\\#')
        journal = item.get('journal', '').strip()
        journal = journal.replace('&amp;', '\\&').replace('&', '\\&')
        year = item.get('year', '')
        vol = item.get('vol', '')
        page = item.get('page', '')
        doi = item.get('doi', '').strip()
        
        authors = item.get('authors', [])
        if not authors:
            author_str = "Author"
        elif len(authors) == 1:
            author_str = authors[0]
        elif len(authors) == 2:
            author_str = f"{authors[0]} and {authors[1]}"
        elif len(authors) == 3:
            author_str = f"{authors[0]}, {authors[1]}, and {authors[2]}"
        else:
            author_str = f"{authors[0]} et al."
            
        vol_page = ""
        if vol and page:
            vol_page = f", vol.~{vol}, pp.~{page}"
        elif vol:
            vol_page = f", vol.~{vol}"
        elif page:
            vol_page = f", pp.~{page}"
            
        doi_str = f" \\doi{{{doi}}}" if doi else ""
        lines.append(f"\\bibitem{{{key}}} {author_str}, ``{title},'' \\emph{{{journal}}}{vol_page}, {year}.{doi_str}")
        
    lines.append("\\end{thebibliography}")
    return "\n".join(lines)

bib_tex = build_bib_string(clean_refs)

# Read current main.tex
with open('manuscript/main.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# Replace the existing thebibliography block with the 80 items
old_bib_match = re.search(r'\\begin\{thebibliography\}\{[^}]+\}.*?\\end\{thebibliography\}', text, re.DOTALL)
assert old_bib_match is not None, "Could not find old thebibliography block"
text = text[:old_bib_match.start()] + bib_tex + text[old_bib_match.end():]

print("Replaced bibliography with 80 items.")

with open('manuscript/main_with_80_bib.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print("Saved manuscript/main_with_80_bib.tex")
