STEP Solid Model Generation Procedure:
1. Open FreeCAD (>= 0.20) or Autodesk Fusion 360 / SolidWorks.
2. In FreeCAD, switch to the 'Surface' or 'Part' workbench.
3. Import the generated STL file from cad/exported_STL/<surface>_surface.stl or CSV point cloud.
4. Use 'Curves' workbench or 'Points' workbench to fit a B-spline / NURBS face to the points.
5. Create an extrude or boundary solid with mirror substrate thickness (15.0 mm).
6. Export as STEP AP214 / AP242 to cad/STEP/<surface>_mirror.step.
7. Verify aperture diameter (20.0 mm), center thickness (15.0 mm), and coordinate system alignment.
