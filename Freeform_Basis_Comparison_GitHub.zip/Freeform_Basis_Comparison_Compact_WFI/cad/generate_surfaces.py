﻿"""
generate_surfaces.py
====================
CAD surface generator for freeform optical surfaces.

Generates:
  1. CSV surface coordinate grids (X, Y, Z, dZ/dX, dZ/dY) for CAD import
  2. ASCII STL triangulated mesh files for 3D visualization and CAD import
  3. Documentation for STEP solid model creation in FreeCAD/SolidWorks

Author: [Author Name] | Date: 2026-09-02 | RANDOM SEED: 42
"""

import os
import sys
import numpy as np
import pandas as pd
from pathlib import Path

# Add python path
sys.path.insert(0, str(Path(__file__).parent.parent / "python"))

from freeform_surfaces import (
    make_grid, even_asphere_sag, zernike_sag, xy_polynomial_sag,
    qtype_sag, chebyshev_sag, surface_slopes
)

BASE = Path(__file__).parent.parent
CAD_DIR = BASE / "cad"
SURF_DIR = CAD_DIR / "freeform_surfaces"
STL_DIR  = CAD_DIR / "exported_STL"
STEP_DIR = CAD_DIR / "STEP"
DATA_CSV = BASE / "data" / "csv"

SURF_DIR.mkdir(parents=True, exist_ok=True)
STL_DIR.mkdir(parents=True, exist_ok=True)
STEP_DIR.mkdir(parents=True, exist_ok=True)

HALF_AP = 10.0   # mm
R_BASE  = 80.0   # mm
K_BASE  = -0.50
N_GRID  = 128    # Grid resolution for CAD mesh
DX      = 2 * HALF_AP / (N_GRID - 1)

# Coefficients
ZERNIKE_COEFFS = {5: 0.050, 9: 0.030, 12: 0.020, 16: 0.012, 17: 0.008, 25: 0.005}
XY_COEFFS      = {(0,2):0.0012, (0,4):0.0006, (2,0):0.0010, (2,2):0.0005, (4,0):0.0004, (0,6):0.0002, (6,0):0.0002}
QTYPE_COEFFS   = {0:0.0, 1:0.040, 2:0.022, 3:0.012, 4:0.006, 5:0.003}
CHEBY_COEFFS   = {(0,2):0.0011, (0,4):0.0005, (2,0):0.0009, (2,2):0.0004, (4,0):0.0003, (0,6):0.0002, (6,0):0.0002}

def write_stl(filename: Path, x: np.ndarray, y: np.ndarray, z: np.ndarray, name: str = "Freeform"):
    """Write an ASCII STL triangulated surface mesh."""
    ny, nx = z.shape
    with open(filename, "w") as f:
        f.write(f"solid {name}\n")
        for i in range(ny - 1):
            for j in range(nx - 1):
                # Triangle 1: (i, j), (i+1, j), (i+1, j+1)
                p1 = np.array([x[i, j], y[i, j], z[i, j]])
                p2 = np.array([x[i+1, j], y[i+1, j], z[i+1, j]])
                p3 = np.array([x[i+1, j+1], y[i+1, j+1], z[i+1, j+1]])
                
                v1 = p2 - p1
                v2 = p3 - p1
                normal1 = np.cross(v1, v2)
                norm_len1 = np.linalg.norm(normal1)
                if norm_len1 > 1e-12:
                    normal1 /= norm_len1
                else:
                    normal1 = np.array([0.0, 0.0, 1.0])
                    
                f.write(f"  facet normal {normal1[0]:.6e} {normal1[1]:.6e} {normal1[2]:.6e}\n")
                f.write("    outer loop\n")
                f.write(f"      vertex {p1[0]:.6e} {p1[1]:.6e} {p1[2]:.6e}\n")
                f.write(f"      vertex {p2[0]:.6e} {p2[1]:.6e} {p2[2]:.6e}\n")
                f.write(f"      vertex {p3[0]:.6e} {p3[1]:.6e} {p3[2]:.6e}\n")
                f.write("    endloop\n")
                f.write("  endfacet\n")
                
                # Triangle 2: (i, j), (i+1, j+1), (i, j+1)
                p4 = np.array([x[i, j+1], y[i, j+1], z[i, j+1]])
                v1 = p3 - p1
                v2 = p4 - p1
                normal2 = np.cross(v1, v2)
                norm_len2 = np.linalg.norm(normal2)
                if norm_len2 > 1e-12:
                    normal2 /= norm_len2
                else:
                    normal2 = np.array([0.0, 0.0, 1.0])
                    
                f.write(f"  facet normal {normal2[0]:.6e} {normal2[1]:.6e} {normal2[2]:.6e}\n")
                f.write("    outer loop\n")
                f.write(f"      vertex {p1[0]:.6e} {p1[1]:.6e} {p1[2]:.6e}\n")
                f.write(f"      vertex {p3[0]:.6e} {p3[1]:.6e} {p3[2]:.6e}\n")
                f.write(f"      vertex {p4[0]:.6e} {p4[1]:.6e} {p4[2]:.6e}\n")
                f.write("    endloop\n")
                f.write("  endfacet\n")
        f.write(f"endsolid {name}\n")
    print(f"  STL written: {filename.name}")

def main():
    print("=== CAD SURFACE GENERATION ===")
    x, y = make_grid(HALF_AP, N_GRID)
    
    z_base = even_asphere_sag(x, y, R_BASE, K_BASE)
    surfaces = {
        "asphere":       z_base,
        "zernike":       zernike_sag(x, y, R_BASE, K_BASE, ZERNIKE_COEFFS, HALF_AP, "fringe"),
        "xy_poly":       xy_polynomial_sag(x, y, R_BASE, K_BASE, XY_COEFFS),
        "qtype":         qtype_sag(x, y, R_BASE, K_BASE, QTYPE_COEFFS, HALF_AP),
        "chebyshev":     chebyshev_sag(x, y, R_BASE, K_BASE, CHEBY_COEFFS, HALF_AP),
    }
    
    cad_coords_rows = []
    for name, z in surfaces.items():
        # Export CSV point cloud
        dzdx, dzdy = surface_slopes(z, DX)
        df = pd.DataFrame({
            "x_mm": x.ravel(),
            "y_mm": y.ravel(),
            "z_mm": z.ravel(),
            "dz_dx": dzdx.ravel(),
            "dz_dy": dzdy.ravel()
        })
        csv_file = SURF_DIR / f"{name}_point_cloud.csv"
        df.to_csv(csv_file, index=False)
        print(f"  CSV point cloud written: {csv_file.name}")
        
        # Add to master cad coordinates
        df_sample = df.iloc[::16].copy()
        df_sample["surface"] = name
        cad_coords_rows.append(df_sample)
        
        # Export STL mesh
        stl_file = STL_DIR / f"{name}_surface.stl"
        write_stl(stl_file, x, y, z, name=name)
        
    master_cad_df = pd.concat(cad_coords_rows, ignore_index=True)
    master_cad_df.to_csv(DATA_CSV / "cad_surface_coordinates.csv", index=False)
    print(f"  Master CAD coordinates saved to data/csv/cad_surface_coordinates.csv")
    
    # Write STEP conversion procedure notes
    step_notes = """STEP Solid Model Generation Procedure:
1. Open FreeCAD (>= 0.20) or Autodesk Fusion 360 / SolidWorks.
2. In FreeCAD, switch to the 'Surface' or 'Part' workbench.
3. Import the generated STL file from cad/exported_STL/<surface>_surface.stl or CSV point cloud.
4. Use 'Curves' workbench or 'Points' workbench to fit a B-spline / NURBS face to the points.
5. Create an extrude or boundary solid with mirror substrate thickness (15.0 mm).
6. Export as STEP AP214 / AP242 to cad/STEP/<surface>_mirror.step.
7. Verify aperture diameter (20.0 mm), center thickness (15.0 mm), and coordinate system alignment.
"""
    with open(STEP_DIR / "README.txt", "w") as f:
        f.write(step_notes)
    print("  STEP conversion notes written.")
    print("=== CAD GENERATION COMPLETE ===")

if __name__ == "__main__":
    main()
