﻿# Freeform Basis Comparison for Compact Wide-Field Imaging Systems

## Project Overview
This repository contains the complete, reproducible computational research pipeline, optical prescriptions, analytical models, tolerance simulations, CAD models, and LaTeX manuscript for the scientific paper:

> **"Comparative Robust Optimization of Freeform Surface Representations for Compact Wide-Field Imaging Systems Using Ansys Zemax OpticStudio"**

---

## Repository Architecture

```text
Freeform_Basis_Comparison_Compact_WFI/
├── manuscript/
│   ├── main.tex               # Full LaTeX manuscript (30+ sections)
│   ├── supplementary.tex      # Supplementary Information document
│   └── references.bib         # Verified BibTeX database
├── zemax/
│   ├── baseline.zmx           # Even Asphere baseline
│   ├── zernike.zmx            # Zernike Fringe Sag surface
│   ├── xy.zmx                 # XY Polynomial surface
│   ├── qtype.zmx              # Forbes Q-bfs Q-Type surface
│   ├── chebyshev.zmx          # Chebyshev polynomial surface
│   └── truefreeform.zmx       # TrueFreeForm / Grid Sag surface
├── python/
│   ├── master_pipeline.py     # Master data generation and figure pipeline
│   ├── freeform_surfaces.py   # Analytical evaluation of all 8 surface representations
│   ├── fci_calculator.py      # Freeform Complexity Index (FCI) computation
│   ├── psd_analysis.py        # Power Spectral Density (LSF/MSF/HSF) decomposition
│   ├── tolerance.py           # Monte-Carlo tolerance analysis (analytical model)
│   ├── statistics.py          # ANOVA, Kruskal-Wallis, effect size & Pareto analysis
│   ├── optimization.py        # Multi-objective NSGA-II optimization
│   ├── plotting.py            # Generates all publication-grade figures
│   ├── zemax_api.py           # ZOS-API interface for OpticStudio automation
│   ├── bibliography.py        # Crossref/DOI verification engine
│   ├── requirements.txt       # Python package dependencies
│   ├── environment.yml        # Conda environment definition
│   └── RUN_ALL.py             # Reproducibility entry point
├── matlab/
│   ├── master_analysis.m      # MATLAB master runner
│   ├── freeform_analysis.m    # Surface reconstruction & metric extraction
│   ├── tolerance_analysis.m   # Monte-Carlo cross-validation
│   ├── statistics_analysis.m  # ANOVA & statistical hypothesis testing
│   └── RUN_ALL.m              # Master MATLAB script
├── cad/
│   ├── generate_surfaces.py   # STL & CSV point cloud generator
│   ├── freeform_surfaces/     # CSV surface coordinate clouds
│   ├── exported_STL/          # Triangulated ASCII STL meshes
│   └── STEP/                  # STEP solid modeling notes & procedure
├── data/
│   ├── csv/                   # CSV datasets (all figures and tables)
│   ├── raw/                   # Raw simulation logs
│   ├── processed/             # Processed metric tables
│   └── tables/                # LaTeX table data
├── figures/
│   ├── source/                # High-resolution PNG figures (300 DPI)
│   └── publication/           # Vector SVG figures
├── references/
│   ├── literature_matrix.csv  # State-of-the-art gap analysis matrix
│   ├── bibliography_verification.csv # DOI verification status
│   └── DOI_verification.csv   # Title match logs
└── logs/
    ├── software_versions.txt  # Environment and software specifications
    ├── simulation_log.txt     # Optical simulation log
    └── bibliography_log.txt   # Reference verification log
```

---

## Scientific Principles & Integrity

1. **Controlled Fair Comparison**: All mathematical representations (Even Asphere, Zernike Fringe, Zernike Standard, XY Polynomial, Forbes Q-Type, Chebyshev Polynomial, TrueFreeForm Grid) are evaluated under **strictly identical optical system constraints**:
   - Aperture: 20 mm
   - Effective Focal Length: 150 mm (F/7.5)
   - Field of View: $\pm 4^\circ$
   - Spectral Band: 450--900 nm
   - Total Track: $\le 250$ mm
   - Identical packaging envelope, clear apertures, and merit-function operands.

2. **No Fake Data Policy**:
   - Analytically computed metrics (surface sag, slopes, curvatures, PSD, FCI, first-order tolerance distributions) are derived directly from the mathematical models and verified against independent MATLAB scripts.
   - OpticStudio live optimization results that require a local license are explicitly labeled `[SIMULATION NOT EXECUTED]` in the placeholder tables.

---

## Quick Start / Reproducibility

### Python Execution
```bash
cd python
pip install -r requirements.txt
python RUN_ALL.py
```

### MATLAB Execution
```matlab
cd matlab
RUN_ALL
```

### LaTeX Compilation
```bash
cd manuscript
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

---

## License & Attribution
Academic and research use only. Cite the accompanying journal publication.
