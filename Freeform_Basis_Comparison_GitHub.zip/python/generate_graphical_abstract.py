"""
generate_graphical_abstract.py
==============================
Generates a professional, publication-grade Graphical Abstract for
Optics & Laser Technology (Elsevier), conforming to Elsevier's dimensions
(531 x 1328 pixels / minimum 500 dpi aspect ratio ~2.5:1 or 2:1 landscape).
"""

import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec

BASE = Path(__file__).parent.parent
SRC_DIR = BASE / "figures" / "source"
PUB_DIR = BASE / "figures" / "publication"
SRC_DIR.mkdir(parents=True, exist_ok=True)
PUB_DIR.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "lines.antialiased": True,
})

def generate_graphical_abstract():
    # Elsevier Graphical Abstract standard: landscape ratio ~ 2:1 to 5:3
    fig = plt.figure(figsize=(12.0, 6.2), dpi=300)
    ax = fig.add_subplot(1, 1, 1)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 6.2)
    ax.axis("off")

    # Background subtle container
    bg_rect = mpatches.FancyBboxPatch((0.1, 0.1), 11.8, 6.0, boxstyle="round,pad=0.2",
                                      facecolor="#f8f9fa", edgecolor="#ced4da", lw=1.5)
    ax.add_patch(bg_rect)

    # Header banner
    header_rect = mpatches.FancyBboxPatch((0.3, 5.3), 11.4, 0.65, boxstyle="round,pad=0.1",
                                          facecolor="#2b2d42", edgecolor="none")
    ax.add_patch(header_rect)
    ax.text(6.0, 5.62, "Benchmarking Mathematical Freeform Surface Representations for Robust Imaging",
            ha="center", va="center", color="white", fontsize=12.5, fontweight="bold")

    # Column 1: Optical Architecture & Baseline (x ~ 0.5 to 2.8)
    col1 = mpatches.FancyBboxPatch((0.5, 0.6), 2.4, 4.4, boxstyle="round,pad=0.15",
                                  facecolor="#edf2f4", edgecolor="#8d99ae", lw=1.5)
    ax.add_patch(col1)
    ax.text(1.7, 4.7, "Compact Off-Axis\nOptical System", ha="center", va="center",
            fontsize=10.5, fontweight="bold", color="#2b2d42")

    # Small diagram inside Col 1: two mirrors and ray trace
    ax.plot([0.9, 1.2, 2.3], [3.6, 2.2, 1.3], color="#d90429", lw=2.0, alpha=0.85) # ray
    ax.plot([0.9, 1.3, 2.3], [3.8, 2.1, 1.1], color="#023e8a", lw=2.0, alpha=0.85) # ray
    # M1 curve
    m1_y = np.linspace(3.2, 4.2, 30)
    m1_x = 0.95 + 0.08 * (m1_y - 3.7)**2
    ax.plot(m1_x, m1_y, color="#2b2d42", lw=3.5, label="M1 (Primary)")
    # M2 curve
    m2_y = np.linspace(1.8, 2.6, 30)
    m2_x = 1.35 - 0.12 * (m2_y - 2.2)**2
    ax.plot(m2_x, m2_y, color="#2b2d42", lw=3.5, label="M2 (Secondary)")
    
    ax.text(1.7, 3.9, "M1 Freeform", fontsize=8.5, fontweight="bold", color="#2b2d42")
    ax.text(1.8, 2.4, "M2 Even Asphere", fontsize=8.5, fontweight="bold", color="#2b2d42")
    ax.text(1.7, 0.95, "EFL = 150 mm, F/7.5\nFoV = ±4.0° Circular\nTrack ≤ 250 mm",
            ha="center", va="center", fontsize=8.2, color="#495057",
            bbox=dict(boxstyle="round,pad=0.2", facecolor="white", edgecolor="#ced4da"))

    # Arrow Col 1 -> Col 2
    ax.annotate("", xy=(3.15, 2.8), xytext=(2.95, 2.8),
                arrowprops=dict(arrowstyle="->", lw=2.5, color="#2b2d42"))

    # Column 2: 7 Candidate Surface Representations (x ~ 3.2 to 5.8)
    col2 = mpatches.FancyBboxPatch((3.2, 0.6), 2.7, 4.4, boxstyle="round,pad=0.15",
                                  facecolor="#e8f4f8", edgecolor="#0077b6", lw=1.5)
    ax.add_patch(col2)
    ax.text(4.55, 4.7, "7 Surface Representations\n(Normalized Protocol N=6)",
            ha="center", va="center", fontsize=10.0, fontweight="bold", color="#03045e")

    rep_items = [
        ("Forbes Q-Type (Q_bfs)", "#00b894"),
        ("2D Chebyshev Poly", "#6c5ce7"),
        ("Zernike Standard (Noll)", "#00cec9"),
        ("Zernike Fringe", "#0984e3"),
        ("Cartesian XY Poly", "#d63031"),
        ("Even Asphere Baseline", "#7f8c8d"),
        ("TrueFreeForm (16x16 PCA)", "#e17055"),
    ]
    for idx, (rep_text, rep_col) in enumerate(rep_items):
        y_pos = 4.05 - idx * 0.47
        rect = mpatches.FancyBboxPatch((3.4, y_pos - 0.17), 2.3, 0.35, boxstyle="round,pad=0.08",
                                       facecolor=rep_col, edgecolor="none", alpha=0.9)
        ax.add_patch(rect)
        ax.text(4.55, y_pos, rep_text, ha="center", va="center", fontsize=8.0,
                fontweight="bold", color="white")

    # Arrow Col 2 -> Col 3
    ax.annotate("", xy=(6.15, 2.8), xytext=(5.95, 2.8),
                arrowprops=dict(arrowstyle="->", lw=2.5, color="#2b2d42"))

    # Column 3: Multi-Criteria Analysis & Monte Carlo (x ~ 6.2 to 8.8)
    col3 = mpatches.FancyBboxPatch((6.2, 0.6), 2.7, 4.4, boxstyle="round,pad=0.15",
                                  facecolor="#fefae0", edgecolor="#dda15e", lw=1.5)
    ax.add_patch(col3)
    ax.text(7.55, 4.7, "Multi-Physics Evaluation\n& 175,000 Monte-Carlo",
            ha="center", va="center", fontsize=10.0, fontweight="bold", color="#bc6c25")

    eval_items = [
        ("• Wavefront Error & MTF", "#2b2d42"),
        ("• Slope & Laplacian Curvature", "#2b2d42"),
        ("• 2D PSD (LSF / MSF / HSF)", "#2b2d42"),
        ("• Freeform Complexity Index (FCI)", "#2b2d42"),
        ("• 25,000 trials × 7 groups (5 seeds)", "#d90429"),
        ("• ISO 10110 Tolerancing", "#2b2d42"),
        ("• NSGA-II 3-Objective Pareto Front", "#2b2d42"),
    ]
    for idx, (e_text, e_col) in enumerate(eval_items):
        y_pos = 4.0 - idx * 0.47
        ax.text(6.4, y_pos, e_text, fontsize=8.0, fontweight="bold", color=e_col)

    # Arrow Col 3 -> Col 4
    ax.annotate("", xy=(9.15, 2.8), xytext=(8.95, 2.8),
                arrowprops=dict(arrowstyle="->", lw=2.5, color="#2b2d42"))

    # Column 4: Key Findings & Engineering Verdict (x ~ 9.2 to 11.5)
    col4 = mpatches.FancyBboxPatch((9.2, 0.6), 2.3, 4.4, boxstyle="round,pad=0.15",
                                  facecolor="#e9f5ed", edgecolor="#2a9d8f", lw=1.5)
    ax.add_patch(col4)
    ax.text(10.35, 4.7, "Benchmark Findings\n& Recommendation",
            ha="center", va="center", fontsize=10.0, fontweight="bold", color="#1b4332")

    # Winner highlight box
    w_box = mpatches.FancyBboxPatch((9.35, 2.7), 2.0, 1.4, boxstyle="round,pad=0.1",
                                   facecolor="#2a9d8f", edgecolor="#1b4332", lw=1.5)
    ax.add_patch(w_box)
    ax.text(10.35, 3.8, "FORBES Q-TYPE", ha="center", va="center", fontsize=9.5,
            fontweight="bold", color="white")
    ax.text(10.35, 3.4, "99.91% Tolerance Yield", ha="center", va="center", fontsize=8.2,
            fontweight="bold", color="#e9d8a6")
    ax.text(10.35, 3.05, "Orthogonal Slope Basis", ha="center", va="center", fontsize=7.8,
            color="white")
    ax.text(10.35, 2.75, "Hessian |C_ij| ≤ 0.08", ha="center", va="center", fontsize=7.8,
            color="white")

    # Comparison summary
    ax.text(10.35, 2.15, "Chebyshev: 99.04% Yield\nZernike Std: 98.35% Yield\nZernike Fringe: 97.35% Yield",
            ha="center", va="center", fontsize=7.6, color="#2b2d42")
    ax.text(10.35, 1.25, "Cartesian XY: 57.20%\nTrueFreeForm: 47.10%\n(High sensitivity / coupling)",
            ha="center", va="center", fontsize=7.6, color="#d90429", fontweight="bold")

    # Footer note
    ax.text(6.0, 0.35, "Controlled benchmark protocol: Identical starting conditions, equal optimization bounds (|a_m| ≤ 0.3 mm), identical DLS optimizer.",
            ha="center", va="center", fontsize=8.2, style="italic", color="#6c757d")

    # Save PNG and SVG
    p_png = SRC_DIR / "graphical_abstract.png"
    p_svg = PUB_DIR / "graphical_abstract.svg"
    fig.savefig(p_png, dpi=300, bbox_inches="tight")
    fig.savefig(p_svg, bbox_inches="tight")
    plt.close(fig)
    print(f"Graphical abstract saved: {p_png}")

if __name__ == "__main__":
    generate_graphical_abstract()
